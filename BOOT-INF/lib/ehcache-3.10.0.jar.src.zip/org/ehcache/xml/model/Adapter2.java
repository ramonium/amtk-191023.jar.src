
package org.ehcache.xml.model;

import java.math.BigInteger;
import javax.xml.bind.annotation.adapters.XmlAdapter;

public class Adapter2
    extends XmlAdapter<String, BigInteger>
{


    public BigInteger unmarshal(String value) {
        return (org.ehcache.xml.ParsingUtil.parsePropertyOrPositiveInteger(value));
    }

    public String marshal(BigInteger value) {
        if (value == null) {
            return null;
        }
        return value.toString();
    }

}

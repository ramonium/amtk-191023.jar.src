
package org.ehcache.xml.model;

import javax.xml.bind.annotation.adapters.XmlAdapter;

public class Adapter4
    extends XmlAdapter<String, String>
{


    public String unmarshal(String value) {
        return (org.ehcache.xml.ParsingUtil.parseStringWithProperties(value));
    }

    public String marshal(String value) {
        if (value == null) {
            return null;
        }
        return value.toString();
    }

}

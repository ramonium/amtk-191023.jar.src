
package org.ehcache.xml.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAnyElement;
import javax.xml.bind.annotation.XmlType;
import org.w3c.dom.Element;


/**
 * &lt;p&gt;Java class for service-type complex type.
 * 
 * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
 * 
 * &lt;pre&gt;
 * &amp;lt;complexType name="service-type"&amp;gt;
 *   &amp;lt;complexContent&amp;gt;
 *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *       &amp;lt;sequence&amp;gt;
 *         &amp;lt;element ref="{http://www.ehcache.org/v3}service-creation-configuration"/&amp;gt;
 *       &amp;lt;/sequence&amp;gt;
 *     &amp;lt;/restriction&amp;gt;
 *   &amp;lt;/complexContent&amp;gt;
 * &amp;lt;/complexType&amp;gt;
 * &lt;/pre&gt;
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "service-type", propOrder = {
    "serviceCreationConfiguration"
})
public class ServiceType {

    @XmlAnyElement
    protected Element serviceCreationConfiguration;

    /**
     * Gets the value of the serviceCreationConfiguration property.
     * 
     * @return
     *     possible object is
     *     {@link Element }
     *     
     */
    public Element getServiceCreationConfiguration() {
        return serviceCreationConfiguration;
    }

    /**
     * Sets the value of the serviceCreationConfiguration property.
     * 
     * @param value
     *     allowed object is
     *     {@link Element }
     *     
     */
    public void setServiceCreationConfiguration(Element value) {
        this.serviceCreationConfiguration = value;
    }

    public ServiceType withServiceCreationConfiguration(Element value) {
        setServiceCreationConfiguration(value);
        return this;
    }

}

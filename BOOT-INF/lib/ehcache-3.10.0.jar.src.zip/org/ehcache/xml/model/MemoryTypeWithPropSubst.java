
package org.ehcache.xml.model;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * &lt;p&gt;Java class for memory-type-with-prop-subst complex type.
 * 
 * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
 * 
 * &lt;pre&gt;
 * &amp;lt;complexType name="memory-type-with-prop-subst"&amp;gt;
 *   &amp;lt;simpleContent&amp;gt;
 *     &amp;lt;extension base="&amp;lt;http://www.ehcache.org/v3&amp;gt;propertyOrPositiveInteger"&amp;gt;
 *       &amp;lt;attGroup ref="{http://www.ehcache.org/v3}memory-unit-attributes"/&amp;gt;
 *     &amp;lt;/extension&amp;gt;
 *   &amp;lt;/simpleContent&amp;gt;
 * &amp;lt;/complexType&amp;gt;
 * &lt;/pre&gt;
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "memory-type-with-prop-subst", propOrder = {
    "value"
})
@XmlSeeAlso({
    PersistableMemoryTypeWithPropSubst.class
})
public class MemoryTypeWithPropSubst {

    @XmlValue
    @XmlJavaTypeAdapter(Adapter2 .class)
    protected BigInteger value;
    @XmlAttribute(name = "unit")
    protected MemoryUnit unit;

    /**
     * Gets the value of the value property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public BigInteger getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValue(BigInteger value) {
        this.value = value;
    }

    /**
     * Gets the value of the unit property.
     * 
     * @return
     *     possible object is
     *     {@link MemoryUnit }
     *     
     */
    public MemoryUnit getUnit() {
        if (unit == null) {
            return MemoryUnit.B;
        } else {
            return unit;
        }
    }

    /**
     * Sets the value of the unit property.
     * 
     * @param value
     *     allowed object is
     *     {@link MemoryUnit }
     *     
     */
    public void setUnit(MemoryUnit value) {
        this.unit = value;
    }

    public MemoryTypeWithPropSubst withValue(BigInteger value) {
        setValue(value);
        return this;
    }

    public MemoryTypeWithPropSubst withUnit(MemoryUnit value) {
        setUnit(value);
        return this;
    }

}


package org.ehcache.xml.model;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * &lt;p&gt;Java class for disk-store-settings-type complex type.
 * 
 * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
 * 
 * &lt;pre&gt;
 * &amp;lt;complexType name="disk-store-settings-type"&amp;gt;
 *   &amp;lt;complexContent&amp;gt;
 *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *       &amp;lt;attribute name="thread-pool" type="{http://www.w3.org/2001/XMLSchema}string" /&amp;gt;
 *       &amp;lt;attribute name="writer-concurrency" type="{http://www.ehcache.org/v3}propertyOrPositiveInteger" default="1" /&amp;gt;
 *       &amp;lt;attribute name="disk-segments" type="{http://www.ehcache.org/v3}propertyOrPositiveInteger" default="16" /&amp;gt;
 *     &amp;lt;/restriction&amp;gt;
 *   &amp;lt;/complexContent&amp;gt;
 * &amp;lt;/complexType&amp;gt;
 * &lt;/pre&gt;
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "disk-store-settings-type")
public class DiskStoreSettingsType {

    @XmlAttribute(name = "thread-pool")
    protected String threadPool;
    @XmlAttribute(name = "writer-concurrency")
    @XmlJavaTypeAdapter(Adapter2 .class)
    protected BigInteger writerConcurrency;
    @XmlAttribute(name = "disk-segments")
    @XmlJavaTypeAdapter(Adapter2 .class)
    protected BigInteger diskSegments;

    /**
     * Gets the value of the threadPool property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getThreadPool() {
        return threadPool;
    }

    /**
     * Sets the value of the threadPool property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setThreadPool(String value) {
        this.threadPool = value;
    }

    /**
     * Gets the value of the writerConcurrency property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public BigInteger getWriterConcurrency() {
        if (writerConcurrency == null) {
            return new Adapter2().unmarshal("1");
        } else {
            return writerConcurrency;
        }
    }

    /**
     * Sets the value of the writerConcurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWriterConcurrency(BigInteger value) {
        this.writerConcurrency = value;
    }

    /**
     * Gets the value of the diskSegments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public BigInteger getDiskSegments() {
        if (diskSegments == null) {
            return new Adapter2().unmarshal("16");
        } else {
            return diskSegments;
        }
    }

    /**
     * Sets the value of the diskSegments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDiskSegments(BigInteger value) {
        this.diskSegments = value;
    }

    public DiskStoreSettingsType withThreadPool(String value) {
        setThreadPool(value);
        return this;
    }

    public DiskStoreSettingsType withWriterConcurrency(BigInteger value) {
        setWriterConcurrency(value);
        return this;
    }

    public DiskStoreSettingsType withDiskSegments(BigInteger value) {
        setDiskSegments(value);
        return this;
    }

}

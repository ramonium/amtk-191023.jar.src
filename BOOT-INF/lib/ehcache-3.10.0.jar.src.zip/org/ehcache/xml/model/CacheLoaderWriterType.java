
package org.ehcache.xml.model;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * &lt;p&gt;Java class for cache-loader-writer-type complex type.
 * 
 * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
 * 
 * &lt;pre&gt;
 * &amp;lt;complexType name="cache-loader-writer-type"&amp;gt;
 *   &amp;lt;complexContent&amp;gt;
 *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *       &amp;lt;sequence&amp;gt;
 *         &amp;lt;element name="class" type="{http://www.ehcache.org/v3}fqcn-type"/&amp;gt;
 *         &amp;lt;element name="write-behind" minOccurs="0"&amp;gt;
 *           &amp;lt;complexType&amp;gt;
 *             &amp;lt;complexContent&amp;gt;
 *               &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *                 &amp;lt;sequence&amp;gt;
 *                   &amp;lt;choice&amp;gt;
 *                     &amp;lt;element name="batching"&amp;gt;
 *                       &amp;lt;complexType&amp;gt;
 *                         &amp;lt;complexContent&amp;gt;
 *                           &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *                             &amp;lt;all&amp;gt;
 *                               &amp;lt;element name="max-write-delay" type="{http://www.ehcache.org/v3}time-type-with-prop-subst"/&amp;gt;
 *                             &amp;lt;/all&amp;gt;
 *                             &amp;lt;attribute name="batch-size" use="required" type="{http://www.ehcache.org/v3}propertyOrPositiveInteger" /&amp;gt;
 *                             &amp;lt;attribute name="coalesce" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" /&amp;gt;
 *                           &amp;lt;/restriction&amp;gt;
 *                         &amp;lt;/complexContent&amp;gt;
 *                       &amp;lt;/complexType&amp;gt;
 *                     &amp;lt;/element&amp;gt;
 *                     &amp;lt;element name="non-batching"&amp;gt;
 *                       &amp;lt;complexType&amp;gt;
 *                         &amp;lt;complexContent&amp;gt;
 *                           &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *                           &amp;lt;/restriction&amp;gt;
 *                         &amp;lt;/complexContent&amp;gt;
 *                       &amp;lt;/complexType&amp;gt;
 *                     &amp;lt;/element&amp;gt;
 *                   &amp;lt;/choice&amp;gt;
 *                 &amp;lt;/sequence&amp;gt;
 *                 &amp;lt;attribute name="concurrency" type="{http://www.ehcache.org/v3}propertyOrPositiveInteger" default="1" /&amp;gt;
 *                 &amp;lt;attribute name="size" type="{http://www.ehcache.org/v3}propertyOrPositiveInteger" default="2147483647" /&amp;gt;
 *                 &amp;lt;attribute name="thread-pool" type="{http://www.w3.org/2001/XMLSchema}string" /&amp;gt;
 *               &amp;lt;/restriction&amp;gt;
 *             &amp;lt;/complexContent&amp;gt;
 *           &amp;lt;/complexType&amp;gt;
 *         &amp;lt;/element&amp;gt;
 *       &amp;lt;/sequence&amp;gt;
 *     &amp;lt;/restriction&amp;gt;
 *   &amp;lt;/complexContent&amp;gt;
 * &amp;lt;/complexType&amp;gt;
 * &lt;/pre&gt;
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cache-loader-writer-type", propOrder = {
    "clazz",
    "writeBehind"
})
public class CacheLoaderWriterType {

    @XmlElement(name = "class", required = true)
    protected String clazz;
    @XmlElement(name = "write-behind")
    protected CacheLoaderWriterType.WriteBehind writeBehind;

    /**
     * Gets the value of the clazz property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClazz() {
        return clazz;
    }

    /**
     * Sets the value of the clazz property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClazz(String value) {
        this.clazz = value;
    }

    /**
     * Gets the value of the writeBehind property.
     * 
     * @return
     *     possible object is
     *     {@link CacheLoaderWriterType.WriteBehind }
     *     
     */
    public CacheLoaderWriterType.WriteBehind getWriteBehind() {
        return writeBehind;
    }

    /**
     * Sets the value of the writeBehind property.
     * 
     * @param value
     *     allowed object is
     *     {@link CacheLoaderWriterType.WriteBehind }
     *     
     */
    public void setWriteBehind(CacheLoaderWriterType.WriteBehind value) {
        this.writeBehind = value;
    }

    public CacheLoaderWriterType withClazz(String value) {
        setClazz(value);
        return this;
    }

    public CacheLoaderWriterType withWriteBehind(CacheLoaderWriterType.WriteBehind value) {
        setWriteBehind(value);
        return this;
    }


    /**
     * &lt;p&gt;Java class for anonymous complex type.
     * 
     * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
     * 
     * &lt;pre&gt;
     * &amp;lt;complexType&amp;gt;
     *   &amp;lt;complexContent&amp;gt;
     *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
     *       &amp;lt;sequence&amp;gt;
     *         &amp;lt;choice&amp;gt;
     *           &amp;lt;element name="batching"&amp;gt;
     *             &amp;lt;complexType&amp;gt;
     *               &amp;lt;complexContent&amp;gt;
     *                 &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
     *                   &amp;lt;all&amp;gt;
     *                     &amp;lt;element name="max-write-delay" type="{http://www.ehcache.org/v3}time-type-with-prop-subst"/&amp;gt;
     *                   &amp;lt;/all&amp;gt;
     *                   &amp;lt;attribute name="batch-size" use="required" type="{http://www.ehcache.org/v3}propertyOrPositiveInteger" /&amp;gt;
     *                   &amp;lt;attribute name="coalesce" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" /&amp;gt;
     *                 &amp;lt;/restriction&amp;gt;
     *               &amp;lt;/complexContent&amp;gt;
     *             &amp;lt;/complexType&amp;gt;
     *           &amp;lt;/element&amp;gt;
     *           &amp;lt;element name="non-batching"&amp;gt;
     *             &amp;lt;complexType&amp;gt;
     *               &amp;lt;complexContent&amp;gt;
     *                 &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
     *                 &amp;lt;/restriction&amp;gt;
     *               &amp;lt;/complexContent&amp;gt;
     *             &amp;lt;/complexType&amp;gt;
     *           &amp;lt;/element&amp;gt;
     *         &amp;lt;/choice&amp;gt;
     *       &amp;lt;/sequence&amp;gt;
     *       &amp;lt;attribute name="concurrency" type="{http://www.ehcache.org/v3}propertyOrPositiveInteger" default="1" /&amp;gt;
     *       &amp;lt;attribute name="size" type="{http://www.ehcache.org/v3}propertyOrPositiveInteger" default="2147483647" /&amp;gt;
     *       &amp;lt;attribute name="thread-pool" type="{http://www.w3.org/2001/XMLSchema}string" /&amp;gt;
     *     &amp;lt;/restriction&amp;gt;
     *   &amp;lt;/complexContent&amp;gt;
     * &amp;lt;/complexType&amp;gt;
     * &lt;/pre&gt;
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "batching",
        "nonBatching"
    })
    public static class WriteBehind {

        protected CacheLoaderWriterType.WriteBehind.Batching batching;
        @XmlElement(name = "non-batching")
        protected CacheLoaderWriterType.WriteBehind.NonBatching nonBatching;
        @XmlAttribute(name = "concurrency")
        @XmlJavaTypeAdapter(Adapter2 .class)
        protected BigInteger concurrency;
        @XmlAttribute(name = "size")
        @XmlJavaTypeAdapter(Adapter2 .class)
        protected BigInteger size;
        @XmlAttribute(name = "thread-pool")
        protected String threadPool;

        /**
         * Gets the value of the batching property.
         * 
         * @return
         *     possible object is
         *     {@link CacheLoaderWriterType.WriteBehind.Batching }
         *     
         */
        public CacheLoaderWriterType.WriteBehind.Batching getBatching() {
            return batching;
        }

        /**
         * Sets the value of the batching property.
         * 
         * @param value
         *     allowed object is
         *     {@link CacheLoaderWriterType.WriteBehind.Batching }
         *     
         */
        public void setBatching(CacheLoaderWriterType.WriteBehind.Batching value) {
            this.batching = value;
        }

        /**
         * Gets the value of the nonBatching property.
         * 
         * @return
         *     possible object is
         *     {@link CacheLoaderWriterType.WriteBehind.NonBatching }
         *     
         */
        public CacheLoaderWriterType.WriteBehind.NonBatching getNonBatching() {
            return nonBatching;
        }

        /**
         * Sets the value of the nonBatching property.
         * 
         * @param value
         *     allowed object is
         *     {@link CacheLoaderWriterType.WriteBehind.NonBatching }
         *     
         */
        public void setNonBatching(CacheLoaderWriterType.WriteBehind.NonBatching value) {
            this.nonBatching = value;
        }

        /**
         * Gets the value of the concurrency property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public BigInteger getConcurrency() {
            if (concurrency == null) {
                return new Adapter2().unmarshal("1");
            } else {
                return concurrency;
            }
        }

        /**
         * Sets the value of the concurrency property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setConcurrency(BigInteger value) {
            this.concurrency = value;
        }

        /**
         * Gets the value of the size property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public BigInteger getSize() {
            if (size == null) {
                return new Adapter2().unmarshal("2147483647");
            } else {
                return size;
            }
        }

        /**
         * Sets the value of the size property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSize(BigInteger value) {
            this.size = value;
        }

        /**
         * Gets the value of the threadPool property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getThreadPool() {
            return threadPool;
        }

        /**
         * Sets the value of the threadPool property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setThreadPool(String value) {
            this.threadPool = value;
        }

        public CacheLoaderWriterType.WriteBehind withBatching(CacheLoaderWriterType.WriteBehind.Batching value) {
            setBatching(value);
            return this;
        }

        public CacheLoaderWriterType.WriteBehind withNonBatching(CacheLoaderWriterType.WriteBehind.NonBatching value) {
            setNonBatching(value);
            return this;
        }

        public CacheLoaderWriterType.WriteBehind withConcurrency(BigInteger value) {
            setConcurrency(value);
            return this;
        }

        public CacheLoaderWriterType.WriteBehind withSize(BigInteger value) {
            setSize(value);
            return this;
        }

        public CacheLoaderWriterType.WriteBehind withThreadPool(String value) {
            setThreadPool(value);
            return this;
        }


        /**
         * &lt;p&gt;Java class for anonymous complex type.
         * 
         * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
         * 
         * &lt;pre&gt;
         * &amp;lt;complexType&amp;gt;
         *   &amp;lt;complexContent&amp;gt;
         *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
         *       &amp;lt;all&amp;gt;
         *         &amp;lt;element name="max-write-delay" type="{http://www.ehcache.org/v3}time-type-with-prop-subst"/&amp;gt;
         *       &amp;lt;/all&amp;gt;
         *       &amp;lt;attribute name="batch-size" use="required" type="{http://www.ehcache.org/v3}propertyOrPositiveInteger" /&amp;gt;
         *       &amp;lt;attribute name="coalesce" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" /&amp;gt;
         *     &amp;lt;/restriction&amp;gt;
         *   &amp;lt;/complexContent&amp;gt;
         * &amp;lt;/complexType&amp;gt;
         * &lt;/pre&gt;
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {

        })
        public static class Batching {

            @XmlElement(name = "max-write-delay", required = true)
            protected TimeTypeWithPropSubst maxWriteDelay;
            @XmlAttribute(name = "batch-size", required = true)
            @XmlJavaTypeAdapter(Adapter2 .class)
            protected BigInteger batchSize;
            @XmlAttribute(name = "coalesce")
            protected Boolean coalesce;

            /**
             * Gets the value of the maxWriteDelay property.
             * 
             * @return
             *     possible object is
             *     {@link TimeTypeWithPropSubst }
             *     
             */
            public TimeTypeWithPropSubst getMaxWriteDelay() {
                return maxWriteDelay;
            }

            /**
             * Sets the value of the maxWriteDelay property.
             * 
             * @param value
             *     allowed object is
             *     {@link TimeTypeWithPropSubst }
             *     
             */
            public void setMaxWriteDelay(TimeTypeWithPropSubst value) {
                this.maxWriteDelay = value;
            }

            /**
             * Gets the value of the batchSize property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public BigInteger getBatchSize() {
                return batchSize;
            }

            /**
             * Sets the value of the batchSize property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setBatchSize(BigInteger value) {
                this.batchSize = value;
            }

            /**
             * Gets the value of the coalesce property.
             * 
             * @return
             *     possible object is
             *     {@link Boolean }
             *     
             */
            public boolean isCoalesce() {
                if (coalesce == null) {
                    return false;
                } else {
                    return coalesce;
                }
            }

            /**
             * Sets the value of the coalesce property.
             * 
             * @param value
             *     allowed object is
             *     {@link Boolean }
             *     
             */
            public void setCoalesce(Boolean value) {
                this.coalesce = value;
            }

            public CacheLoaderWriterType.WriteBehind.Batching withMaxWriteDelay(TimeTypeWithPropSubst value) {
                setMaxWriteDelay(value);
                return this;
            }

            public CacheLoaderWriterType.WriteBehind.Batching withBatchSize(BigInteger value) {
                setBatchSize(value);
                return this;
            }

            public CacheLoaderWriterType.WriteBehind.Batching withCoalesce(Boolean value) {
                setCoalesce(value);
                return this;
            }

        }


        /**
         * &lt;p&gt;Java class for anonymous complex type.
         * 
         * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
         * 
         * &lt;pre&gt;
         * &amp;lt;complexType&amp;gt;
         *   &amp;lt;complexContent&amp;gt;
         *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
         *     &amp;lt;/restriction&amp;gt;
         *   &amp;lt;/complexContent&amp;gt;
         * &amp;lt;/complexType&amp;gt;
         * &lt;/pre&gt;
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "")
        public static class NonBatching {


        }

    }

}


package org.ehcache.xml.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * &lt;p&gt;Java class for event-type.
 * 
 * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
 * &lt;pre&gt;
 * &amp;lt;simpleType name="event-type"&amp;gt;
 *   &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&amp;gt;
 *     &amp;lt;enumeration value="EVICTED"/&amp;gt;
 *     &amp;lt;enumeration value="EXPIRED"/&amp;gt;
 *     &amp;lt;enumeration value="REMOVED"/&amp;gt;
 *     &amp;lt;enumeration value="CREATED"/&amp;gt;
 *     &amp;lt;enumeration value="UPDATED"/&amp;gt;
 *   &amp;lt;/restriction&amp;gt;
 * &amp;lt;/simpleType&amp;gt;
 * &lt;/pre&gt;
 * 
 */
@XmlType(name = "event-type")
@XmlEnum
public enum EventType {

    EVICTED,
    EXPIRED,
    REMOVED,
    CREATED,
    UPDATED;

    public String value() {
        return name();
    }

    public static EventType fromValue(String v) {
        return valueOf(v);
    }

}

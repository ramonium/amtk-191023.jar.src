
package org.ehcache.xml.model;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

@SuppressWarnings({
    "unchecked",
    "serial"
})
public class Offheap
    extends JAXBElement<MemoryTypeWithPropSubst>
{

    protected final static QName NAME = new QName("http://www.ehcache.org/v3", "offheap");

    public Offheap(MemoryTypeWithPropSubst value) {
        super(NAME, ((Class) MemoryTypeWithPropSubst.class), null, value);
    }

    public Offheap() {
        super(NAME, ((Class) MemoryTypeWithPropSubst.class), null, null);
    }

}


package org.ehcache.xml.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * &lt;p&gt;Java class for event-firing-type.
 * 
 * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
 * &lt;pre&gt;
 * &amp;lt;simpleType name="event-firing-type"&amp;gt;
 *   &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&amp;gt;
 *     &amp;lt;enumeration value="ASYNCHRONOUS"/&amp;gt;
 *     &amp;lt;enumeration value="SYNCHRONOUS"/&amp;gt;
 *   &amp;lt;/restriction&amp;gt;
 * &amp;lt;/simpleType&amp;gt;
 * &lt;/pre&gt;
 * 
 */
@XmlType(name = "event-firing-type")
@XmlEnum
public enum EventFiringType {

    ASYNCHRONOUS,
    SYNCHRONOUS;

    public String value() {
        return name();
    }

    public static EventFiringType fromValue(String v) {
        return valueOf(v);
    }

}


package org.ehcache.xml.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * &lt;p&gt;Java class for thread-pool-reference-type complex type.
 * 
 * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
 * 
 * &lt;pre&gt;
 * &amp;lt;complexType name="thread-pool-reference-type"&amp;gt;
 *   &amp;lt;complexContent&amp;gt;
 *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *       &amp;lt;attribute name="thread-pool" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&amp;gt;
 *     &amp;lt;/restriction&amp;gt;
 *   &amp;lt;/complexContent&amp;gt;
 * &amp;lt;/complexType&amp;gt;
 * &lt;/pre&gt;
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "thread-pool-reference-type")
public class ThreadPoolReferenceType {

    @XmlAttribute(name = "thread-pool", required = true)
    protected String threadPool;

    /**
     * Gets the value of the threadPool property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getThreadPool() {
        return threadPool;
    }

    /**
     * Sets the value of the threadPool property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setThreadPool(String value) {
        this.threadPool = value;
    }

    public ThreadPoolReferenceType withThreadPool(String value) {
        setThreadPool(value);
        return this;
    }

}

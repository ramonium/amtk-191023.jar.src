
package org.ehcache.xml.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * &lt;p&gt;Java class for expiry-type complex type.
 * 
 * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
 * 
 * &lt;pre&gt;
 * &amp;lt;complexType name="expiry-type"&amp;gt;
 *   &amp;lt;complexContent&amp;gt;
 *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *       &amp;lt;choice&amp;gt;
 *         &amp;lt;element name="class" type="{http://www.ehcache.org/v3}fqcn-type"/&amp;gt;
 *         &amp;lt;element name="tti" type="{http://www.ehcache.org/v3}time-type-with-prop-subst"/&amp;gt;
 *         &amp;lt;element name="ttl" type="{http://www.ehcache.org/v3}time-type-with-prop-subst"/&amp;gt;
 *         &amp;lt;element name="none"&amp;gt;
 *           &amp;lt;complexType&amp;gt;
 *             &amp;lt;complexContent&amp;gt;
 *               &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *               &amp;lt;/restriction&amp;gt;
 *             &amp;lt;/complexContent&amp;gt;
 *           &amp;lt;/complexType&amp;gt;
 *         &amp;lt;/element&amp;gt;
 *       &amp;lt;/choice&amp;gt;
 *     &amp;lt;/restriction&amp;gt;
 *   &amp;lt;/complexContent&amp;gt;
 * &amp;lt;/complexType&amp;gt;
 * &lt;/pre&gt;
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "expiry-type", propOrder = {
    "clazz",
    "tti",
    "ttl",
    "none"
})
public class ExpiryType {

    @XmlElement(name = "class")
    protected String clazz;
    protected TimeTypeWithPropSubst tti;
    protected TimeTypeWithPropSubst ttl;
    protected ExpiryType.None none;

    /**
     * Gets the value of the clazz property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClazz() {
        return clazz;
    }

    /**
     * Sets the value of the clazz property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClazz(String value) {
        this.clazz = value;
    }

    /**
     * Gets the value of the tti property.
     * 
     * @return
     *     possible object is
     *     {@link TimeTypeWithPropSubst }
     *     
     */
    public TimeTypeWithPropSubst getTti() {
        return tti;
    }

    /**
     * Sets the value of the tti property.
     * 
     * @param value
     *     allowed object is
     *     {@link TimeTypeWithPropSubst }
     *     
     */
    public void setTti(TimeTypeWithPropSubst value) {
        this.tti = value;
    }

    /**
     * Gets the value of the ttl property.
     * 
     * @return
     *     possible object is
     *     {@link TimeTypeWithPropSubst }
     *     
     */
    public TimeTypeWithPropSubst getTtl() {
        return ttl;
    }

    /**
     * Sets the value of the ttl property.
     * 
     * @param value
     *     allowed object is
     *     {@link TimeTypeWithPropSubst }
     *     
     */
    public void setTtl(TimeTypeWithPropSubst value) {
        this.ttl = value;
    }

    /**
     * Gets the value of the none property.
     * 
     * @return
     *     possible object is
     *     {@link ExpiryType.None }
     *     
     */
    public ExpiryType.None getNone() {
        return none;
    }

    /**
     * Sets the value of the none property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExpiryType.None }
     *     
     */
    public void setNone(ExpiryType.None value) {
        this.none = value;
    }

    public ExpiryType withClazz(String value) {
        setClazz(value);
        return this;
    }

    public ExpiryType withTti(TimeTypeWithPropSubst value) {
        setTti(value);
        return this;
    }

    public ExpiryType withTtl(TimeTypeWithPropSubst value) {
        setTtl(value);
        return this;
    }

    public ExpiryType withNone(ExpiryType.None value) {
        setNone(value);
        return this;
    }


    /**
     * &lt;p&gt;Java class for anonymous complex type.
     * 
     * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
     * 
     * &lt;pre&gt;
     * &amp;lt;complexType&amp;gt;
     *   &amp;lt;complexContent&amp;gt;
     *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
     *     &amp;lt;/restriction&amp;gt;
     *   &amp;lt;/complexContent&amp;gt;
     * &amp;lt;/complexType&amp;gt;
     * &lt;/pre&gt;
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class None {


    }

}

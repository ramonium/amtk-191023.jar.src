
package org.ehcache.xml.model;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * &lt;p&gt;Java class for thread-pools-type complex type.
 * 
 * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
 * 
 * &lt;pre&gt;
 * &amp;lt;complexType name="thread-pools-type"&amp;gt;
 *   &amp;lt;complexContent&amp;gt;
 *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *       &amp;lt;sequence&amp;gt;
 *         &amp;lt;element name="thread-pool" maxOccurs="unbounded"&amp;gt;
 *           &amp;lt;complexType&amp;gt;
 *             &amp;lt;complexContent&amp;gt;
 *               &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *                 &amp;lt;attribute name="alias" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&amp;gt;
 *                 &amp;lt;attribute name="default" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" /&amp;gt;
 *                 &amp;lt;attribute name="min-size" use="required" type="{http://www.ehcache.org/v3}propertyOrNonNegativeInteger" /&amp;gt;
 *                 &amp;lt;attribute name="max-size" use="required" type="{http://www.ehcache.org/v3}propertyOrPositiveInteger" /&amp;gt;
 *               &amp;lt;/restriction&amp;gt;
 *             &amp;lt;/complexContent&amp;gt;
 *           &amp;lt;/complexType&amp;gt;
 *         &amp;lt;/element&amp;gt;
 *       &amp;lt;/sequence&amp;gt;
 *     &amp;lt;/restriction&amp;gt;
 *   &amp;lt;/complexContent&amp;gt;
 * &amp;lt;/complexType&amp;gt;
 * &lt;/pre&gt;
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "thread-pools-type", propOrder = {
    "threadPool"
})
public class ThreadPoolsType {

    @XmlElement(name = "thread-pool", required = true)
    protected List<ThreadPoolsType.ThreadPool> threadPool;

    /**
     * Gets the value of the threadPool property.
     * 
     * &lt;p&gt;
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a &lt;CODE&gt;set&lt;/CODE&gt; method for the threadPool property.
     * 
     * &lt;p&gt;
     * For example, to add a new item, do as follows:
     * &lt;pre&gt;
     *    getThreadPool().add(newItem);
     * &lt;/pre&gt;
     * 
     * 
     * &lt;p&gt;
     * Objects of the following type(s) are allowed in the list
     * {@link ThreadPoolsType.ThreadPool }
     * 
     * 
     */
    public List<ThreadPoolsType.ThreadPool> getThreadPool() {
        if (threadPool == null) {
            threadPool = new ArrayList<ThreadPoolsType.ThreadPool>();
        }
        return this.threadPool;
    }

    public ThreadPoolsType withThreadPool(ThreadPoolsType.ThreadPool... values) {
        if (values!= null) {
            for (ThreadPoolsType.ThreadPool value: values) {
                getThreadPool().add(value);
            }
        }
        return this;
    }

    public ThreadPoolsType withThreadPool(Collection<ThreadPoolsType.ThreadPool> values) {
        if (values!= null) {
            getThreadPool().addAll(values);
        }
        return this;
    }


    /**
     * &lt;p&gt;Java class for anonymous complex type.
     * 
     * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
     * 
     * &lt;pre&gt;
     * &amp;lt;complexType&amp;gt;
     *   &amp;lt;complexContent&amp;gt;
     *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
     *       &amp;lt;attribute name="alias" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&amp;gt;
     *       &amp;lt;attribute name="default" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" /&amp;gt;
     *       &amp;lt;attribute name="min-size" use="required" type="{http://www.ehcache.org/v3}propertyOrNonNegativeInteger" /&amp;gt;
     *       &amp;lt;attribute name="max-size" use="required" type="{http://www.ehcache.org/v3}propertyOrPositiveInteger" /&amp;gt;
     *     &amp;lt;/restriction&amp;gt;
     *   &amp;lt;/complexContent&amp;gt;
     * &amp;lt;/complexType&amp;gt;
     * &lt;/pre&gt;
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class ThreadPool {

        @XmlAttribute(name = "alias", required = true)
        protected String alias;
        @XmlAttribute(name = "default")
        protected Boolean _default;
        @XmlAttribute(name = "min-size", required = true)
        @XmlJavaTypeAdapter(Adapter3 .class)
        protected BigInteger minSize;
        @XmlAttribute(name = "max-size", required = true)
        @XmlJavaTypeAdapter(Adapter2 .class)
        protected BigInteger maxSize;

        /**
         * Gets the value of the alias property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getAlias() {
            return alias;
        }

        /**
         * Sets the value of the alias property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setAlias(String value) {
            this.alias = value;
        }

        /**
         * Gets the value of the default property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDefault() {
            if (_default == null) {
                return false;
            } else {
                return _default;
            }
        }

        /**
         * Sets the value of the default property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDefault(Boolean value) {
            this._default = value;
        }

        /**
         * Gets the value of the minSize property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public BigInteger getMinSize() {
            return minSize;
        }

        /**
         * Sets the value of the minSize property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMinSize(BigInteger value) {
            this.minSize = value;
        }

        /**
         * Gets the value of the maxSize property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public BigInteger getMaxSize() {
            return maxSize;
        }

        /**
         * Sets the value of the maxSize property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMaxSize(BigInteger value) {
            this.maxSize = value;
        }

        public ThreadPoolsType.ThreadPool withAlias(String value) {
            setAlias(value);
            return this;
        }

        public ThreadPoolsType.ThreadPool withDefault(Boolean value) {
            setDefault(value);
            return this;
        }

        public ThreadPoolsType.ThreadPool withMinSize(BigInteger value) {
            setMinSize(value);
            return this;
        }

        public ThreadPoolsType.ThreadPool withMaxSize(BigInteger value) {
            setMaxSize(value);
            return this;
        }

    }

}


package org.ehcache.xml.model;

import java.math.BigInteger;
import javax.xml.bind.annotation.adapters.XmlAdapter;

public class Adapter3
    extends XmlAdapter<String, BigInteger>
{


    public BigInteger unmarshal(String value) {
        return (org.ehcache.xml.ParsingUtil.parsePropertyOrNonNegativeInteger(value));
    }

    public String marshal(BigInteger value) {
        if (value == null) {
            return null;
        }
        return value.toString();
    }

}

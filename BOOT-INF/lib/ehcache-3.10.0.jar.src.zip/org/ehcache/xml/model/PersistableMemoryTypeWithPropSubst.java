
package org.ehcache.xml.model;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * &lt;p&gt;Java class for persistable-memory-type-with-prop-subst complex type.
 * 
 * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
 * 
 * &lt;pre&gt;
 * &amp;lt;complexType name="persistable-memory-type-with-prop-subst"&amp;gt;
 *   &amp;lt;simpleContent&amp;gt;
 *     &amp;lt;extension base="&amp;lt;http://www.ehcache.org/v3&amp;gt;memory-type-with-prop-subst"&amp;gt;
 *       &amp;lt;attribute name="persistent" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" /&amp;gt;
 *     &amp;lt;/extension&amp;gt;
 *   &amp;lt;/simpleContent&amp;gt;
 * &amp;lt;/complexType&amp;gt;
 * &lt;/pre&gt;
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "persistable-memory-type-with-prop-subst")
public class PersistableMemoryTypeWithPropSubst
    extends MemoryTypeWithPropSubst
{

    @XmlAttribute(name = "persistent")
    protected Boolean persistent;

    /**
     * Gets the value of the persistent property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isPersistent() {
        if (persistent == null) {
            return false;
        } else {
            return persistent;
        }
    }

    /**
     * Sets the value of the persistent property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPersistent(Boolean value) {
        this.persistent = value;
    }

    public PersistableMemoryTypeWithPropSubst withPersistent(Boolean value) {
        setPersistent(value);
        return this;
    }

    @Override
    public PersistableMemoryTypeWithPropSubst withValue(BigInteger value) {
        setValue(value);
        return this;
    }

    @Override
    public PersistableMemoryTypeWithPropSubst withUnit(MemoryUnit value) {
        setUnit(value);
        return this;
    }

}

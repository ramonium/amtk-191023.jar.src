
package org.ehcache.xml.model;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

@SuppressWarnings({
    "unchecked",
    "serial"
})
public class Heap
    extends JAXBElement<ResourceTypeWithPropSubst>
{

    protected final static QName NAME = new QName("http://www.ehcache.org/v3", "heap");

    public Heap(ResourceTypeWithPropSubst value) {
        super(NAME, ((Class) ResourceTypeWithPropSubst.class), null, value);
    }

    public Heap() {
        super(NAME, ((Class) ResourceTypeWithPropSubst.class), null, null);
    }

}

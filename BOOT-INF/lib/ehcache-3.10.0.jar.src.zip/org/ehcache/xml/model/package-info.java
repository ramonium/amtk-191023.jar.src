@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.ehcache.org/v3", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.ehcache.xml.model;

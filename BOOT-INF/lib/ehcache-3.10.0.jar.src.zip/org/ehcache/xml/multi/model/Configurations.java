
package org.ehcache.xml.multi.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAnyElement;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import org.w3c.dom.Element;


/**
 * &lt;p&gt;Java class for anonymous complex type.
 * 
 * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
 * 
 * &lt;pre&gt;
 * &amp;lt;complexType&amp;gt;
 *   &amp;lt;complexContent&amp;gt;
 *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *       &amp;lt;sequence maxOccurs="unbounded" minOccurs="0"&amp;gt;
 *         &amp;lt;element name="configuration"&amp;gt;
 *           &amp;lt;complexType&amp;gt;
 *             &amp;lt;complexContent&amp;gt;
 *               &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *                 &amp;lt;choice&amp;gt;
 *                   &amp;lt;element ref="{http://www.ehcache.org/v3}config"/&amp;gt;
 *                   &amp;lt;element name="variant" maxOccurs="unbounded"&amp;gt;
 *                     &amp;lt;complexType&amp;gt;
 *                       &amp;lt;complexContent&amp;gt;
 *                         &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *                           &amp;lt;sequence&amp;gt;
 *                             &amp;lt;element ref="{http://www.ehcache.org/v3}config"/&amp;gt;
 *                           &amp;lt;/sequence&amp;gt;
 *                           &amp;lt;attribute name="type" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&amp;gt;
 *                         &amp;lt;/restriction&amp;gt;
 *                       &amp;lt;/complexContent&amp;gt;
 *                     &amp;lt;/complexType&amp;gt;
 *                   &amp;lt;/element&amp;gt;
 *                 &amp;lt;/choice&amp;gt;
 *                 &amp;lt;attribute name="identity" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&amp;gt;
 *               &amp;lt;/restriction&amp;gt;
 *             &amp;lt;/complexContent&amp;gt;
 *           &amp;lt;/complexType&amp;gt;
 *         &amp;lt;/element&amp;gt;
 *       &amp;lt;/sequence&amp;gt;
 *     &amp;lt;/restriction&amp;gt;
 *   &amp;lt;/complexContent&amp;gt;
 * &amp;lt;/complexType&amp;gt;
 * &lt;/pre&gt;
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "configuration"
})
@XmlRootElement(name = "configurations")
public class Configurations {

    protected List<Configurations.Configuration> configuration;

    /**
     * Gets the value of the configuration property.
     * 
     * &lt;p&gt;
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a &lt;CODE&gt;set&lt;/CODE&gt; method for the configuration property.
     * 
     * &lt;p&gt;
     * For example, to add a new item, do as follows:
     * &lt;pre&gt;
     *    getConfiguration().add(newItem);
     * &lt;/pre&gt;
     * 
     * 
     * &lt;p&gt;
     * Objects of the following type(s) are allowed in the list
     * {@link Configurations.Configuration }
     * 
     * 
     */
    public List<Configurations.Configuration> getConfiguration() {
        if (configuration == null) {
            configuration = new ArrayList<Configurations.Configuration>();
        }
        return this.configuration;
    }

    public Configurations withConfiguration(Configurations.Configuration... values) {
        if (values!= null) {
            for (Configurations.Configuration value: values) {
                getConfiguration().add(value);
            }
        }
        return this;
    }

    public Configurations withConfiguration(Collection<Configurations.Configuration> values) {
        if (values!= null) {
            getConfiguration().addAll(values);
        }
        return this;
    }


    /**
     * &lt;p&gt;Java class for anonymous complex type.
     * 
     * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
     * 
     * &lt;pre&gt;
     * &amp;lt;complexType&amp;gt;
     *   &amp;lt;complexContent&amp;gt;
     *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
     *       &amp;lt;choice&amp;gt;
     *         &amp;lt;element ref="{http://www.ehcache.org/v3}config"/&amp;gt;
     *         &amp;lt;element name="variant" maxOccurs="unbounded"&amp;gt;
     *           &amp;lt;complexType&amp;gt;
     *             &amp;lt;complexContent&amp;gt;
     *               &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
     *                 &amp;lt;sequence&amp;gt;
     *                   &amp;lt;element ref="{http://www.ehcache.org/v3}config"/&amp;gt;
     *                 &amp;lt;/sequence&amp;gt;
     *                 &amp;lt;attribute name="type" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&amp;gt;
     *               &amp;lt;/restriction&amp;gt;
     *             &amp;lt;/complexContent&amp;gt;
     *           &amp;lt;/complexType&amp;gt;
     *         &amp;lt;/element&amp;gt;
     *       &amp;lt;/choice&amp;gt;
     *       &amp;lt;attribute name="identity" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&amp;gt;
     *     &amp;lt;/restriction&amp;gt;
     *   &amp;lt;/complexContent&amp;gt;
     * &amp;lt;/complexType&amp;gt;
     * &lt;/pre&gt;
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "config",
        "variant"
    })
    public static class Configuration {

        @XmlAnyElement
        protected Element config;
        protected List<Configurations.Configuration.Variant> variant;
        @XmlAttribute(name = "identity", required = true)
        protected String identity;

        /**
         * Gets the value of the config property.
         * 
         * @return
         *     possible object is
         *     {@link Element }
         *     
         */
        public Element getConfig() {
            return config;
        }

        /**
         * Sets the value of the config property.
         * 
         * @param value
         *     allowed object is
         *     {@link Element }
         *     
         */
        public void setConfig(Element value) {
            this.config = value;
        }

        /**
         * Gets the value of the variant property.
         * 
         * &lt;p&gt;
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a &lt;CODE&gt;set&lt;/CODE&gt; method for the variant property.
         * 
         * &lt;p&gt;
         * For example, to add a new item, do as follows:
         * &lt;pre&gt;
         *    getVariant().add(newItem);
         * &lt;/pre&gt;
         * 
         * 
         * &lt;p&gt;
         * Objects of the following type(s) are allowed in the list
         * {@link Configurations.Configuration.Variant }
         * 
         * 
         */
        public List<Configurations.Configuration.Variant> getVariant() {
            if (variant == null) {
                variant = new ArrayList<Configurations.Configuration.Variant>();
            }
            return this.variant;
        }

        /**
         * Gets the value of the identity property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getIdentity() {
            return identity;
        }

        /**
         * Sets the value of the identity property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setIdentity(String value) {
            this.identity = value;
        }

        public Configurations.Configuration withConfig(Element value) {
            setConfig(value);
            return this;
        }

        public Configurations.Configuration withVariant(Configurations.Configuration.Variant... values) {
            if (values!= null) {
                for (Configurations.Configuration.Variant value: values) {
                    getVariant().add(value);
                }
            }
            return this;
        }

        public Configurations.Configuration withVariant(Collection<Configurations.Configuration.Variant> values) {
            if (values!= null) {
                getVariant().addAll(values);
            }
            return this;
        }

        public Configurations.Configuration withIdentity(String value) {
            setIdentity(value);
            return this;
        }


        /**
         * &lt;p&gt;Java class for anonymous complex type.
         * 
         * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
         * 
         * &lt;pre&gt;
         * &amp;lt;complexType&amp;gt;
         *   &amp;lt;complexContent&amp;gt;
         *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
         *       &amp;lt;sequence&amp;gt;
         *         &amp;lt;element ref="{http://www.ehcache.org/v3}config"/&amp;gt;
         *       &amp;lt;/sequence&amp;gt;
         *       &amp;lt;attribute name="type" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&amp;gt;
         *     &amp;lt;/restriction&amp;gt;
         *   &amp;lt;/complexContent&amp;gt;
         * &amp;lt;/complexType&amp;gt;
         * &lt;/pre&gt;
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "config"
        })
        public static class Variant {

            @XmlAnyElement
            protected Element config;
            @XmlAttribute(name = "type", required = true)
            protected String type;

            /**
             * Gets the value of the config property.
             * 
             * @return
             *     possible object is
             *     {@link Element }
             *     
             */
            public Element getConfig() {
                return config;
            }

            /**
             * Sets the value of the config property.
             * 
             * @param value
             *     allowed object is
             *     {@link Element }
             *     
             */
            public void setConfig(Element value) {
                this.config = value;
            }

            /**
             * Gets the value of the type property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getType() {
                return type;
            }

            /**
             * Sets the value of the type property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setType(String value) {
                this.type = value;
            }

            public Configurations.Configuration.Variant withConfig(Element value) {
                setConfig(value);
                return this;
            }

            public Configurations.Configuration.Variant withType(String value) {
                setType(value);
                return this;
            }

        }

    }

}

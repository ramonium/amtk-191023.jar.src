module com.javax0.license3j {
    requires java.net.http;
    exports javax0.license3j;
    exports javax0.license3j.crypto;
    exports javax0.license3j.io;
    exports javax0.license3j.parsers;
    exports javax0.license3j.hardware;
}
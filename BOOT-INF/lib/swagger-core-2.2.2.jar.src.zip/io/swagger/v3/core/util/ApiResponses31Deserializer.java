package io.swagger.v3.core.util;

public class ApiResponses31Deserializer extends ApiResponsesDeserializer {

    public ApiResponses31Deserializer() {
        this.openapi31 = true;
    }

}

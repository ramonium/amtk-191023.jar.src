package io.swagger.v3.core.util;

public class SecurityScheme31Deserializer extends SecuritySchemeDeserializer {

    public SecurityScheme31Deserializer() {
        openapi31 = true;
    }
}

package io.swagger.v3.core.util;

public class Model31Deserializer extends ModelDeserializer {

    public Model31Deserializer() {this.openapi31 = true;}
}

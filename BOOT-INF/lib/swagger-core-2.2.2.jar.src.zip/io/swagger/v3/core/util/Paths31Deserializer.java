package io.swagger.v3.core.util;

public class Paths31Deserializer extends PathsDeserializer {

    public Paths31Deserializer() {
        this.openapi31 = true;
    }
}

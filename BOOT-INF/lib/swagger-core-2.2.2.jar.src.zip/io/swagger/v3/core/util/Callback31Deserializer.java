package io.swagger.v3.core.util;

public class Callback31Deserializer extends CallbackDeserializer {

    public Callback31Deserializer() {
        openapi31 = true;
    }
}

package net.logstash.logback.encoder.com.lmax.disruptor;

public interface TimeoutHandler
{
    void onTimeout(long sequence) throws Exception;
}

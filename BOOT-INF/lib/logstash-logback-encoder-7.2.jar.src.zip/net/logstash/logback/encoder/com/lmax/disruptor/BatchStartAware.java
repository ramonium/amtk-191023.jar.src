package net.logstash.logback.encoder.com.lmax.disruptor;

public interface BatchStartAware
{
    void onBatchStart(long batchSize);
}

package net.logstash.logback.encoder.com.lmax.disruptor;

public interface EventSequencer<T> extends DataProvider<T>, Sequenced
{

}

package javax.xml.bind;

import org.xml.sax.ContentHandler;

public interface UnmarshallerHandler extends ContentHandler {
  Object getResult() throws JAXBException, IllegalStateException;
}


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\jaxb-api-2.3.1.jar!\javax\xml\bind\UnmarshallerHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
package javax.xml.bind;

public interface ValidationEventHandler {
  boolean handleEvent(ValidationEvent paramValidationEvent);
}


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\jaxb-api-2.3.1.jar!\javax\xml\bind\ValidationEventHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package javax.xml.bind.helpers;
/*     */ 
/*     */ import java.net.URL;
/*     */ import javax.xml.bind.ValidationEvent;
/*     */ import javax.xml.bind.ValidationEventHandler;
/*     */ import javax.xml.bind.ValidationEventLocator;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultValidationEventHandler
/*     */   implements ValidationEventHandler
/*     */ {
/*     */   public boolean handleEvent(ValidationEvent event) {
/*  76 */     if (event == null) {
/*  77 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */     
/*  81 */     String severity = null;
/*  82 */     boolean retVal = false;
/*  83 */     switch (event.getSeverity()) {
/*     */       case 0:
/*  85 */         severity = Messages.format("DefaultValidationEventHandler.Warning");
/*  86 */         retVal = true;
/*     */         break;
/*     */       case 1:
/*  89 */         severity = Messages.format("DefaultValidationEventHandler.Error");
/*  90 */         retVal = false;
/*     */         break;
/*     */       case 2:
/*  93 */         severity = Messages.format("DefaultValidationEventHandler.FatalError");
/*  94 */         retVal = false;
/*     */         break;
/*     */       
/*     */       default:
/*  98 */         assert false : Messages.format("DefaultValidationEventHandler.UnrecognizedSeverity", 
/*  99 */             Integer.valueOf(event.getSeverity()));
/*     */         break;
/*     */     } 
/*     */     
/* 103 */     String location = getLocation(event);
/*     */     
/* 105 */     System.out.println(
/* 106 */         Messages.format("DefaultValidationEventHandler.SeverityMessage", severity, event
/*     */           
/* 108 */           .getMessage(), location));
/*     */ 
/*     */ 
/*     */     
/* 112 */     return retVal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getLocation(ValidationEvent event) {
/* 120 */     StringBuffer msg = new StringBuffer();
/*     */     
/* 122 */     ValidationEventLocator locator = event.getLocator();
/*     */     
/* 124 */     if (locator != null) {
/*     */       
/* 126 */       URL url = locator.getURL();
/* 127 */       Object obj = locator.getObject();
/* 128 */       Node node = locator.getNode();
/* 129 */       int line = locator.getLineNumber();
/*     */       
/* 131 */       if (url != null || line != -1) {
/* 132 */         msg.append("line " + line);
/* 133 */         if (url != null)
/* 134 */           msg.append(" of " + url); 
/* 135 */       } else if (obj != null) {
/* 136 */         msg.append(" obj: " + obj.toString());
/* 137 */       } else if (node != null) {
/* 138 */         msg.append(" node: " + node.toString());
/*     */       } 
/*     */     } else {
/* 141 */       msg.append(Messages.format("DefaultValidationEventHandler.LocationUnavailable"));
/*     */     } 
/*     */     
/* 144 */     return msg.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\jaxb-api-2.3.1.jar!\javax\xml\bind\helpers\DefaultValidationEventHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
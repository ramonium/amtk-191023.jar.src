package javax.xml.bind;

public interface PrintConversionEvent extends ValidationEvent {}


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\jaxb-api-2.3.1.jar!\javax\xml\bind\PrintConversionEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
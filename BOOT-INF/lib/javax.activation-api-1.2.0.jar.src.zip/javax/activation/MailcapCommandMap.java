/*     */ package javax.activation;
/*     */ 
/*     */ import com.sun.activation.registries.LogSupport;
/*     */ import com.sun.activation.registries.MailcapFile;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MailcapCommandMap
/*     */   extends CommandMap
/*     */ {
/*     */   private MailcapFile[] DB;
/*     */   private static final int PROG = 0;
/*     */   private static final String confDir;
/*     */   
/*     */   static {
/* 150 */     String dir = null;
/*     */     try {
/* 152 */       dir = AccessController.<String>doPrivileged(new PrivilegedAction<String>()
/*     */           {
/*     */             public Object run() {
/* 155 */               String home = System.getProperty("java.home");
/* 156 */               String newdir = home + File.separator + "conf";
/* 157 */               File conf = new File(newdir);
/* 158 */               if (conf.exists()) {
/* 159 */                 return newdir + File.separator;
/*     */               }
/* 161 */               return home + File.separator + "lib" + File.separator;
/*     */             }
/*     */           });
/* 164 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 167 */     confDir = dir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MailcapCommandMap() {
/* 175 */     List<MailcapFile> dbv = new ArrayList(5);
/* 176 */     MailcapFile mf = null;
/* 177 */     dbv.add(null);
/*     */     
/* 179 */     LogSupport.log("MailcapCommandMap: load HOME");
/*     */     try {
/* 181 */       String user_home = System.getProperty("user.home");
/*     */       
/* 183 */       if (user_home != null) {
/* 184 */         String path = user_home + File.separator + ".mailcap";
/* 185 */         mf = loadFile(path);
/* 186 */         if (mf != null)
/* 187 */           dbv.add(mf); 
/*     */       } 
/* 189 */     } catch (SecurityException securityException) {}
/*     */     
/* 191 */     LogSupport.log("MailcapCommandMap: load SYS");
/*     */     
/*     */     try {
/* 194 */       if (confDir != null) {
/* 195 */         mf = loadFile(confDir + "mailcap");
/* 196 */         if (mf != null)
/* 197 */           dbv.add(mf); 
/*     */       } 
/* 199 */     } catch (SecurityException securityException) {}
/*     */     
/* 201 */     LogSupport.log("MailcapCommandMap: load JAR");
/*     */     
/* 203 */     loadAllResources(dbv, "META-INF/mailcap");
/*     */     
/* 205 */     LogSupport.log("MailcapCommandMap: load DEF");
/* 206 */     mf = loadResource("/META-INF/mailcap.default");
/*     */     
/* 208 */     if (mf != null) {
/* 209 */       dbv.add(mf);
/*     */     }
/* 211 */     this.DB = new MailcapFile[dbv.size()];
/* 212 */     this.DB = dbv.<MailcapFile>toArray(this.DB);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MailcapFile loadResource(String name) {
/* 219 */     InputStream clis = null;
/*     */     try {
/* 221 */       clis = SecuritySupport.getResourceAsStream(getClass(), name);
/* 222 */       if (clis != null) {
/* 223 */         MailcapFile mf = new MailcapFile(clis);
/* 224 */         if (LogSupport.isLoggable()) {
/* 225 */           LogSupport.log("MailcapCommandMap: successfully loaded mailcap file: " + name);
/*     */         }
/* 227 */         return mf;
/*     */       } 
/* 229 */       if (LogSupport.isLoggable()) {
/* 230 */         LogSupport.log("MailcapCommandMap: not loading mailcap file: " + name);
/*     */       }
/*     */     }
/* 233 */     catch (IOException e) {
/* 234 */       if (LogSupport.isLoggable())
/* 235 */         LogSupport.log("MailcapCommandMap: can't load " + name, e); 
/* 236 */     } catch (SecurityException sex) {
/* 237 */       if (LogSupport.isLoggable())
/* 238 */         LogSupport.log("MailcapCommandMap: can't load " + name, sex); 
/*     */     } finally {
/*     */       try {
/* 241 */         if (clis != null)
/* 242 */           clis.close(); 
/* 243 */       } catch (IOException iOException) {}
/*     */     } 
/* 245 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadAllResources(List<MailcapFile> v, String name) {
/* 252 */     boolean anyLoaded = false;
/*     */     try {
/*     */       URL[] urls;
/* 255 */       ClassLoader cld = null;
/*     */       
/* 257 */       cld = SecuritySupport.getContextClassLoader();
/* 258 */       if (cld == null)
/* 259 */         cld = getClass().getClassLoader(); 
/* 260 */       if (cld != null) {
/* 261 */         urls = SecuritySupport.getResources(cld, name);
/*     */       } else {
/* 263 */         urls = SecuritySupport.getSystemResources(name);
/* 264 */       }  if (urls != null) {
/* 265 */         if (LogSupport.isLoggable())
/* 266 */           LogSupport.log("MailcapCommandMap: getResources"); 
/* 267 */         for (int i = 0; i < urls.length; i++) {
/* 268 */           URL url = urls[i];
/* 269 */           InputStream clis = null;
/* 270 */           if (LogSupport.isLoggable());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 304 */     catch (Exception ex) {
/* 305 */       if (LogSupport.isLoggable()) {
/* 306 */         LogSupport.log("MailcapCommandMap: can't load " + name, ex);
/*     */       }
/*     */     } 
/*     */     
/* 310 */     if (!anyLoaded) {
/* 311 */       if (LogSupport.isLoggable())
/* 312 */         LogSupport.log("MailcapCommandMap: !anyLoaded"); 
/* 313 */       MailcapFile mf = loadResource("/" + name);
/* 314 */       if (mf != null) {
/* 315 */         v.add(mf);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private MailcapFile loadFile(String name) {
/* 323 */     MailcapFile mtf = null;
/*     */     
/*     */     try {
/* 326 */       mtf = new MailcapFile(name);
/* 327 */     } catch (IOException iOException) {}
/*     */ 
/*     */     
/* 330 */     return mtf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MailcapCommandMap(String fileName) throws IOException {
/* 341 */     this();
/*     */     
/* 343 */     if (LogSupport.isLoggable())
/* 344 */       LogSupport.log("MailcapCommandMap: load PROG from " + fileName); 
/* 345 */     if (this.DB[0] == null) {
/* 346 */       this.DB[0] = new MailcapFile(fileName);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MailcapCommandMap(InputStream is) {
/* 358 */     this();
/*     */     
/* 360 */     LogSupport.log("MailcapCommandMap: load PROG");
/* 361 */     if (this.DB[0] == null) {
/*     */       try {
/* 363 */         this.DB[0] = new MailcapFile(is);
/* 364 */       } catch (IOException iOException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized CommandInfo[] getPreferredCommands(String mimeType) {
/* 384 */     List cmdList = new ArrayList();
/* 385 */     if (mimeType != null)
/* 386 */       mimeType = mimeType.toLowerCase(Locale.ENGLISH); 
/*     */     int i;
/* 388 */     for (i = 0; i < this.DB.length; i++) {
/* 389 */       if (this.DB[i] != null) {
/*     */         
/* 391 */         Map cmdMap = this.DB[i].getMailcapList(mimeType);
/* 392 */         if (cmdMap != null) {
/* 393 */           appendPrefCmdsToList(cmdMap, cmdList);
/*     */         }
/*     */       } 
/*     */     } 
/* 397 */     for (i = 0; i < this.DB.length; i++) {
/* 398 */       if (this.DB[i] != null) {
/*     */         
/* 400 */         Map cmdMap = this.DB[i].getMailcapFallbackList(mimeType);
/* 401 */         if (cmdMap != null)
/* 402 */           appendPrefCmdsToList(cmdMap, cmdList); 
/*     */       } 
/*     */     } 
/* 405 */     CommandInfo[] cmdInfos = new CommandInfo[cmdList.size()];
/* 406 */     cmdInfos = (CommandInfo[])cmdList.toArray((Object[])cmdInfos);
/*     */     
/* 408 */     return cmdInfos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void appendPrefCmdsToList(Map cmdHash, List<CommandInfo> cmdList) {
/* 415 */     Iterator<String> verb_enum = cmdHash.keySet().iterator();
/*     */     
/* 417 */     while (verb_enum.hasNext()) {
/* 418 */       String verb = verb_enum.next();
/* 419 */       if (!checkForVerb(cmdList, verb)) {
/* 420 */         List<String> cmdList2 = (List)cmdHash.get(verb);
/* 421 */         String className = cmdList2.get(0);
/* 422 */         cmdList.add(new CommandInfo(verb, className));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkForVerb(List cmdList, String verb) {
/* 432 */     Iterator<CommandInfo> ee = cmdList.iterator();
/* 433 */     while (ee.hasNext()) {
/*     */       
/* 435 */       String enum_verb = ((CommandInfo)ee.next()).getCommandName();
/* 436 */       if (enum_verb.equals(verb))
/* 437 */         return true; 
/*     */     } 
/* 439 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized CommandInfo[] getAllCommands(String mimeType) {
/* 450 */     List cmdList = new ArrayList();
/* 451 */     if (mimeType != null)
/* 452 */       mimeType = mimeType.toLowerCase(Locale.ENGLISH); 
/*     */     int i;
/* 454 */     for (i = 0; i < this.DB.length; i++) {
/* 455 */       if (this.DB[i] != null) {
/*     */         
/* 457 */         Map cmdMap = this.DB[i].getMailcapList(mimeType);
/* 458 */         if (cmdMap != null) {
/* 459 */           appendCmdsToList(cmdMap, cmdList);
/*     */         }
/*     */       } 
/*     */     } 
/* 463 */     for (i = 0; i < this.DB.length; i++) {
/* 464 */       if (this.DB[i] != null) {
/*     */         
/* 466 */         Map cmdMap = this.DB[i].getMailcapFallbackList(mimeType);
/* 467 */         if (cmdMap != null)
/* 468 */           appendCmdsToList(cmdMap, cmdList); 
/*     */       } 
/*     */     } 
/* 471 */     CommandInfo[] cmdInfos = new CommandInfo[cmdList.size()];
/* 472 */     cmdInfos = (CommandInfo[])cmdList.toArray((Object[])cmdInfos);
/*     */     
/* 474 */     return cmdInfos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void appendCmdsToList(Map typeHash, List<CommandInfo> cmdList) {
/* 481 */     Iterator<String> verb_enum = typeHash.keySet().iterator();
/*     */     
/* 483 */     while (verb_enum.hasNext()) {
/* 484 */       String verb = verb_enum.next();
/* 485 */       List cmdList2 = (List)typeHash.get(verb);
/* 486 */       Iterator<String> cmd_enum = cmdList2.iterator();
/*     */       
/* 488 */       while (cmd_enum.hasNext()) {
/* 489 */         String cmd = cmd_enum.next();
/* 490 */         cmdList.add(new CommandInfo(verb, cmd));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized CommandInfo getCommand(String mimeType, String cmdName) {
/* 505 */     if (mimeType != null)
/* 506 */       mimeType = mimeType.toLowerCase(Locale.ENGLISH); 
/*     */     int i;
/* 508 */     for (i = 0; i < this.DB.length; i++) {
/* 509 */       if (this.DB[i] != null) {
/*     */         
/* 511 */         Map cmdMap = this.DB[i].getMailcapList(mimeType);
/* 512 */         if (cmdMap != null) {
/*     */           
/* 514 */           List<String> v = (List)cmdMap.get(cmdName);
/* 515 */           if (v != null) {
/* 516 */             String cmdClassName = v.get(0);
/*     */             
/* 518 */             if (cmdClassName != null) {
/* 519 */               return new CommandInfo(cmdName, cmdClassName);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 525 */     for (i = 0; i < this.DB.length; i++) {
/* 526 */       if (this.DB[i] != null) {
/*     */         
/* 528 */         Map cmdMap = this.DB[i].getMailcapFallbackList(mimeType);
/* 529 */         if (cmdMap != null) {
/*     */           
/* 531 */           List<String> v = (List)cmdMap.get(cmdName);
/* 532 */           if (v != null) {
/* 533 */             String cmdClassName = v.get(0);
/*     */             
/* 535 */             if (cmdClassName != null)
/* 536 */               return new CommandInfo(cmdName, cmdClassName); 
/*     */           } 
/*     */         } 
/*     */       } 
/* 540 */     }  return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void addMailcap(String mail_cap) {
/* 554 */     LogSupport.log("MailcapCommandMap: add to PROG");
/* 555 */     if (this.DB[0] == null) {
/* 556 */       this.DB[0] = new MailcapFile();
/*     */     }
/* 558 */     this.DB[0].appendToMailcap(mail_cap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized DataContentHandler createDataContentHandler(String mimeType) {
/* 569 */     if (LogSupport.isLoggable()) {
/* 570 */       LogSupport.log("MailcapCommandMap: createDataContentHandler for " + mimeType);
/*     */     }
/* 572 */     if (mimeType != null)
/* 573 */       mimeType = mimeType.toLowerCase(Locale.ENGLISH); 
/*     */     int i;
/* 575 */     for (i = 0; i < this.DB.length; i++) {
/* 576 */       if (this.DB[i] != null) {
/*     */         
/* 578 */         if (LogSupport.isLoggable())
/* 579 */           LogSupport.log("  search DB #" + i); 
/* 580 */         Map cmdMap = this.DB[i].getMailcapList(mimeType);
/* 581 */         if (cmdMap != null) {
/* 582 */           List<String> v = (List)cmdMap.get("content-handler");
/* 583 */           if (v != null) {
/* 584 */             String name = v.get(0);
/* 585 */             DataContentHandler dch = getDataContentHandler(name);
/* 586 */             if (dch != null) {
/* 587 */               return dch;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 593 */     for (i = 0; i < this.DB.length; i++) {
/* 594 */       if (this.DB[i] != null) {
/*     */         
/* 596 */         if (LogSupport.isLoggable())
/* 597 */           LogSupport.log("  search fallback DB #" + i); 
/* 598 */         Map cmdMap = this.DB[i].getMailcapFallbackList(mimeType);
/* 599 */         if (cmdMap != null) {
/* 600 */           List<String> v = (List)cmdMap.get("content-handler");
/* 601 */           if (v != null) {
/* 602 */             String name = v.get(0);
/* 603 */             DataContentHandler dch = getDataContentHandler(name);
/* 604 */             if (dch != null)
/* 605 */               return dch; 
/*     */           } 
/*     */         } 
/*     */       } 
/* 609 */     }  return null;
/*     */   }
/*     */   
/*     */   private DataContentHandler getDataContentHandler(String name) {
/* 613 */     if (LogSupport.isLoggable())
/* 614 */       LogSupport.log("    got content-handler"); 
/* 615 */     if (LogSupport.isLoggable())
/* 616 */       LogSupport.log("      class " + name); 
/*     */     try {
/* 618 */       ClassLoader cld = null;
/*     */       
/* 620 */       cld = SecuritySupport.getContextClassLoader();
/* 621 */       if (cld == null)
/* 622 */         cld = getClass().getClassLoader(); 
/* 623 */       Class<?> cl = null;
/*     */       try {
/* 625 */         cl = cld.loadClass(name);
/* 626 */       } catch (Exception ex) {
/*     */         
/* 628 */         cl = Class.forName(name);
/*     */       } 
/* 630 */       if (cl != null)
/* 631 */         return (DataContentHandler)cl.newInstance(); 
/* 632 */     } catch (IllegalAccessException e) {
/* 633 */       if (LogSupport.isLoggable())
/* 634 */         LogSupport.log("Can't load DCH " + name, e); 
/* 635 */     } catch (ClassNotFoundException e) {
/* 636 */       if (LogSupport.isLoggable())
/* 637 */         LogSupport.log("Can't load DCH " + name, e); 
/* 638 */     } catch (InstantiationException e) {
/* 639 */       if (LogSupport.isLoggable())
/* 640 */         LogSupport.log("Can't load DCH " + name, e); 
/*     */     } 
/* 642 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized String[] getMimeTypes() {
/* 652 */     List<String> mtList = new ArrayList();
/*     */     
/* 654 */     for (int i = 0; i < this.DB.length; i++) {
/* 655 */       if (this.DB[i] != null) {
/*     */         
/* 657 */         String[] ts = this.DB[i].getMimeTypes();
/* 658 */         if (ts != null)
/* 659 */           for (int j = 0; j < ts.length; j++) {
/*     */             
/* 661 */             if (!mtList.contains(ts[j])) {
/* 662 */               mtList.add(ts[j]);
/*     */             }
/*     */           }  
/*     */       } 
/*     */     } 
/* 667 */     String[] mts = new String[mtList.size()];
/* 668 */     mts = mtList.<String>toArray(mts);
/*     */     
/* 670 */     return mts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized String[] getNativeCommands(String mimeType) {
/* 689 */     List<String> cmdList = new ArrayList();
/* 690 */     if (mimeType != null) {
/* 691 */       mimeType = mimeType.toLowerCase(Locale.ENGLISH);
/*     */     }
/* 693 */     for (int i = 0; i < this.DB.length; i++) {
/* 694 */       if (this.DB[i] != null) {
/*     */         
/* 696 */         String[] arrayOfString = this.DB[i].getNativeCommands(mimeType);
/* 697 */         if (arrayOfString != null)
/* 698 */           for (int j = 0; j < arrayOfString.length; j++) {
/*     */             
/* 700 */             if (!cmdList.contains(arrayOfString[j])) {
/* 701 */               cmdList.add(arrayOfString[j]);
/*     */             }
/*     */           }  
/*     */       } 
/*     */     } 
/* 706 */     String[] cmds = new String[cmdList.size()];
/* 707 */     cmds = cmdList.<String>toArray(cmds);
/*     */     
/* 709 */     return cmds;
/*     */   }
/*     */ }


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\javax.activation-api-1.2.0.jar!\javax\activation\MailcapCommandMap.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */
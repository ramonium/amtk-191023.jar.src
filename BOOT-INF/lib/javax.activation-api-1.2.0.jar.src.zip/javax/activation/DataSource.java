package javax.activation;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public interface DataSource {
  InputStream getInputStream() throws IOException;
  
  OutputStream getOutputStream() throws IOException;
  
  String getContentType();
  
  String getName();
}


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\javax.activation-api-1.2.0.jar!\javax\activation\DataSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */
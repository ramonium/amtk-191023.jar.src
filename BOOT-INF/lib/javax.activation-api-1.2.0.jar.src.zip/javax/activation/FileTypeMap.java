/*     */ package javax.activation;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FileTypeMap
/*     */ {
/*  65 */   private static FileTypeMap defaultMap = null;
/*  66 */   private static Map<ClassLoader, FileTypeMap> map = new WeakHashMap<ClassLoader, FileTypeMap>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getContentType(File paramFile);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getContentType(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setDefaultFileTypeMap(FileTypeMap fileTypeMap) {
/* 103 */     SecurityManager security = System.getSecurityManager();
/* 104 */     if (security != null) {
/*     */       
/*     */       try {
/* 107 */         security.checkSetFactory();
/* 108 */       } catch (SecurityException ex) {
/*     */ 
/*     */ 
/*     */         
/* 112 */         ClassLoader cl = FileTypeMap.class.getClassLoader();
/* 113 */         if (cl == null || cl.getParent() == null || cl != fileTypeMap
/* 114 */           .getClass().getClassLoader()) {
/* 115 */           throw ex;
/*     */         }
/*     */       } 
/*     */     }
/* 119 */     map.remove(SecuritySupport.getContextClassLoader());
/* 120 */     defaultMap = fileTypeMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized FileTypeMap getDefaultFileTypeMap() {
/* 133 */     if (defaultMap != null) {
/* 134 */       return defaultMap;
/*     */     }
/*     */     
/* 137 */     ClassLoader tccl = SecuritySupport.getContextClassLoader();
/* 138 */     FileTypeMap def = map.get(tccl);
/* 139 */     if (def == null) {
/* 140 */       def = new MimetypesFileTypeMap();
/* 141 */       map.put(tccl, def);
/*     */     } 
/* 143 */     return def;
/*     */   }
/*     */ }


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\javax.activation-api-1.2.0.jar!\javax\activation\FileTypeMap.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */
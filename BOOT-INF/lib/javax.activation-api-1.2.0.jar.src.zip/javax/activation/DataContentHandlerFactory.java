package javax.activation;

public interface DataContentHandlerFactory {
  DataContentHandler createDataContentHandler(String paramString);
}


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\javax.activation-api-1.2.0.jar!\javax\activation\DataContentHandlerFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */
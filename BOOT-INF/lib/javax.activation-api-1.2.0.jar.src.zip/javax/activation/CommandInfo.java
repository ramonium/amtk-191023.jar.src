/*     */ package javax.activation;
/*     */ 
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommandInfo
/*     */ {
/*     */   private String verb;
/*     */   private String className;
/*     */   
/*     */   public CommandInfo(String verb, String className) {
/*  73 */     this.verb = verb;
/*  74 */     this.className = className;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCommandName() {
/*  83 */     return this.verb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCommandClass() {
/*  97 */     return this.className;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getCommandObject(DataHandler dh, ClassLoader loader) throws IOException, ClassNotFoundException {
/* 141 */     Object new_bean = null;
/*     */ 
/*     */     
/* 144 */     new_bean = Beans.instantiate(loader, this.className);
/*     */ 
/*     */     
/* 147 */     if (new_bean != null) {
/* 148 */       if (new_bean instanceof CommandObject) {
/* 149 */         ((CommandObject)new_bean).setCommandContext(this.verb, dh);
/* 150 */       } else if (new_bean instanceof Externalizable && 
/* 151 */         dh != null) {
/* 152 */         InputStream is = dh.getInputStream();
/* 153 */         if (is != null) {
/* 154 */           ((Externalizable)new_bean).readExternal(new ObjectInputStream(is));
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 161 */     return new_bean;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Beans
/*     */   {
/*     */     static final Method instantiateMethod;
/*     */ 
/*     */     
/*     */     static {
/*     */       Method m;
/*     */       try {
/* 174 */         Class<?> c = Class.forName("java.beans.Beans");
/* 175 */         m = c.getDeclaredMethod("instantiate", new Class[] { ClassLoader.class, String.class });
/* 176 */       } catch (ClassNotFoundException e) {
/* 177 */         m = null;
/* 178 */       } catch (NoSuchMethodException e) {
/* 179 */         m = null;
/*     */       } 
/* 181 */       instantiateMethod = m;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static Object instantiate(ClassLoader loader, String cn) throws IOException, ClassNotFoundException {
/* 192 */       if (instantiateMethod != null) {
/*     */ 
/*     */         
/*     */         try {
/* 196 */           return instantiateMethod.invoke(null, new Object[] { loader, cn });
/* 197 */         } catch (InvocationTargetException e) {
/* 198 */           Exception exception = e;
/* 199 */         } catch (IllegalAccessException e) {
/* 200 */           Exception exception = e;
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 205 */         SecurityManager security = System.getSecurityManager();
/* 206 */         if (security != null) {
/*     */           
/* 208 */           String cname = cn.replace('/', '.');
/* 209 */           if (cname.startsWith("[")) {
/* 210 */             int b = cname.lastIndexOf('[') + 2;
/* 211 */             if (b > 1 && b < cname.length()) {
/* 212 */               cname = cname.substring(b);
/*     */             }
/*     */           } 
/* 215 */           int i = cname.lastIndexOf('.');
/* 216 */           if (i != -1) {
/* 217 */             security.checkPackageAccess(cname.substring(0, i));
/*     */           }
/*     */         } 
/*     */ 
/*     */         
/* 222 */         if (loader == null)
/*     */         {
/* 224 */           loader = AccessController.<ClassLoader>doPrivileged(new PrivilegedAction<ClassLoader>() {
/*     */                 public Object run() {
/* 226 */                   ClassLoader cl = null;
/*     */                   try {
/* 228 */                     cl = ClassLoader.getSystemClassLoader();
/* 229 */                   } catch (SecurityException securityException) {}
/* 230 */                   return cl;
/*     */                 }
/*     */               });
/*     */         }
/* 234 */         Class<?> beanClass = Class.forName(cn, true, loader);
/*     */         try {
/* 236 */           return beanClass.newInstance();
/* 237 */         } catch (Exception ex) {
/* 238 */           throw new ClassNotFoundException(beanClass + ": " + ex, ex);
/*     */         } 
/*     */       } 
/*     */       
/* 242 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\javax.activation-api-1.2.0.jar!\javax\activation\CommandInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */
/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2014 Red Hat, Inc., and individual contributors
 * as indicated by the @author tags.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.undertow.servlet.compat.rewrite;

import java.util.Map;

/**
 * The configuration for a {@link io.undertow.servlet.compat.rewrite.RewriteHandler}. This should be produced by
 *  {@link RewriteConfigFactory}
 *
 * @author Stuart Douglas
 */
public class RewriteConfig {

    /**
     * The rewrite rules that the valve will use.
     */
    private final  RewriteRule[] rules;

    /**
     * Maps to be used by the rules.
     */
    private final Map<String, RewriteMap> maps;

    public RewriteConfig(RewriteRule[] rules, Map<String, RewriteMap> maps) {
        this.rules = rules;
        this.maps = maps;
    }

    public RewriteRule[] getRules() {
        return rules;
    }

    public Map<String, RewriteMap> getMaps() {
        return maps;
    }


    public String toString() {
        StringBuffer buffer = new StringBuffer();
        // FIXME: Output maps if possible
        for (int i = 0; i < rules.length; i++) {
            for (int j = 0; j < rules[i].getConditions().length; j++) {
                buffer.append(rules[i].getConditions()[j].toString()).append("\r\n");
            }
            buffer.append(rules[i].toString()).append("\r\n").append("\r\n");
        }
        return buffer.toString();
    }
}

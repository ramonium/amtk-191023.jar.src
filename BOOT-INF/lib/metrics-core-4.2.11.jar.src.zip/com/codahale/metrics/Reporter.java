package com.codahale.metrics;

import java.io.Closeable;

/*
 * A tag interface to indicate that a class is a Reporter.
 */
public interface Reporter extends Closeable {

}

/**
 * Liquibase specific code.
 */
package tech.jhipster.config.liquibase;

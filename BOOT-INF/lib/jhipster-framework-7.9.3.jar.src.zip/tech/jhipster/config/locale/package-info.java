/**
 * Locale specific code.
 */
package tech.jhipster.config.locale;

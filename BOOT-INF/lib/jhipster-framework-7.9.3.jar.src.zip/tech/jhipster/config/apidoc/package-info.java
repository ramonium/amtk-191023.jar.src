/**
 * Springfox configuraiton to generate ApiDocs documentation.
 */
package tech.jhipster.config.apidoc;

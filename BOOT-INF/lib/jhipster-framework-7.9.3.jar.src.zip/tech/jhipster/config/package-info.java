/**
 * JHipster configuration classes and helpers.
 */
package tech.jhipster.config;

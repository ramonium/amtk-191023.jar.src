/**
 * Utilities for JPA criteria classes, used for filtering data on the back-end.
 */
package tech.jhipster.service.filter;

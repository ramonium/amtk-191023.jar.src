/**
 * Security classes and helpers used in JHipster applications.
 */
package tech.jhipster.security;

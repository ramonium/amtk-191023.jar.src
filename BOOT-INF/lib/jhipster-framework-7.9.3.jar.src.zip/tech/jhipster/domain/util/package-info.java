/**
 * Utilities for JHipster domain objects.
 */
package tech.jhipster.domain.util;

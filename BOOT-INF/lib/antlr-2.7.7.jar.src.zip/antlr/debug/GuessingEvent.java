/*    */ package antlr.debug;
/*    */ 
/*    */ public abstract class GuessingEvent
/*    */   extends Event {
/*    */   private int guessing;
/*    */   
/*    */   public GuessingEvent(Object paramObject) {
/*  8 */     super(paramObject);
/*    */   }
/*    */   public GuessingEvent(Object paramObject, int paramInt) {
/* 11 */     super(paramObject, paramInt);
/*    */   }
/*    */   public int getGuessing() {
/* 14 */     return this.guessing;
/*    */   }
/*    */   void setGuessing(int paramInt) {
/* 17 */     this.guessing = paramInt;
/*    */   }
/*    */   
/*    */   void setValues(int paramInt1, int paramInt2) {
/* 21 */     setValues(paramInt1);
/* 22 */     setGuessing(paramInt2);
/*    */   }
/*    */ }


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\debug\GuessingEvent.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
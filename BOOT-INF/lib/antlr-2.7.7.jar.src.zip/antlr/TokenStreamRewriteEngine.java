/*     */ package antlr;
/*     */ 
/*     */ import antlr.ASdebug.ASDebugStream;
/*     */ import antlr.ASdebug.IASDebugStream;
/*     */ import antlr.ASdebug.TokenOffsetInfo;
/*     */ import antlr.collections.impl.BitSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TokenStreamRewriteEngine
/*     */   implements TokenStream, IASDebugStream
/*     */ {
/*     */   public static final int MIN_TOKEN_INDEX = 0;
/*     */   public static final String DEFAULT_PROGRAM_NAME = "default";
/*     */   public static final int PROGRAM_INIT_SIZE = 100;
/*     */   protected List tokens;
/*     */   
/*     */   static class RewriteOperation
/*     */   {
/*     */     protected int index;
/*     */     protected String text;
/*     */     
/*     */     protected RewriteOperation(int param1Int, String param1String) {
/*  70 */       this.index = param1Int;
/*  71 */       this.text = param1String;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int execute(StringBuffer param1StringBuffer) {
/*  77 */       return this.index;
/*     */     }
/*     */     public String toString() {
/*  80 */       String str = getClass().getName();
/*  81 */       int i = str.indexOf('$');
/*  82 */       str = str.substring(i + 1, str.length());
/*  83 */       return str + "@" + this.index + '"' + this.text + '"';
/*     */     }
/*     */   }
/*     */   
/*     */   static class InsertBeforeOp extends RewriteOperation {
/*     */     public InsertBeforeOp(int param1Int, String param1String) {
/*  89 */       super(param1Int, param1String);
/*     */     }
/*     */     public int execute(StringBuffer param1StringBuffer) {
/*  92 */       param1StringBuffer.append(this.text);
/*  93 */       return this.index;
/*     */     }
/*     */   }
/*     */   
/*     */   static class ReplaceOp
/*     */     extends RewriteOperation
/*     */   {
/*     */     protected int lastIndex;
/*     */     
/*     */     public ReplaceOp(int param1Int1, int param1Int2, String param1String) {
/* 103 */       super(param1Int1, param1String);
/* 104 */       this.lastIndex = param1Int2;
/*     */     }
/*     */     public int execute(StringBuffer param1StringBuffer) {
/* 107 */       if (this.text != null) {
/* 108 */         param1StringBuffer.append(this.text);
/*     */       }
/* 110 */       return this.lastIndex + 1;
/*     */     }
/*     */   }
/*     */   
/*     */   static class DeleteOp extends ReplaceOp {
/*     */     public DeleteOp(int param1Int1, int param1Int2) {
/* 116 */       super(param1Int1, param1Int2, null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   protected Map programs = null;
/*     */ 
/*     */   
/* 133 */   protected Map lastRewriteTokenIndexes = null;
/*     */ 
/*     */   
/* 136 */   protected int index = 0;
/*     */ 
/*     */   
/*     */   protected TokenStream stream;
/*     */ 
/*     */   
/* 142 */   protected BitSet discardMask = new BitSet();
/*     */   
/*     */   public TokenStreamRewriteEngine(TokenStream paramTokenStream) {
/* 145 */     this(paramTokenStream, 1000);
/*     */   }
/*     */   
/*     */   public TokenStreamRewriteEngine(TokenStream paramTokenStream, int paramInt) {
/* 149 */     this.stream = paramTokenStream;
/* 150 */     this.tokens = new ArrayList(paramInt);
/* 151 */     this.programs = new HashMap();
/* 152 */     this.programs.put("default", new ArrayList(100));
/*     */     
/* 154 */     this.lastRewriteTokenIndexes = new HashMap();
/*     */   }
/*     */ 
/*     */   
/*     */   public Token nextToken() throws TokenStreamException {
/*     */     TokenWithIndex tokenWithIndex;
/*     */     do {
/* 161 */       tokenWithIndex = (TokenWithIndex)this.stream.nextToken();
/* 162 */       if (tokenWithIndex == null)
/* 163 */         continue;  tokenWithIndex.setIndex(this.index);
/* 164 */       if (tokenWithIndex.getType() != 1) {
/* 165 */         this.tokens.add(tokenWithIndex);
/*     */       }
/* 167 */       this.index++;
/*     */     }
/* 169 */     while (tokenWithIndex != null && this.discardMask.member(tokenWithIndex.getType()));
/* 170 */     return tokenWithIndex;
/*     */   }
/*     */   
/*     */   public void rollback(int paramInt) {
/* 174 */     rollback("default", paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rollback(String paramString, int paramInt) {
/* 182 */     List list = (List)this.programs.get(paramString);
/* 183 */     if (list != null) {
/* 184 */       this.programs.put(paramString, list.subList(0, paramInt));
/*     */     }
/*     */   }
/*     */   
/*     */   public void deleteProgram() {
/* 189 */     deleteProgram("default");
/*     */   }
/*     */ 
/*     */   
/*     */   public void deleteProgram(String paramString) {
/* 194 */     rollback(paramString, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addToSortedRewriteList(RewriteOperation paramRewriteOperation) {
/* 200 */     addToSortedRewriteList("default", paramRewriteOperation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addToSortedRewriteList(String paramString, RewriteOperation paramRewriteOperation) {
/* 247 */     List list = getProgram(paramString);
/*     */     
/* 249 */     Comparator comparator = new Comparator(this) {
/*     */         public int compare(Object param1Object1, Object param1Object2) {
/* 251 */           TokenStreamRewriteEngine.RewriteOperation rewriteOperation1 = (TokenStreamRewriteEngine.RewriteOperation)param1Object1;
/* 252 */           TokenStreamRewriteEngine.RewriteOperation rewriteOperation2 = (TokenStreamRewriteEngine.RewriteOperation)param1Object2;
/* 253 */           if (rewriteOperation1.index < rewriteOperation2.index) return -1; 
/* 254 */           if (rewriteOperation1.index > rewriteOperation2.index) return 1; 
/* 255 */           return 0;
/*     */         } private final TokenStreamRewriteEngine this$0;
/*     */       };
/* 258 */     int i = Collections.binarySearch(list, paramRewriteOperation, comparator);
/*     */ 
/*     */     
/* 261 */     if (i >= 0) {
/*     */ 
/*     */       
/* 264 */       for (; i >= 0; i--) {
/* 265 */         RewriteOperation rewriteOperation = list.get(i);
/* 266 */         if (rewriteOperation.index < paramRewriteOperation.index) {
/*     */           break;
/*     */         }
/*     */       } 
/* 270 */       i++;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 277 */       if (paramRewriteOperation instanceof ReplaceOp) {
/* 278 */         boolean bool = false;
/*     */         
/*     */         int j;
/* 281 */         for (j = i; j < list.size(); j++) {
/* 282 */           RewriteOperation rewriteOperation = list.get(i);
/* 283 */           if (rewriteOperation.index != paramRewriteOperation.index) {
/*     */             break;
/*     */           }
/* 286 */           if (rewriteOperation instanceof ReplaceOp) {
/* 287 */             list.set(i, paramRewriteOperation);
/* 288 */             bool = true;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 293 */         if (!bool)
/*     */         {
/* 295 */           list.add(j, paramRewriteOperation);
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 300 */         list.add(i, paramRewriteOperation);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 305 */       list.add(-i - 1, paramRewriteOperation);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void insertAfter(Token paramToken, String paramString) {
/* 311 */     insertAfter("default", paramToken, paramString);
/*     */   }
/*     */   
/*     */   public void insertAfter(int paramInt, String paramString) {
/* 315 */     insertAfter("default", paramInt, paramString);
/*     */   }
/*     */   
/*     */   public void insertAfter(String paramString1, Token paramToken, String paramString2) {
/* 319 */     insertAfter(paramString1, ((TokenWithIndex)paramToken).getIndex(), paramString2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void insertAfter(String paramString1, int paramInt, String paramString2) {
/* 324 */     insertBefore(paramString1, paramInt + 1, paramString2);
/*     */   }
/*     */   
/*     */   public void insertBefore(Token paramToken, String paramString) {
/* 328 */     insertBefore("default", paramToken, paramString);
/*     */   }
/*     */   
/*     */   public void insertBefore(int paramInt, String paramString) {
/* 332 */     insertBefore("default", paramInt, paramString);
/*     */   }
/*     */   
/*     */   public void insertBefore(String paramString1, Token paramToken, String paramString2) {
/* 336 */     insertBefore(paramString1, ((TokenWithIndex)paramToken).getIndex(), paramString2);
/*     */   }
/*     */   
/*     */   public void insertBefore(String paramString1, int paramInt, String paramString2) {
/* 340 */     addToSortedRewriteList(paramString1, new InsertBeforeOp(paramInt, paramString2));
/*     */   }
/*     */   
/*     */   public void replace(int paramInt, String paramString) {
/* 344 */     replace("default", paramInt, paramInt, paramString);
/*     */   }
/*     */   
/*     */   public void replace(int paramInt1, int paramInt2, String paramString) {
/* 348 */     replace("default", paramInt1, paramInt2, paramString);
/*     */   }
/*     */   
/*     */   public void replace(Token paramToken, String paramString) {
/* 352 */     replace("default", paramToken, paramToken, paramString);
/*     */   }
/*     */   
/*     */   public void replace(Token paramToken1, Token paramToken2, String paramString) {
/* 356 */     replace("default", paramToken1, paramToken2, paramString);
/*     */   }
/*     */   
/*     */   public void replace(String paramString1, int paramInt1, int paramInt2, String paramString2) {
/* 360 */     addToSortedRewriteList(new ReplaceOp(paramInt1, paramInt2, paramString2));
/*     */   }
/*     */   
/*     */   public void replace(String paramString1, Token paramToken1, Token paramToken2, String paramString2) {
/* 364 */     replace(paramString1, ((TokenWithIndex)paramToken1).getIndex(), ((TokenWithIndex)paramToken2).getIndex(), paramString2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void delete(int paramInt) {
/* 371 */     delete("default", paramInt, paramInt);
/*     */   }
/*     */   
/*     */   public void delete(int paramInt1, int paramInt2) {
/* 375 */     delete("default", paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public void delete(Token paramToken) {
/* 379 */     delete("default", paramToken, paramToken);
/*     */   }
/*     */   
/*     */   public void delete(Token paramToken1, Token paramToken2) {
/* 383 */     delete("default", paramToken1, paramToken2);
/*     */   }
/*     */   
/*     */   public void delete(String paramString, int paramInt1, int paramInt2) {
/* 387 */     replace(paramString, paramInt1, paramInt2, (String)null);
/*     */   }
/*     */   
/*     */   public void delete(String paramString, Token paramToken1, Token paramToken2) {
/* 391 */     replace(paramString, paramToken1, paramToken2, (String)null);
/*     */   }
/*     */   
/*     */   public void discard(int paramInt) {
/* 395 */     this.discardMask.add(paramInt);
/*     */   }
/*     */   
/*     */   public TokenWithIndex getToken(int paramInt) {
/* 399 */     return this.tokens.get(paramInt);
/*     */   }
/*     */   
/*     */   public int getTokenStreamSize() {
/* 403 */     return this.tokens.size();
/*     */   }
/*     */   
/*     */   public String toOriginalString() {
/* 407 */     return toOriginalString(0, getTokenStreamSize() - 1);
/*     */   }
/*     */   
/*     */   public String toOriginalString(int paramInt1, int paramInt2) {
/* 411 */     StringBuffer stringBuffer = new StringBuffer();
/* 412 */     for (int i = paramInt1; i >= 0 && i <= paramInt2 && i < this.tokens.size(); i++) {
/* 413 */       stringBuffer.append(getToken(i).getText());
/*     */     }
/* 415 */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   public String toString() {
/* 419 */     return toString(0, getTokenStreamSize() - 1);
/*     */   }
/*     */   
/*     */   public String toString(String paramString) {
/* 423 */     return toString(paramString, 0, getTokenStreamSize() - 1);
/*     */   }
/*     */   
/*     */   public String toString(int paramInt1, int paramInt2) {
/* 427 */     return toString("default", paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public String toString(String paramString, int paramInt1, int paramInt2) {
/* 431 */     List list = (List)this.programs.get(paramString);
/* 432 */     if (list == null || list.size() == 0) {
/* 433 */       return toOriginalString(paramInt1, paramInt2);
/*     */     }
/* 435 */     StringBuffer stringBuffer = new StringBuffer();
/*     */ 
/*     */     
/* 438 */     byte b1 = 0;
/*     */     
/* 440 */     int i = paramInt1;
/*     */ 
/*     */     
/* 443 */     while (i >= 0 && i <= paramInt2 && i < this.tokens.size()) {
/*     */ 
/*     */ 
/*     */       
/* 447 */       if (b1 < list.size()) {
/* 448 */         RewriteOperation rewriteOperation = list.get(b1);
/*     */ 
/*     */ 
/*     */         
/* 452 */         while (rewriteOperation.index < i && b1 < list.size()) {
/* 453 */           b1++;
/* 454 */           if (b1 < list.size()) {
/* 455 */             rewriteOperation = list.get(b1);
/*     */           }
/*     */         } 
/*     */ 
/*     */         
/* 460 */         while (i == rewriteOperation.index && b1 < list.size()) {
/*     */           
/* 462 */           i = rewriteOperation.execute(stringBuffer);
/*     */           
/* 464 */           b1++;
/* 465 */           if (b1 < list.size()) {
/* 466 */             rewriteOperation = list.get(b1);
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 471 */       if (i <= paramInt2) {
/* 472 */         stringBuffer.append(getToken(i).getText());
/* 473 */         i++;
/*     */       } 
/*     */     } 
/*     */     
/* 477 */     for (byte b2 = b1; b2 < list.size(); b2++) {
/* 478 */       RewriteOperation rewriteOperation = list.get(b2);
/*     */       
/* 480 */       if (rewriteOperation.index >= size()) {
/* 481 */         rewriteOperation.execute(stringBuffer);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 487 */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   public String toDebugString() {
/* 491 */     return toDebugString(0, getTokenStreamSize() - 1);
/*     */   }
/*     */   
/*     */   public String toDebugString(int paramInt1, int paramInt2) {
/* 495 */     StringBuffer stringBuffer = new StringBuffer();
/* 496 */     for (int i = paramInt1; i >= 0 && i <= paramInt2 && i < this.tokens.size(); i++) {
/* 497 */       stringBuffer.append(getToken(i));
/*     */     }
/* 499 */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   public int getLastRewriteTokenIndex() {
/* 503 */     return getLastRewriteTokenIndex("default");
/*     */   }
/*     */   
/*     */   protected int getLastRewriteTokenIndex(String paramString) {
/* 507 */     Integer integer = (Integer)this.lastRewriteTokenIndexes.get(paramString);
/* 508 */     if (integer == null) {
/* 509 */       return -1;
/*     */     }
/* 511 */     return integer.intValue();
/*     */   }
/*     */   
/*     */   protected void setLastRewriteTokenIndex(String paramString, int paramInt) {
/* 515 */     this.lastRewriteTokenIndexes.put(paramString, new Integer(paramInt));
/*     */   }
/*     */   
/*     */   protected List getProgram(String paramString) {
/* 519 */     List list = (List)this.programs.get(paramString);
/* 520 */     if (list == null) {
/* 521 */       list = initializeProgram(paramString);
/*     */     }
/* 523 */     return list;
/*     */   }
/*     */   
/*     */   private List initializeProgram(String paramString) {
/* 527 */     ArrayList arrayList = new ArrayList(100);
/* 528 */     this.programs.put(paramString, arrayList);
/* 529 */     return arrayList;
/*     */   }
/*     */   
/*     */   public int size() {
/* 533 */     return this.tokens.size();
/*     */   }
/*     */   
/*     */   public int index() {
/* 537 */     return this.index;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getEntireText() {
/* 542 */     return ASDebugStream.getEntireText(this.stream);
/*     */   }
/*     */ 
/*     */   
/*     */   public TokenOffsetInfo getOffsetInfo(Token paramToken) {
/* 547 */     return ASDebugStream.getOffsetInfo(this.stream, paramToken);
/*     */   }
/*     */ }


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\TokenStreamRewriteEngine.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package antlr;
/*     */ 
/*     */ import antlr.collections.impl.BitSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MismatchedCharException
/*     */   extends RecognitionException
/*     */ {
/*     */   public static final int CHAR = 1;
/*     */   public static final int NOT_CHAR = 2;
/*     */   public static final int RANGE = 3;
/*     */   public static final int NOT_RANGE = 4;
/*     */   public static final int SET = 5;
/*     */   public static final int NOT_SET = 6;
/*     */   public int mismatchType;
/*     */   public int foundChar;
/*     */   public int expecting;
/*     */   public int upper;
/*     */   public BitSet set;
/*     */   public CharScanner scanner;
/*     */   
/*     */   public MismatchedCharException() {
/*  43 */     super("Mismatched char");
/*     */   }
/*     */ 
/*     */   
/*     */   public MismatchedCharException(char paramChar1, char paramChar2, char paramChar3, boolean paramBoolean, CharScanner paramCharScanner) {
/*  48 */     super("Mismatched char", paramCharScanner.getFilename(), paramCharScanner.getLine(), paramCharScanner.getColumn());
/*  49 */     this.mismatchType = paramBoolean ? 4 : 3;
/*  50 */     this.foundChar = paramChar1;
/*  51 */     this.expecting = paramChar2;
/*  52 */     this.upper = paramChar3;
/*  53 */     this.scanner = paramCharScanner;
/*     */   }
/*     */ 
/*     */   
/*     */   public MismatchedCharException(char paramChar1, char paramChar2, boolean paramBoolean, CharScanner paramCharScanner) {
/*  58 */     super("Mismatched char", paramCharScanner.getFilename(), paramCharScanner.getLine(), paramCharScanner.getColumn());
/*  59 */     this.mismatchType = paramBoolean ? 2 : 1;
/*  60 */     this.foundChar = paramChar1;
/*  61 */     this.expecting = paramChar2;
/*  62 */     this.scanner = paramCharScanner;
/*     */   }
/*     */ 
/*     */   
/*     */   public MismatchedCharException(char paramChar, BitSet paramBitSet, boolean paramBoolean, CharScanner paramCharScanner) {
/*  67 */     super("Mismatched char", paramCharScanner.getFilename(), paramCharScanner.getLine(), paramCharScanner.getColumn());
/*  68 */     this.mismatchType = paramBoolean ? 6 : 5;
/*  69 */     this.foundChar = paramChar;
/*  70 */     this.set = paramBitSet;
/*  71 */     this.scanner = paramCharScanner;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessage() {
/*     */     int[] arrayOfInt;
/*     */     byte b;
/*  78 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/*  80 */     switch (this.mismatchType)
/*     */     { case 1:
/*  82 */         stringBuffer.append("expecting "); appendCharName(stringBuffer, this.expecting);
/*  83 */         stringBuffer.append(", found "); appendCharName(stringBuffer, this.foundChar);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 117 */         return stringBuffer.toString();case 2: stringBuffer.append("expecting anything but '"); appendCharName(stringBuffer, this.expecting); stringBuffer.append("'; got it anyway"); return stringBuffer.toString();case 3: case 4: stringBuffer.append("expecting token "); if (this.mismatchType == 4) stringBuffer.append("NOT ");  stringBuffer.append("in range: "); appendCharName(stringBuffer, this.expecting); stringBuffer.append(".."); appendCharName(stringBuffer, this.upper); stringBuffer.append(", found "); appendCharName(stringBuffer, this.foundChar); return stringBuffer.toString();case 5: case 6: stringBuffer.append("expecting " + ((this.mismatchType == 6) ? "NOT " : "") + "one of ("); arrayOfInt = this.set.toArray(); for (b = 0; b < arrayOfInt.length; b++) appendCharName(stringBuffer, arrayOfInt[b]);  stringBuffer.append("), found "); appendCharName(stringBuffer, this.foundChar); return stringBuffer.toString(); }  stringBuffer.append(super.getMessage()); return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void appendCharName(StringBuffer paramStringBuffer, int paramInt) {
/* 124 */     switch (paramInt) {
/*     */       
/*     */       case 65535:
/* 127 */         paramStringBuffer.append("'<EOF>'");
/*     */         return;
/*     */       case 10:
/* 130 */         paramStringBuffer.append("'\\n'");
/*     */         return;
/*     */       case 13:
/* 133 */         paramStringBuffer.append("'\\r'");
/*     */         return;
/*     */       case 9:
/* 136 */         paramStringBuffer.append("'\\t'");
/*     */         return;
/*     */     } 
/* 139 */     paramStringBuffer.append('\'');
/* 140 */     paramStringBuffer.append((char)paramInt);
/* 141 */     paramStringBuffer.append('\'');
/*     */   }
/*     */ }


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\MismatchedCharException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LLkParser
/*    */   extends Parser
/*    */ {
/*    */   int k;
/*    */   
/*    */   public LLkParser(int paramInt) {
/* 21 */     this.k = paramInt;
/*    */   }
/*    */   
/*    */   public LLkParser(ParserSharedInputState paramParserSharedInputState, int paramInt) {
/* 25 */     super(paramParserSharedInputState);
/* 26 */     this.k = paramInt;
/*    */   }
/*    */   
/*    */   public LLkParser(TokenBuffer paramTokenBuffer, int paramInt) {
/* 30 */     this.k = paramInt;
/* 31 */     setTokenBuffer(paramTokenBuffer);
/*    */   }
/*    */   
/*    */   public LLkParser(TokenStream paramTokenStream, int paramInt) {
/* 35 */     this.k = paramInt;
/* 36 */     TokenBuffer tokenBuffer = new TokenBuffer(paramTokenStream);
/* 37 */     setTokenBuffer(tokenBuffer);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void consume() throws TokenStreamException {
/* 48 */     this.inputState.input.consume();
/*    */   }
/*    */   
/*    */   public int LA(int paramInt) throws TokenStreamException {
/* 52 */     return this.inputState.input.LA(paramInt);
/*    */   }
/*    */   
/*    */   public Token LT(int paramInt) throws TokenStreamException {
/* 56 */     return this.inputState.input.LT(paramInt);
/*    */   }
/*    */   
/*    */   private void trace(String paramString1, String paramString2) throws TokenStreamException {
/* 60 */     traceIndent();
/* 61 */     System.out.print(paramString1 + paramString2 + ((this.inputState.guessing > 0) ? "; [guessing]" : "; "));
/* 62 */     for (byte b = 1; b <= this.k; b++) {
/* 63 */       if (b != 1) {
/* 64 */         System.out.print(", ");
/*    */       }
/* 66 */       if (LT(b) != null) {
/* 67 */         System.out.print("LA(" + b + ")==" + LT(b).getText());
/*    */       } else {
/*    */         
/* 70 */         System.out.print("LA(" + b + ")==null");
/*    */       } 
/*    */     } 
/* 73 */     System.out.println("");
/*    */   }
/*    */   
/*    */   public void traceIn(String paramString) throws TokenStreamException {
/* 77 */     this.traceDepth++;
/* 78 */     trace("> ", paramString);
/*    */   }
/*    */   
/*    */   public void traceOut(String paramString) throws TokenStreamException {
/* 82 */     trace("< ", paramString);
/* 83 */     this.traceDepth--;
/*    */   }
/*    */ }


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\LLkParser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
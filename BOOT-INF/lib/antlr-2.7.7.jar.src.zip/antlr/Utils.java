/*    */ package antlr;
/*    */ 
/*    */ public class Utils {
/*    */   private static boolean useSystemExit = true;
/*    */   
/*    */   static {
/*  7 */     if ("true".equalsIgnoreCase(System.getProperty("ANTLR_DO_NOT_EXIT", "false")))
/*  8 */       useSystemExit = false; 
/*  9 */     if ("true".equalsIgnoreCase(System.getProperty("ANTLR_USE_DIRECT_CLASS_LOADING", "false")))
/* 10 */       useDirectClassLoading = true; 
/*    */   }
/*    */   private static boolean useDirectClassLoading = false;
/*    */   
/*    */   public static Class loadClass(String paramString) throws ClassNotFoundException {
/*    */     try {
/* 16 */       ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/* 17 */       if (!useDirectClassLoading && classLoader != null) {
/* 18 */         return classLoader.loadClass(paramString);
/*    */       }
/* 20 */       return Class.forName(paramString);
/*    */     }
/* 22 */     catch (Exception exception) {
/* 23 */       return Class.forName(paramString);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static Object createInstanceOf(String paramString) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
/* 28 */     return loadClass(paramString).newInstance();
/*    */   }
/*    */   
/*    */   public static void error(String paramString) {
/* 32 */     if (useSystemExit)
/* 33 */       System.exit(1); 
/* 34 */     throw new RuntimeException("ANTLR Panic: " + paramString);
/*    */   }
/*    */   
/*    */   public static void error(String paramString, Throwable paramThrowable) {
/* 38 */     if (useSystemExit)
/* 39 */       System.exit(1); 
/* 40 */     throw new RuntimeException("ANTLR Panic", paramThrowable);
/*    */   }
/*    */ }


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\Utils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
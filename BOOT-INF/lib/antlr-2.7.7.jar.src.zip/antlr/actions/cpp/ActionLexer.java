/*      */ package antlr.actions.cpp;
/*      */ 
/*      */ import antlr.ActionTransInfo;
/*      */ import antlr.ByteBuffer;
/*      */ import antlr.CharBuffer;
/*      */ import antlr.CharScanner;
/*      */ import antlr.CharStreamException;
/*      */ import antlr.CharStreamIOException;
/*      */ import antlr.CodeGenerator;
/*      */ import antlr.InputBuffer;
/*      */ import antlr.LexerSharedInputState;
/*      */ import antlr.NoViableAltForCharException;
/*      */ import antlr.RecognitionException;
/*      */ import antlr.RuleBlock;
/*      */ import antlr.Token;
/*      */ import antlr.TokenStream;
/*      */ import antlr.TokenStreamException;
/*      */ import antlr.TokenStreamIOException;
/*      */ import antlr.TokenStreamRecognitionException;
/*      */ import antlr.Tool;
/*      */ import antlr.collections.impl.BitSet;
/*      */ import antlr.collections.impl.Vector;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.StringReader;
/*      */ import java.util.Hashtable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ActionLexer
/*      */   extends CharScanner
/*      */   implements ActionLexerTokenTypes, TokenStream
/*      */ {
/*      */   protected RuleBlock currentRule;
/*      */   protected CodeGenerator generator;
/*   59 */   protected int lineOffset = 0;
/*      */   
/*      */   private Tool antlrTool;
/*      */   
/*      */   ActionTransInfo transInfo;
/*      */ 
/*      */   
/*      */   public ActionLexer(String paramString, RuleBlock paramRuleBlock, CodeGenerator paramCodeGenerator, ActionTransInfo paramActionTransInfo) {
/*   67 */     this(new StringReader(paramString));
/*   68 */     this.currentRule = paramRuleBlock;
/*   69 */     this.generator = paramCodeGenerator;
/*   70 */     this.transInfo = paramActionTransInfo;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setLineOffset(int paramInt) {
/*   75 */     setLine(paramInt);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTool(Tool paramTool) {
/*   80 */     this.antlrTool = paramTool;
/*      */   }
/*      */ 
/*      */   
/*      */   public void reportError(RecognitionException paramRecognitionException) {
/*   85 */     this.antlrTool.error("Syntax error in action: " + paramRecognitionException, getFilename(), getLine(), getColumn());
/*      */   }
/*      */ 
/*      */   
/*      */   public void reportError(String paramString) {
/*   90 */     this.antlrTool.error(paramString, getFilename(), getLine(), getColumn());
/*      */   }
/*      */ 
/*      */   
/*      */   public void reportWarning(String paramString) {
/*   95 */     if (getFilename() == null) {
/*   96 */       this.antlrTool.warning(paramString);
/*      */     } else {
/*   98 */       this.antlrTool.warning(paramString, getFilename(), getLine(), getColumn());
/*      */     } 
/*      */   } public ActionLexer(InputStream paramInputStream) {
/*  101 */     this((InputBuffer)new ByteBuffer(paramInputStream));
/*      */   }
/*      */   public ActionLexer(Reader paramReader) {
/*  104 */     this((InputBuffer)new CharBuffer(paramReader));
/*      */   }
/*      */   public ActionLexer(InputBuffer paramInputBuffer) {
/*  107 */     this(new LexerSharedInputState(paramInputBuffer));
/*      */   }
/*      */   public ActionLexer(LexerSharedInputState paramLexerSharedInputState) {
/*  110 */     super(paramLexerSharedInputState);
/*  111 */     this.caseSensitiveLiterals = true;
/*  112 */     setCaseSensitive(true);
/*  113 */     this.literals = new Hashtable();
/*      */   }
/*      */   
/*      */   public Token nextToken() throws TokenStreamException {
/*  117 */     Token token = null;
/*      */     
/*      */     while (true) {
/*  120 */       Object object = null;
/*  121 */       int i = 0;
/*  122 */       resetText();
/*      */       
/*      */       try {
/*  125 */         if (LA(1) >= '\003' && LA(1) <= 'ÿ')
/*  126 */         { mACTION(true);
/*  127 */           token = this._returnToken;
/*      */            }
/*      */         
/*  130 */         else if (LA(1) == Character.MAX_VALUE) { uponEOF(); this._returnToken = makeToken(1); }
/*  131 */         else { throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */         
/*  134 */         if (this._returnToken == null)
/*  135 */           continue;  i = this._returnToken.getType();
/*  136 */         this._returnToken.setType(i);
/*  137 */         return this._returnToken;
/*      */       }
/*  139 */       catch (RecognitionException recognitionException) {
/*  140 */         throw new TokenStreamRecognitionException(recognitionException);
/*      */       
/*      */       }
/*  143 */       catch (CharStreamException charStreamException) {
/*  144 */         if (charStreamException instanceof CharStreamIOException) {
/*  145 */           throw new TokenStreamIOException(((CharStreamIOException)charStreamException).io);
/*      */         }
/*      */         
/*  148 */         throw new TokenStreamException(charStreamException.getMessage());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void mACTION(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  155 */     Token token = null; int i = this.text.length();
/*  156 */     byte b1 = 4;
/*      */ 
/*      */ 
/*      */     
/*  160 */     byte b2 = 0;
/*      */     
/*      */     while (true) {
/*  163 */       switch (LA(1)) {
/*      */         
/*      */         case '#':
/*  166 */           mAST_ITEM(false);
/*      */           break;
/*      */ 
/*      */         
/*      */         case '$':
/*  171 */           mTEXT_ITEM(false);
/*      */           break;
/*      */         
/*      */         default:
/*  175 */           if (_tokenSet_0.member(LA(1))) {
/*  176 */             mSTUFF(false);
/*      */             break;
/*      */           } 
/*  179 */           if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/*  182 */       b2++;
/*      */     } 
/*      */     
/*  185 */     if (paramBoolean && token == null && b1 != -1) {
/*  186 */       token = makeToken(b1);
/*  187 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  189 */     this._returnToken = token;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void mSTUFF(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  196 */     Token token = null; int i = this.text.length();
/*  197 */     byte b = 5;
/*      */ 
/*      */     
/*  200 */     switch (LA(1)) {
/*      */       
/*      */       case '"':
/*  203 */         mSTRING(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\'':
/*  208 */         mCHAR(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\n':
/*  213 */         match('\n');
/*  214 */         newline();
/*      */         break;
/*      */       
/*      */       default:
/*  218 */         if (LA(1) == '/' && (LA(2) == '*' || LA(2) == '/')) {
/*  219 */           mCOMMENT(false); break;
/*      */         } 
/*  221 */         if (LA(1) == '\r' && LA(2) == '\n') {
/*  222 */           match("\r\n");
/*  223 */           newline(); break;
/*      */         } 
/*  225 */         if (LA(1) == '\\' && LA(2) == '#') {
/*  226 */           match('\\');
/*  227 */           match('#');
/*  228 */           this.text.setLength(i); this.text.append("#"); break;
/*      */         } 
/*  230 */         if (LA(1) == '/' && _tokenSet_1.member(LA(2))) {
/*  231 */           match('/');
/*      */           
/*  233 */           match(_tokenSet_1);
/*      */           break;
/*      */         } 
/*  236 */         if (LA(1) == '\r') {
/*  237 */           match('\r');
/*  238 */           newline(); break;
/*      */         } 
/*  240 */         if (_tokenSet_2.member(LA(1))) {
/*      */           
/*  242 */           match(_tokenSet_2);
/*      */           
/*      */           break;
/*      */         } 
/*  246 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/*  249 */     if (paramBoolean && token == null && b != -1) {
/*  250 */       token = makeToken(b);
/*  251 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  253 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mAST_ITEM(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  257 */     Token token1 = null; int i = this.text.length();
/*  258 */     byte b = 6;
/*      */     
/*  260 */     Token token2 = null;
/*  261 */     Token token3 = null;
/*  262 */     Token token4 = null;
/*      */     
/*  264 */     if (LA(1) == '#' && LA(2) == '(') {
/*  265 */       int j = this.text.length();
/*  266 */       match('#');
/*  267 */       this.text.setLength(j);
/*  268 */       mTREE(true);
/*  269 */       token2 = this._returnToken;
/*      */     }
/*  271 */     else if (LA(1) == '#' && _tokenSet_3.member(LA(2))) {
/*  272 */       int j = this.text.length();
/*  273 */       match('#');
/*  274 */       this.text.setLength(j);
/*      */       
/*  276 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/*  279 */           mWS(false); break;
/*      */         case ':': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '_': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h':
/*      */         case 'i':
/*      */         case 'j':
/*      */         case 'k':
/*      */         case 'l':
/*      */         case 'm':
/*      */         case 'n':
/*      */         case 'o':
/*      */         case 'p':
/*      */         case 'q':
/*      */         case 'r':
/*      */         case 's':
/*      */         case 't':
/*      */         case 'u':
/*      */         case 'v':
/*      */         case 'w':
/*      */         case 'x':
/*      */         case 'y':
/*      */         case 'z':
/*      */           break;
/*      */         default:
/*  301 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */       
/*  305 */       mID(true);
/*  306 */       token3 = this._returnToken;
/*      */       
/*  308 */       String str1 = token3.getText();
/*  309 */       String str2 = this.generator.mapTreeId(token3.getText(), this.transInfo);
/*      */ 
/*      */       
/*  312 */       if (str2 != null && !str1.equals(str2)) {
/*      */         
/*  314 */         this.text.setLength(i); this.text.append(str2);
/*      */ 
/*      */       
/*      */       }
/*  318 */       else if (str1.equals("if") || str1.equals("define") || str1.equals("ifdef") || str1.equals("ifndef") || str1.equals("else") || str1.equals("elif") || str1.equals("endif") || str1.equals("warning") || str1.equals("error") || str1.equals("ident") || str1.equals("pragma") || str1.equals("include")) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  331 */         this.text.setLength(i); this.text.append("#" + str1);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  336 */       if (_tokenSet_4.member(LA(1))) {
/*  337 */         mWS(false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  344 */       if (LA(1) == '=') {
/*  345 */         mVAR_ASSIGN(false);
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*  352 */     else if (LA(1) == '#' && LA(2) == '[') {
/*  353 */       int j = this.text.length();
/*  354 */       match('#');
/*  355 */       this.text.setLength(j);
/*  356 */       mAST_CONSTRUCTOR(true);
/*  357 */       token4 = this._returnToken;
/*      */     }
/*  359 */     else if (LA(1) == '#' && LA(2) == '#') {
/*  360 */       match("##");
/*      */       
/*  362 */       if (this.currentRule != null) {
/*      */         
/*  364 */         String str = this.currentRule.getRuleName() + "_AST";
/*  365 */         this.text.setLength(i); this.text.append(str);
/*      */         
/*  367 */         if (this.transInfo != null) {
/*  368 */           this.transInfo.refRuleRoot = str;
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/*  373 */         reportWarning("\"##\" not valid in this context");
/*  374 */         this.text.setLength(i); this.text.append("##");
/*      */       } 
/*      */ 
/*      */       
/*  378 */       if (_tokenSet_4.member(LA(1))) {
/*  379 */         mWS(false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  386 */       if (LA(1) == '=') {
/*  387 */         mVAR_ASSIGN(false);
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  395 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/*  398 */     if (paramBoolean && token1 == null && b != -1) {
/*  399 */       token1 = makeToken(b);
/*  400 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  402 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mTEXT_ITEM(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  406 */     Token token1 = null; int i = this.text.length();
/*  407 */     byte b = 7;
/*      */     
/*  409 */     Token token2 = null;
/*  410 */     Token token3 = null;
/*  411 */     Token token4 = null;
/*  412 */     Token token5 = null;
/*  413 */     Token token6 = null;
/*  414 */     Token token7 = null;
/*      */     
/*  416 */     if (LA(1) == '$' && LA(2) == 'F' && LA(3) == 'O') {
/*  417 */       match("$FOLLOW");
/*      */       
/*  419 */       if (_tokenSet_5.member(LA(1)) && _tokenSet_6.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/*      */         
/*  421 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*  424 */             mWS(false);
/*      */             break;
/*      */ 
/*      */           
/*      */           case '(':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  433 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/*  437 */         match('(');
/*  438 */         mTEXT_ARG(true);
/*  439 */         token6 = this._returnToken;
/*  440 */         match(')');
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  447 */       String str1 = this.currentRule.getRuleName();
/*  448 */       if (token6 != null) {
/*  449 */         str1 = token6.getText();
/*      */       }
/*  451 */       String str2 = this.generator.getFOLLOWBitSet(str1, 1);
/*      */       
/*  453 */       if (str2 == null) {
/*  454 */         reportError("$FOLLOW(" + str1 + ")" + ": unknown rule or bad lookahead computation");
/*      */       }
/*      */       else {
/*      */         
/*  458 */         this.text.setLength(i); this.text.append(str2);
/*      */       }
/*      */     
/*      */     }
/*  462 */     else if (LA(1) == '$' && LA(2) == 'F' && LA(3) == 'I') {
/*  463 */       match("$FIRST");
/*      */       
/*  465 */       if (_tokenSet_5.member(LA(1)) && _tokenSet_6.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/*      */         
/*  467 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*  470 */             mWS(false);
/*      */             break;
/*      */ 
/*      */           
/*      */           case '(':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  479 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/*  483 */         match('(');
/*  484 */         mTEXT_ARG(true);
/*  485 */         token7 = this._returnToken;
/*  486 */         match(')');
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  493 */       String str1 = this.currentRule.getRuleName();
/*  494 */       if (token7 != null) {
/*  495 */         str1 = token7.getText();
/*      */       }
/*  497 */       String str2 = this.generator.getFIRSTBitSet(str1, 1);
/*      */       
/*  499 */       if (str2 == null) {
/*  500 */         reportError("$FIRST(" + str1 + ")" + ": unknown rule or bad lookahead computation");
/*      */       }
/*      */       else {
/*      */         
/*  504 */         this.text.setLength(i); this.text.append(str2);
/*      */       }
/*      */     
/*      */     }
/*  508 */     else if (LA(1) == '$' && LA(2) == 'a') {
/*  509 */       match("$append");
/*      */       
/*  511 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/*  514 */           mWS(false);
/*      */           break;
/*      */ 
/*      */         
/*      */         case '(':
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  523 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */       
/*  527 */       match('(');
/*  528 */       mTEXT_ARG(true);
/*  529 */       token2 = this._returnToken;
/*  530 */       match(')');
/*      */       
/*  532 */       String str = "text += " + token2.getText();
/*  533 */       this.text.setLength(i); this.text.append(str);
/*      */     
/*      */     }
/*  536 */     else if (LA(1) == '$' && LA(2) == 's') {
/*  537 */       match("$set");
/*      */       
/*  539 */       if (LA(1) == 'T' && LA(2) == 'e') {
/*  540 */         match("Text");
/*      */         
/*  542 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*  545 */             mWS(false);
/*      */             break;
/*      */ 
/*      */           
/*      */           case '(':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  554 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/*  558 */         match('(');
/*  559 */         mTEXT_ARG(true);
/*  560 */         token3 = this._returnToken;
/*  561 */         match(')');
/*      */ 
/*      */         
/*  564 */         String str = "{ text.erase(_begin); text += " + token3.getText() + "; }";
/*  565 */         this.text.setLength(i); this.text.append(str);
/*      */       
/*      */       }
/*  568 */       else if (LA(1) == 'T' && LA(2) == 'o') {
/*  569 */         match("Token");
/*      */         
/*  571 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*  574 */             mWS(false);
/*      */             break;
/*      */ 
/*      */           
/*      */           case '(':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  583 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/*  587 */         match('(');
/*  588 */         mTEXT_ARG(true);
/*  589 */         token4 = this._returnToken;
/*  590 */         match(')');
/*      */         
/*  592 */         String str = "_token = " + token4.getText();
/*  593 */         this.text.setLength(i); this.text.append(str);
/*      */       
/*      */       }
/*  596 */       else if (LA(1) == 'T' && LA(2) == 'y') {
/*  597 */         match("Type");
/*      */         
/*  599 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*  602 */             mWS(false);
/*      */             break;
/*      */ 
/*      */           
/*      */           case '(':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  611 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/*  615 */         match('(');
/*  616 */         mTEXT_ARG(true);
/*  617 */         token5 = this._returnToken;
/*  618 */         match(')');
/*      */         
/*  620 */         String str = "_ttype = " + token5.getText();
/*  621 */         this.text.setLength(i); this.text.append(str);
/*      */       }
/*      */       else {
/*      */         
/*  625 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  630 */     else if (LA(1) == '$' && LA(2) == 'g') {
/*  631 */       match("$getText");
/*      */       
/*  633 */       this.text.setLength(i); this.text.append("text.substr(_begin,text.length()-_begin)");
/*      */     }
/*      */     else {
/*      */       
/*  637 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/*  640 */     if (paramBoolean && token1 == null && b != -1) {
/*  641 */       token1 = makeToken(b);
/*  642 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  644 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mCOMMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  648 */     Token token = null; int i = this.text.length();
/*  649 */     byte b = 19;
/*      */ 
/*      */     
/*  652 */     if (LA(1) == '/' && LA(2) == '/') {
/*  653 */       mSL_COMMENT(false);
/*      */     }
/*  655 */     else if (LA(1) == '/' && LA(2) == '*') {
/*  656 */       mML_COMMENT(false);
/*      */     } else {
/*      */       
/*  659 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/*  662 */     if (paramBoolean && token == null && b != -1) {
/*  663 */       token = makeToken(b);
/*  664 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  666 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mSTRING(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  670 */     Token token = null; int i = this.text.length();
/*  671 */     byte b = 23;
/*      */ 
/*      */     
/*  674 */     match('"');
/*      */ 
/*      */     
/*      */     while (true) {
/*  678 */       while (LA(1) == '\\') {
/*  679 */         mESC(false);
/*      */       }
/*  681 */       if (_tokenSet_7.member(LA(1))) {
/*  682 */         matchNot('"');
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/*  690 */     match('"');
/*  691 */     if (paramBoolean && token == null && b != -1) {
/*  692 */       token = makeToken(b);
/*  693 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  695 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mCHAR(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  699 */     Token token = null; int i = this.text.length();
/*  700 */     byte b = 22;
/*      */ 
/*      */     
/*  703 */     match('\'');
/*      */     
/*  705 */     if (LA(1) == '\\') {
/*  706 */       mESC(false);
/*      */     }
/*  708 */     else if (_tokenSet_8.member(LA(1))) {
/*  709 */       matchNot('\'');
/*      */     } else {
/*      */       
/*  712 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/*  716 */     match('\'');
/*  717 */     if (paramBoolean && token == null && b != -1) {
/*  718 */       token = makeToken(b);
/*  719 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  721 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mTREE(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  725 */     Token token1 = null; int i = this.text.length();
/*  726 */     byte b = 8;
/*      */     
/*  728 */     Token token2 = null;
/*  729 */     Token token3 = null;
/*      */     
/*  731 */     StringBuffer stringBuffer = new StringBuffer();
/*  732 */     boolean bool = false;
/*  733 */     Vector vector = new Vector(10);
/*      */ 
/*      */     
/*  736 */     int j = this.text.length();
/*  737 */     match('(');
/*  738 */     this.text.setLength(j);
/*      */     
/*  740 */     switch (LA(1)) { case '\t': case '\n':
/*      */       case '\r':
/*      */       case ' ':
/*  743 */         j = this.text.length();
/*  744 */         mWS(false);
/*  745 */         this.text.setLength(j); break;
/*      */       case '"': case '#': case '(': case ':': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g':
/*      */       case 'h':
/*      */       case 'i':
/*      */       case 'j':
/*      */       case 'k':
/*      */       case 'l':
/*      */       case 'm':
/*      */       case 'n':
/*      */       case 'o':
/*      */       case 'p':
/*      */       case 'q':
/*      */       case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/*      */         break;
/*      */       default:
/*  768 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */     
/*  772 */     j = this.text.length();
/*  773 */     mTREE_ELEMENT(true);
/*  774 */     this.text.setLength(j);
/*  775 */     token2 = this._returnToken;
/*      */     
/*  777 */     vector.appendElement(this.generator.processStringForASTConstructor(token2.getText()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  782 */     switch (LA(1)) { case '\t': case '\n':
/*      */       case '\r':
/*      */       case ' ':
/*  785 */         j = this.text.length();
/*  786 */         mWS(false);
/*  787 */         this.text.setLength(j);
/*      */         break;
/*      */ 
/*      */       
/*      */       case ')':
/*      */       case ',':
/*      */         break;
/*      */       
/*      */       default:
/*  796 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  803 */     while (LA(1) == ',') {
/*  804 */       j = this.text.length();
/*  805 */       match(',');
/*  806 */       this.text.setLength(j);
/*      */       
/*  808 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/*  811 */           j = this.text.length();
/*  812 */           mWS(false);
/*  813 */           this.text.setLength(j); break;
/*      */         case '"': case '#': case '(': case ':': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g':
/*      */         case 'h':
/*      */         case 'i':
/*      */         case 'j':
/*      */         case 'k':
/*      */         case 'l':
/*      */         case 'm':
/*      */         case 'n':
/*      */         case 'o':
/*      */         case 'p':
/*      */         case 'q':
/*      */         case 'r':
/*      */         case 's':
/*      */         case 't':
/*      */         case 'u':
/*      */         case 'v':
/*      */         case 'w':
/*      */         case 'x':
/*      */         case 'y':
/*      */         case 'z':
/*      */           break;
/*      */         default:
/*  836 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */       
/*  840 */       j = this.text.length();
/*  841 */       mTREE_ELEMENT(true);
/*  842 */       this.text.setLength(j);
/*  843 */       token3 = this._returnToken;
/*      */       
/*  845 */       vector.appendElement(this.generator.processStringForASTConstructor(token3.getText()));
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  850 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/*  853 */           j = this.text.length();
/*  854 */           mWS(false);
/*  855 */           this.text.setLength(j);
/*      */           continue;
/*      */ 
/*      */         
/*      */         case ')':
/*      */         case ',':
/*      */           continue; }
/*      */ 
/*      */       
/*  864 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  875 */     this.text.setLength(i); this.text.append(this.generator.getASTCreateString(vector));
/*  876 */     j = this.text.length();
/*  877 */     match(')');
/*  878 */     this.text.setLength(j);
/*  879 */     if (paramBoolean && token1 == null && b != -1) {
/*  880 */       token1 = makeToken(b);
/*  881 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  883 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mWS(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  887 */     Token token = null; int i = this.text.length();
/*  888 */     byte b1 = 28;
/*      */ 
/*      */ 
/*      */     
/*  892 */     byte b2 = 0;
/*      */     
/*      */     while (true) {
/*  895 */       if (LA(1) == '\r' && LA(2) == '\n') {
/*  896 */         match('\r');
/*  897 */         match('\n');
/*  898 */         newline();
/*      */       }
/*  900 */       else if (LA(1) == ' ') {
/*  901 */         match(' ');
/*      */       }
/*  903 */       else if (LA(1) == '\t') {
/*  904 */         match('\t');
/*      */       }
/*  906 */       else if (LA(1) == '\r') {
/*  907 */         match('\r');
/*  908 */         newline();
/*      */       }
/*  910 */       else if (LA(1) == '\n') {
/*  911 */         match('\n');
/*  912 */         newline();
/*      */       } else {
/*      */         
/*  915 */         if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/*  918 */       b2++;
/*      */     } 
/*      */     
/*  921 */     if (paramBoolean && token == null && b1 != -1) {
/*  922 */       token = makeToken(b1);
/*  923 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  925 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mID(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  929 */     Token token = null; int i = this.text.length();
/*  930 */     byte b = 17;
/*      */ 
/*      */ 
/*      */     
/*  934 */     switch (LA(1)) { case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j': case 'k': case 'l': case 'm': case 'n': case 'o': case 'p': case 'q': case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/*  943 */         matchRange('a', 'z'); break;
/*      */       case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q':
/*      */       case 'R':
/*      */       case 'S':
/*      */       case 'T':
/*      */       case 'U':
/*      */       case 'V':
/*      */       case 'W':
/*      */       case 'X':
/*      */       case 'Y':
/*      */       case 'Z':
/*  954 */         matchRange('A', 'Z');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '_':
/*  959 */         match('_');
/*      */         break;
/*      */ 
/*      */       
/*      */       case ':':
/*  964 */         match("::");
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/*  969 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  976 */     while (_tokenSet_9.member(LA(1))) {
/*      */       
/*  978 */       switch (LA(1)) { case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j': case 'k': case 'l': case 'm': case 'n': case 'o': case 'p': case 'q': case 'r':
/*      */         case 's':
/*      */         case 't':
/*      */         case 'u':
/*      */         case 'v':
/*      */         case 'w':
/*      */         case 'x':
/*      */         case 'y':
/*      */         case 'z':
/*  987 */           matchRange('a', 'z'); continue;
/*      */         case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q':
/*      */         case 'R':
/*      */         case 'S':
/*      */         case 'T':
/*      */         case 'U':
/*      */         case 'V':
/*      */         case 'W':
/*      */         case 'X':
/*      */         case 'Y':
/*      */         case 'Z':
/*  998 */           matchRange('A', 'Z'); continue;
/*      */         case '0': case '1': case '2': case '3': case '4':
/*      */         case '5':
/*      */         case '6':
/*      */         case '7':
/*      */         case '8':
/*      */         case '9':
/* 1005 */           matchRange('0', '9');
/*      */           continue;
/*      */ 
/*      */         
/*      */         case '_':
/* 1010 */           match('_');
/*      */           continue;
/*      */ 
/*      */         
/*      */         case ':':
/* 1015 */           match("::");
/*      */           continue; }
/*      */ 
/*      */ 
/*      */       
/* 1020 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1031 */     if (paramBoolean && token == null && b != -1) {
/* 1032 */       token = makeToken(b);
/* 1033 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1035 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mVAR_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1039 */     Token token = null; int i = this.text.length();
/* 1040 */     byte b = 18;
/*      */ 
/*      */     
/* 1043 */     match('=');
/*      */ 
/*      */ 
/*      */     
/* 1047 */     if (LA(1) != '=' && this.transInfo != null && this.transInfo.refRuleRoot != null) {
/* 1048 */       this.transInfo.assignToRoot = true;
/*      */     }
/*      */     
/* 1051 */     if (paramBoolean && token == null && b != -1) {
/* 1052 */       token = makeToken(b);
/* 1053 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1055 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mAST_CONSTRUCTOR(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1059 */     Token token1 = null; int i = this.text.length();
/* 1060 */     byte b = 10;
/*      */     
/* 1062 */     Token token2 = null;
/* 1063 */     Token token3 = null;
/*      */     
/* 1065 */     int j = this.text.length();
/* 1066 */     match('[');
/* 1067 */     this.text.setLength(j);
/*      */     
/* 1069 */     switch (LA(1)) { case '\t': case '\n':
/*      */       case '\r':
/*      */       case ' ':
/* 1072 */         j = this.text.length();
/* 1073 */         mWS(false);
/* 1074 */         this.text.setLength(j); break;
/*      */       case '"': case '#': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case ':': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e':
/*      */       case 'f':
/*      */       case 'g':
/*      */       case 'h':
/*      */       case 'i':
/*      */       case 'j':
/*      */       case 'k':
/*      */       case 'l':
/*      */       case 'm':
/*      */       case 'n':
/*      */       case 'o':
/*      */       case 'p':
/*      */       case 'q':
/*      */       case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/*      */         break;
/*      */       default:
/* 1099 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */     
/* 1103 */     j = this.text.length();
/* 1104 */     mAST_CTOR_ELEMENT(true);
/* 1105 */     this.text.setLength(j);
/* 1106 */     token2 = this._returnToken;
/*      */     
/* 1108 */     switch (LA(1)) { case '\t': case '\n':
/*      */       case '\r':
/*      */       case ' ':
/* 1111 */         j = this.text.length();
/* 1112 */         mWS(false);
/* 1113 */         this.text.setLength(j);
/*      */         break;
/*      */ 
/*      */       
/*      */       case ',':
/*      */       case ']':
/*      */         break;
/*      */       
/*      */       default:
/* 1122 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1127 */     switch (LA(1)) {
/*      */       
/*      */       case ',':
/* 1130 */         j = this.text.length();
/* 1131 */         match(',');
/* 1132 */         this.text.setLength(j);
/*      */         
/* 1134 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/* 1137 */             j = this.text.length();
/* 1138 */             mWS(false);
/* 1139 */             this.text.setLength(j); break;
/*      */           case '"': case '#': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case ':': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e':
/*      */           case 'f':
/*      */           case 'g':
/*      */           case 'h':
/*      */           case 'i':
/*      */           case 'j':
/*      */           case 'k':
/*      */           case 'l':
/*      */           case 'm':
/*      */           case 'n':
/*      */           case 'o':
/*      */           case 'p':
/*      */           case 'q':
/*      */           case 'r':
/*      */           case 's':
/*      */           case 't':
/*      */           case 'u':
/*      */           case 'v':
/*      */           case 'w':
/*      */           case 'x':
/*      */           case 'y':
/*      */           case 'z':
/*      */             break;
/*      */           default:
/* 1164 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/* 1168 */         j = this.text.length();
/* 1169 */         mAST_CTOR_ELEMENT(true);
/* 1170 */         this.text.setLength(j);
/* 1171 */         token3 = this._returnToken;
/*      */         
/* 1173 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/* 1176 */             j = this.text.length();
/* 1177 */             mWS(false);
/* 1178 */             this.text.setLength(j);
/*      */             break;
/*      */ 
/*      */           
/*      */           case ']':
/*      */             break; }
/*      */ 
/*      */ 
/*      */         
/* 1187 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case ']':
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 1199 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 1203 */     j = this.text.length();
/* 1204 */     match(']');
/* 1205 */     this.text.setLength(j);
/*      */ 
/*      */ 
/*      */     
/* 1209 */     String str = this.generator.processStringForASTConstructor(token2.getText());
/*      */ 
/*      */ 
/*      */     
/* 1213 */     if (token3 != null) {
/* 1214 */       str = str + "," + token3.getText();
/*      */     }
/* 1216 */     this.text.setLength(i); this.text.append(this.generator.getASTCreateString(null, str));
/*      */     
/* 1218 */     if (paramBoolean && token1 == null && b != -1) {
/* 1219 */       token1 = makeToken(b);
/* 1220 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1222 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mTEXT_ARG(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1226 */     Token token = null; int i = this.text.length();
/* 1227 */     byte b1 = 13;
/*      */ 
/*      */ 
/*      */     
/* 1231 */     switch (LA(1)) { case '\t': case '\n':
/*      */       case '\r':
/*      */       case ' ':
/* 1234 */         mWS(false); break;
/*      */       case '"': case '$': case '\'': case '+': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case ':': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '_': case 'a': case 'b': case 'c': case 'd': case 'e':
/*      */       case 'f':
/*      */       case 'g':
/*      */       case 'h':
/*      */       case 'i':
/*      */       case 'j':
/*      */       case 'k':
/*      */       case 'l':
/*      */       case 'm':
/*      */       case 'n':
/*      */       case 'o':
/*      */       case 'p':
/*      */       case 'q':
/*      */       case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/*      */         break;
/*      */       default:
/* 1259 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1264 */     byte b2 = 0;
/*      */     
/*      */     while (true) {
/* 1267 */       if (_tokenSet_10.member(LA(1)) && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 1268 */         mTEXT_ARG_ELEMENT(false);
/*      */         
/* 1270 */         if (_tokenSet_4.member(LA(1)) && _tokenSet_11.member(LA(2))) {
/* 1271 */           mWS(false);
/*      */         }
/* 1273 */         else if (!_tokenSet_11.member(LA(1))) {
/*      */ 
/*      */           
/* 1276 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1282 */         if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/* 1285 */       b2++;
/*      */     } 
/*      */     
/* 1288 */     if (paramBoolean && token == null && b1 != -1) {
/* 1289 */       token = makeToken(b1);
/* 1290 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1292 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mTREE_ELEMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1296 */     Token token1 = null; int i = this.text.length();
/* 1297 */     byte b = 9;
/*      */     
/* 1299 */     Token token2 = null;
/*      */ 
/*      */     
/* 1302 */     switch (LA(1)) {
/*      */       
/*      */       case '(':
/* 1305 */         mTREE(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '[':
/* 1310 */         mAST_CONSTRUCTOR(false); break;
/*      */       case ':': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '_': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j':
/*      */       case 'k':
/*      */       case 'l':
/*      */       case 'm':
/*      */       case 'n':
/*      */       case 'o':
/*      */       case 'p':
/*      */       case 'q':
/*      */       case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/* 1328 */         mID_ELEMENT(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '"':
/* 1333 */         mSTRING(false);
/*      */         break;
/*      */       
/*      */       default:
/* 1337 */         if (LA(1) == '#' && LA(2) == '(') {
/* 1338 */           int j = this.text.length();
/* 1339 */           match('#');
/* 1340 */           this.text.setLength(j);
/* 1341 */           mTREE(false); break;
/*      */         } 
/* 1343 */         if (LA(1) == '#' && LA(2) == '[') {
/* 1344 */           int j = this.text.length();
/* 1345 */           match('#');
/* 1346 */           this.text.setLength(j);
/* 1347 */           mAST_CONSTRUCTOR(false); break;
/*      */         } 
/* 1349 */         if (LA(1) == '#' && _tokenSet_12.member(LA(2))) {
/* 1350 */           int j = this.text.length();
/* 1351 */           match('#');
/* 1352 */           this.text.setLength(j);
/* 1353 */           boolean bool = mID_ELEMENT(true);
/* 1354 */           token2 = this._returnToken;
/*      */           
/* 1356 */           if (!bool) {
/*      */             
/* 1358 */             String str = this.generator.mapTreeId(token2.getText(), null);
/*      */             
/* 1360 */             if (str != null) {
/* 1361 */               this.text.setLength(i); this.text.append(str);
/*      */             } 
/*      */           } 
/*      */           break;
/*      */         } 
/* 1366 */         if (LA(1) == '#' && LA(2) == '#') {
/* 1367 */           match("##");
/*      */           
/* 1369 */           if (this.currentRule != null) {
/*      */             
/* 1371 */             String str = this.currentRule.getRuleName() + "_AST";
/* 1372 */             this.text.setLength(i); this.text.append(str);
/*      */             
/*      */             break;
/*      */           } 
/* 1376 */           reportError("\"##\" not valid in this context");
/* 1377 */           this.text.setLength(i); this.text.append("##");
/*      */           
/*      */           break;
/*      */         } 
/*      */         
/* 1382 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/* 1385 */     if (paramBoolean && token1 == null && b != -1) {
/* 1386 */       token1 = makeToken(b);
/* 1387 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1389 */     this._returnToken = token1;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final boolean mID_ELEMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*      */     int j;
/*      */     byte b2;
/* 1396 */     boolean bool = false;
/* 1397 */     Token token1 = null; int i = this.text.length();
/* 1398 */     byte b1 = 12;
/*      */     
/* 1400 */     Token token2 = null;
/*      */     
/* 1402 */     mID(true);
/* 1403 */     token2 = this._returnToken;
/*      */     
/* 1405 */     if (_tokenSet_4.member(LA(1)) && _tokenSet_13.member(LA(2))) {
/* 1406 */       int k = this.text.length();
/* 1407 */       mWS(false);
/* 1408 */       this.text.setLength(k);
/*      */     }
/* 1410 */     else if (!_tokenSet_13.member(LA(1))) {
/*      */ 
/*      */       
/* 1413 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1418 */     switch (LA(1)) {
/*      */       
/*      */       case '(':
/*      */       case '<':
/* 1422 */         switch (LA(1)) {
/*      */           
/*      */           case '<':
/* 1425 */             match('<');
/*      */ 
/*      */ 
/*      */             
/* 1429 */             while (_tokenSet_14.member(LA(1))) {
/* 1430 */               matchNot('>');
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1438 */             match('>');
/*      */             break;
/*      */ 
/*      */           
/*      */           case '(':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 1447 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */ 
/*      */         
/* 1451 */         match('(');
/*      */         
/* 1453 */         if (_tokenSet_4.member(LA(1)) && _tokenSet_15.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 1454 */           int k = this.text.length();
/* 1455 */           mWS(false);
/* 1456 */           this.text.setLength(k);
/*      */         }
/* 1458 */         else if (!_tokenSet_15.member(LA(1)) || LA(2) < '\003' || LA(2) > 'ÿ') {
/*      */ 
/*      */           
/* 1461 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1466 */         switch (LA(1)) { case '"': case '#': case '\'': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case ':': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g':
/*      */           case 'h':
/*      */           case 'i':
/*      */           case 'j':
/*      */           case 'k':
/*      */           case 'l':
/*      */           case 'm':
/*      */           case 'n':
/*      */           case 'o':
/*      */           case 'p':
/*      */           case 'q':
/*      */           case 'r':
/*      */           case 's':
/*      */           case 't':
/*      */           case 'u':
/*      */           case 'v':
/*      */           case 'w':
/*      */           case 'x':
/*      */           case 'y':
/*      */           case 'z':
/* 1486 */             mARG(false);
/*      */ 
/*      */ 
/*      */             
/* 1490 */             while (LA(1) == ',') {
/* 1491 */               int k; match(',');
/*      */               
/* 1493 */               switch (LA(1)) { case '\t': case '\n':
/*      */                 case '\r':
/*      */                 case ' ':
/* 1496 */                   k = this.text.length();
/* 1497 */                   mWS(false);
/* 1498 */                   this.text.setLength(k); break;
/*      */                 case '"': case '#': case '\'': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case ':': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd':
/*      */                 case 'e':
/*      */                 case 'f':
/*      */                 case 'g':
/*      */                 case 'h':
/*      */                 case 'i':
/*      */                 case 'j':
/*      */                 case 'k':
/*      */                 case 'l':
/*      */                 case 'm':
/*      */                 case 'n':
/*      */                 case 'o':
/*      */                 case 'p':
/*      */                 case 'q':
/*      */                 case 'r':
/*      */                 case 's':
/*      */                 case 't':
/*      */                 case 'u':
/*      */                 case 'v':
/*      */                 case 'w':
/*      */                 case 'x':
/*      */                 case 'y':
/*      */                 case 'z':
/*      */                   break;
/*      */                 default:
/* 1524 */                   throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */               
/* 1528 */               mARG(false);
/*      */             } 
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case '\t':
/*      */           case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*      */           case ')':
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           default:
/* 1545 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1550 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/* 1553 */             j = this.text.length();
/* 1554 */             mWS(false);
/* 1555 */             this.text.setLength(j);
/*      */             break;
/*      */ 
/*      */           
/*      */           case ')':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 1564 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/* 1568 */         match(')');
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case '[':
/* 1574 */         b2 = 0;
/*      */         
/*      */         while (true) {
/* 1577 */           if (LA(1) == '[') {
/* 1578 */             match('[');
/*      */             
/* 1580 */             switch (LA(1)) { case '\t': case '\n':
/*      */               case '\r':
/*      */               case ' ':
/* 1583 */                 j = this.text.length();
/* 1584 */                 mWS(false);
/* 1585 */                 this.text.setLength(j); break;
/*      */               case '"': case '#': case '\'': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case ':': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd':
/*      */               case 'e':
/*      */               case 'f':
/*      */               case 'g':
/*      */               case 'h':
/*      */               case 'i':
/*      */               case 'j':
/*      */               case 'k':
/*      */               case 'l':
/*      */               case 'm':
/*      */               case 'n':
/*      */               case 'o':
/*      */               case 'p':
/*      */               case 'q':
/*      */               case 'r':
/*      */               case 's':
/*      */               case 't':
/*      */               case 'u':
/*      */               case 'v':
/*      */               case 'w':
/*      */               case 'x':
/*      */               case 'y':
/*      */               case 'z':
/*      */                 break;
/*      */               default:
/* 1611 */                 throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */             
/* 1615 */             mARG(false);
/*      */             
/* 1617 */             switch (LA(1)) { case '\t': case '\n':
/*      */               case '\r':
/*      */               case ' ':
/* 1620 */                 j = this.text.length();
/* 1621 */                 mWS(false);
/* 1622 */                 this.text.setLength(j);
/*      */                 break;
/*      */ 
/*      */               
/*      */               case ']':
/*      */                 break;
/*      */ 
/*      */               
/*      */               default:
/* 1631 */                 throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */             
/* 1635 */             match(']');
/*      */           } else {
/*      */             
/* 1638 */             if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */           } 
/*      */           
/* 1641 */           b2++;
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case '.':
/* 1648 */         match('.');
/* 1649 */         mID_ELEMENT(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case ':':
/* 1654 */         match("::");
/* 1655 */         mID_ELEMENT(false);
/*      */         break;
/*      */       
/*      */       default:
/* 1659 */         if (LA(1) == '-' && LA(2) == '>' && _tokenSet_12.member(LA(3))) {
/* 1660 */           match("->");
/* 1661 */           mID_ELEMENT(false); break;
/*      */         } 
/* 1663 */         if (_tokenSet_16.member(LA(1))) {
/*      */           
/* 1665 */           bool = true;
/* 1666 */           String str = this.generator.mapTreeId(token2.getText(), this.transInfo);
/*      */           
/* 1668 */           if (str != null) {
/* 1669 */             this.text.setLength(i); this.text.append(str);
/*      */           } 
/*      */ 
/*      */           
/* 1673 */           if (_tokenSet_17.member(LA(1)) && _tokenSet_16.member(LA(2)) && this.transInfo != null && this.transInfo.refRuleRoot != null) {
/*      */             
/* 1675 */             switch (LA(1)) { case '\t': case '\n':
/*      */               case '\r':
/*      */               case ' ':
/* 1678 */                 mWS(false);
/*      */                 break;
/*      */ 
/*      */               
/*      */               case '=':
/*      */                 break;
/*      */ 
/*      */               
/*      */               default:
/* 1687 */                 throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */             
/* 1691 */             mVAR_ASSIGN(false); break;
/*      */           } 
/* 1693 */           if (_tokenSet_18.member(LA(1))) {
/*      */             break;
/*      */           }
/* 1696 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1702 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 1706 */     if (paramBoolean && token1 == null && b1 != -1) {
/* 1707 */       token1 = makeToken(b1);
/* 1708 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1710 */     this._returnToken = token1;
/* 1711 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void mAST_CTOR_ELEMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1718 */     Token token = null; int i = this.text.length();
/* 1719 */     byte b = 11;
/*      */ 
/*      */     
/* 1722 */     if (LA(1) == '"' && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 1723 */       mSTRING(false);
/*      */     }
/* 1725 */     else if (_tokenSet_19.member(LA(1)) && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 1726 */       mTREE_ELEMENT(false);
/*      */     }
/* 1728 */     else if (LA(1) >= '0' && LA(1) <= '9') {
/* 1729 */       mINT(false);
/*      */     } else {
/*      */       
/* 1732 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/* 1735 */     if (paramBoolean && token == null && b != -1) {
/* 1736 */       token = makeToken(b);
/* 1737 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1739 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mINT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1743 */     Token token = null; int i = this.text.length();
/* 1744 */     byte b1 = 26;
/*      */ 
/*      */ 
/*      */     
/* 1748 */     byte b2 = 0;
/*      */     
/*      */     while (true) {
/* 1751 */       if (LA(1) >= '0' && LA(1) <= '9') {
/* 1752 */         mDIGIT(false);
/*      */       } else {
/*      */         
/* 1755 */         if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/* 1758 */       b2++;
/*      */     } 
/*      */     
/* 1761 */     if (paramBoolean && token == null && b1 != -1) {
/* 1762 */       token = makeToken(b1);
/* 1763 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1765 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mARG(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1769 */     Token token = null; int i = this.text.length();
/* 1770 */     byte b = 16;
/*      */ 
/*      */ 
/*      */     
/* 1774 */     switch (LA(1)) {
/*      */       
/*      */       case '\'':
/* 1777 */         mCHAR(false); break;
/*      */       case '0': case '1': case '2': case '3': case '4':
/*      */       case '5':
/*      */       case '6':
/*      */       case '7':
/*      */       case '8':
/*      */       case '9':
/* 1784 */         mINT_OR_FLOAT(false);
/*      */         break;
/*      */       
/*      */       default:
/* 1788 */         if (_tokenSet_19.member(LA(1)) && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 1789 */           mTREE_ELEMENT(false); break;
/*      */         } 
/* 1791 */         if (LA(1) == '"' && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 1792 */           mSTRING(false);
/*      */           break;
/*      */         } 
/* 1795 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1802 */     while (_tokenSet_20.member(LA(1)) && _tokenSet_21.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/*      */       
/* 1804 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/* 1807 */           mWS(false);
/*      */           break;
/*      */         
/*      */         case '*':
/*      */         case '+':
/*      */         case '-':
/*      */         case '/':
/*      */           break;
/*      */         default:
/* 1816 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1821 */       switch (LA(1)) {
/*      */         
/*      */         case '+':
/* 1824 */           match('+');
/*      */           break;
/*      */ 
/*      */         
/*      */         case '-':
/* 1829 */           match('-');
/*      */           break;
/*      */ 
/*      */         
/*      */         case '*':
/* 1834 */           match('*');
/*      */           break;
/*      */ 
/*      */         
/*      */         case '/':
/* 1839 */           match('/');
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1844 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1849 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/* 1852 */           mWS(false); break;
/*      */         case '"': case '#': case '\'': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case ':': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd':
/*      */         case 'e':
/*      */         case 'f':
/*      */         case 'g':
/*      */         case 'h':
/*      */         case 'i':
/*      */         case 'j':
/*      */         case 'k':
/*      */         case 'l':
/*      */         case 'm':
/*      */         case 'n':
/*      */         case 'o':
/*      */         case 'p':
/*      */         case 'q':
/*      */         case 'r':
/*      */         case 's':
/*      */         case 't':
/*      */         case 'u':
/*      */         case 'v':
/*      */         case 'w':
/*      */         case 'x':
/*      */         case 'y':
/*      */         case 'z':
/*      */           break;
/*      */         default:
/* 1878 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */       
/* 1882 */       mARG(false);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1890 */     if (paramBoolean && token == null && b != -1) {
/* 1891 */       token = makeToken(b);
/* 1892 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1894 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mTEXT_ARG_ELEMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1898 */     Token token = null; int i = this.text.length();
/* 1899 */     byte b = 14;
/*      */ 
/*      */     
/* 1902 */     switch (LA(1)) { case ':': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '_': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j': case 'k':
/*      */       case 'l':
/*      */       case 'm':
/*      */       case 'n':
/*      */       case 'o':
/*      */       case 'p':
/*      */       case 'q':
/*      */       case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/* 1918 */         mTEXT_ARG_ID_ELEMENT(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '"':
/* 1923 */         mSTRING(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\'':
/* 1928 */         mCHAR(false); break;
/*      */       case '0': case '1': case '2': case '3': case '4':
/*      */       case '5':
/*      */       case '6':
/*      */       case '7':
/*      */       case '8':
/*      */       case '9':
/* 1935 */         mINT_OR_FLOAT(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '$':
/* 1940 */         mTEXT_ITEM(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '+':
/* 1945 */         match('+');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 1950 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */     
/* 1953 */     if (paramBoolean && token == null && b != -1) {
/* 1954 */       token = makeToken(b);
/* 1955 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1957 */     this._returnToken = token;
/*      */   } protected final void mTEXT_ARG_ID_ELEMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*      */     int j;
/*      */     byte b2;
/* 1961 */     Token token1 = null; int i = this.text.length();
/* 1962 */     byte b1 = 15;
/*      */     
/* 1964 */     Token token2 = null;
/*      */     
/* 1966 */     mID(true);
/* 1967 */     token2 = this._returnToken;
/*      */     
/* 1969 */     if (_tokenSet_4.member(LA(1)) && _tokenSet_22.member(LA(2))) {
/* 1970 */       int k = this.text.length();
/* 1971 */       mWS(false);
/* 1972 */       this.text.setLength(k);
/*      */     }
/* 1974 */     else if (!_tokenSet_22.member(LA(1))) {
/*      */ 
/*      */       
/* 1977 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1982 */     switch (LA(1)) {
/*      */       
/*      */       case '(':
/* 1985 */         match('(');
/*      */         
/* 1987 */         if (_tokenSet_4.member(LA(1)) && _tokenSet_23.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 1988 */           int k = this.text.length();
/* 1989 */           mWS(false);
/* 1990 */           this.text.setLength(k);
/*      */         }
/* 1992 */         else if (!_tokenSet_23.member(LA(1)) || LA(2) < '\003' || LA(2) > 'ÿ') {
/*      */ 
/*      */           
/* 1995 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2002 */         while (_tokenSet_24.member(LA(1)) && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 2003 */           mTEXT_ARG(false);
/*      */ 
/*      */ 
/*      */           
/* 2007 */           while (LA(1) == ',') {
/* 2008 */             match(',');
/* 2009 */             mTEXT_ARG(false);
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2025 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/* 2028 */             j = this.text.length();
/* 2029 */             mWS(false);
/* 2030 */             this.text.setLength(j);
/*      */             break;
/*      */ 
/*      */           
/*      */           case ')':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 2039 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/* 2043 */         match(')');
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case '[':
/* 2049 */         b2 = 0;
/*      */         
/*      */         while (true) {
/* 2052 */           if (LA(1) == '[') {
/* 2053 */             match('[');
/*      */             
/* 2055 */             if (_tokenSet_4.member(LA(1)) && _tokenSet_24.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 2056 */               j = this.text.length();
/* 2057 */               mWS(false);
/* 2058 */               this.text.setLength(j);
/*      */             }
/* 2060 */             else if (!_tokenSet_24.member(LA(1)) || LA(2) < '\003' || LA(2) > 'ÿ' || LA(3) < '\003' || LA(3) > 'ÿ') {
/*      */ 
/*      */               
/* 2063 */               throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */             } 
/*      */ 
/*      */             
/* 2067 */             mTEXT_ARG(false);
/*      */             
/* 2069 */             switch (LA(1)) { case '\t': case '\n':
/*      */               case '\r':
/*      */               case ' ':
/* 2072 */                 j = this.text.length();
/* 2073 */                 mWS(false);
/* 2074 */                 this.text.setLength(j);
/*      */                 break;
/*      */ 
/*      */               
/*      */               case ']':
/*      */                 break;
/*      */ 
/*      */               
/*      */               default:
/* 2083 */                 throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */             
/* 2087 */             match(']');
/*      */           } else {
/*      */             
/* 2090 */             if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */           } 
/*      */           
/* 2093 */           b2++;
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case '.':
/* 2100 */         match('.');
/* 2101 */         mTEXT_ARG_ID_ELEMENT(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '-':
/* 2106 */         match("->");
/* 2107 */         mTEXT_ARG_ID_ELEMENT(false);
/*      */         break;
/*      */       
/*      */       default:
/* 2111 */         if (LA(1) == ':' && LA(2) == ':' && _tokenSet_12.member(LA(3))) {
/* 2112 */           match("::");
/* 2113 */           mTEXT_ARG_ID_ELEMENT(false); break;
/*      */         } 
/* 2115 */         if (_tokenSet_11.member(LA(1))) {
/*      */           break;
/*      */         }
/* 2118 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 2122 */     if (paramBoolean && token1 == null && b1 != -1) {
/* 2123 */       token1 = makeToken(b1);
/* 2124 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2126 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mINT_OR_FLOAT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2130 */     Token token = null; int i = this.text.length();
/* 2131 */     byte b1 = 27;
/*      */ 
/*      */ 
/*      */     
/* 2135 */     byte b2 = 0;
/*      */     
/*      */     while (true) {
/* 2138 */       if (LA(1) >= '0' && LA(1) <= '9' && _tokenSet_25.member(LA(2))) {
/* 2139 */         mDIGIT(false);
/*      */       } else {
/*      */         
/* 2142 */         if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/* 2145 */       b2++;
/*      */     } 
/*      */ 
/*      */     
/* 2149 */     if (LA(1) == 'L' && _tokenSet_26.member(LA(2))) {
/* 2150 */       match('L');
/*      */     }
/* 2152 */     else if (LA(1) == 'l' && _tokenSet_26.member(LA(2))) {
/* 2153 */       match('l');
/*      */     }
/* 2155 */     else if (LA(1) == '.') {
/* 2156 */       match('.');
/*      */ 
/*      */ 
/*      */       
/* 2160 */       while (LA(1) >= '0' && LA(1) <= '9' && _tokenSet_26.member(LA(2))) {
/* 2161 */         mDIGIT(false);
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 2170 */     else if (!_tokenSet_26.member(LA(1))) {
/*      */ 
/*      */       
/* 2173 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 2177 */     if (paramBoolean && token == null && b1 != -1) {
/* 2178 */       token = makeToken(b1);
/* 2179 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2181 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mSL_COMMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2185 */     Token token = null; int i = this.text.length();
/* 2186 */     byte b = 20;
/*      */ 
/*      */     
/* 2189 */     match("//");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2194 */     while (LA(1) != '\n' && LA(1) != '\r' && 
/* 2195 */       LA(1) >= '\003' && LA(1) <= 'ÿ' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 2196 */       matchNot('￿');
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2205 */     if (LA(1) == '\r' && LA(2) == '\n') {
/* 2206 */       match("\r\n");
/*      */     }
/* 2208 */     else if (LA(1) == '\n') {
/* 2209 */       match('\n');
/*      */     }
/* 2211 */     else if (LA(1) == '\r') {
/* 2212 */       match('\r');
/*      */     } else {
/*      */       
/* 2215 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 2219 */     newline();
/* 2220 */     if (paramBoolean && token == null && b != -1) {
/* 2221 */       token = makeToken(b);
/* 2222 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2224 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mML_COMMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2228 */     Token token = null; int i = this.text.length();
/* 2229 */     byte b = 21;
/*      */ 
/*      */     
/* 2232 */     match("/*");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2237 */     while (LA(1) != '*' || LA(2) != '/') {
/* 2238 */       if (LA(1) == '\r' && LA(2) == '\n' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 2239 */         match('\r');
/* 2240 */         match('\n');
/* 2241 */         newline(); continue;
/*      */       } 
/* 2243 */       if (LA(1) == '\r' && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 2244 */         match('\r');
/* 2245 */         newline(); continue;
/*      */       } 
/* 2247 */       if (LA(1) == '\n' && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 2248 */         match('\n');
/* 2249 */         newline(); continue;
/*      */       } 
/* 2251 */       if (LA(1) >= '\003' && LA(1) <= 'ÿ' && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 2252 */         matchNot('￿');
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/* 2260 */     match("*/");
/* 2261 */     if (paramBoolean && token == null && b != -1) {
/* 2262 */       token = makeToken(b);
/* 2263 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2265 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mESC(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2269 */     Token token = null; int i = this.text.length();
/* 2270 */     byte b = 24;
/*      */ 
/*      */     
/* 2273 */     match('\\');
/*      */     
/* 2275 */     switch (LA(1)) {
/*      */       
/*      */       case 'n':
/* 2278 */         match('n');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'r':
/* 2283 */         match('r');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 't':
/* 2288 */         match('t');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'v':
/* 2293 */         match('v');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'b':
/* 2298 */         match('b');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'f':
/* 2303 */         match('f');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '"':
/* 2308 */         match('"');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\'':
/* 2313 */         match('\'');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\\':
/* 2318 */         match('\\');
/*      */         break;
/*      */       case '0':
/*      */       case '1':
/*      */       case '2':
/*      */       case '3':
/* 2324 */         matchRange('0', '3');
/*      */ 
/*      */         
/* 2327 */         if (LA(1) >= '0' && LA(1) <= '9' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 2328 */           mDIGIT(false);
/*      */           
/* 2330 */           if (LA(1) >= '0' && LA(1) <= '9' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 2331 */             mDIGIT(false); break;
/*      */           } 
/* 2333 */           if (LA(1) >= '\003' && LA(1) <= 'ÿ') {
/*      */             break;
/*      */           }
/* 2336 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 2341 */         if (LA(1) >= '\003' && LA(1) <= 'ÿ') {
/*      */           break;
/*      */         }
/* 2344 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case '4':
/*      */       case '5':
/*      */       case '6':
/*      */       case '7':
/* 2353 */         matchRange('4', '7');
/*      */ 
/*      */         
/* 2356 */         if (LA(1) >= '0' && LA(1) <= '9' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 2357 */           mDIGIT(false); break;
/*      */         } 
/* 2359 */         if (LA(1) >= '\003' && LA(1) <= 'ÿ') {
/*      */           break;
/*      */         }
/* 2362 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 2370 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 2374 */     if (paramBoolean && token == null && b != -1) {
/* 2375 */       token = makeToken(b);
/* 2376 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2378 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mDIGIT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2382 */     Token token = null; int i = this.text.length();
/* 2383 */     byte b = 25;
/*      */ 
/*      */     
/* 2386 */     matchRange('0', '9');
/* 2387 */     if (paramBoolean && token == null && b != -1) {
/* 2388 */       token = makeToken(b);
/* 2389 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2391 */     this._returnToken = token;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final long[] mk_tokenSet_0() {
/* 2396 */     long[] arrayOfLong = new long[8];
/* 2397 */     arrayOfLong[0] = -103079215112L;
/* 2398 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 2399 */      return arrayOfLong;
/*      */   }
/* 2401 */   public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
/*      */   private static final long[] mk_tokenSet_1() {
/* 2403 */     long[] arrayOfLong = new long[8];
/* 2404 */     arrayOfLong[0] = -145135534866440L;
/* 2405 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 2406 */      return arrayOfLong;
/*      */   }
/* 2408 */   public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
/*      */   private static final long[] mk_tokenSet_2() {
/* 2410 */     long[] arrayOfLong = new long[8];
/* 2411 */     arrayOfLong[0] = -141407503262728L;
/* 2412 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 2413 */      return arrayOfLong;
/*      */   }
/* 2415 */   public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
/*      */   private static final long[] mk_tokenSet_3() {
/* 2417 */     return new long[] { 288230380446688768L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2420 */   public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
/*      */   private static final long[] mk_tokenSet_4() {
/* 2422 */     return new long[] { 4294977024L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2425 */   public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
/*      */   private static final long[] mk_tokenSet_5() {
/* 2427 */     return new long[] { 1103806604800L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2430 */   public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
/*      */   private static final long[] mk_tokenSet_6() {
/* 2432 */     return new long[] { 576189812881499648L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2435 */   public static final BitSet _tokenSet_6 = new BitSet(mk_tokenSet_6());
/*      */   private static final long[] mk_tokenSet_7() {
/* 2437 */     long[] arrayOfLong = new long[8];
/* 2438 */     arrayOfLong[0] = -17179869192L;
/* 2439 */     arrayOfLong[1] = -268435457L;
/* 2440 */     for (byte b = 2; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 2441 */      return arrayOfLong;
/*      */   }
/* 2443 */   public static final BitSet _tokenSet_7 = new BitSet(mk_tokenSet_7());
/*      */   private static final long[] mk_tokenSet_8() {
/* 2445 */     long[] arrayOfLong = new long[8];
/* 2446 */     arrayOfLong[0] = -549755813896L;
/* 2447 */     arrayOfLong[1] = -268435457L;
/* 2448 */     for (byte b = 2; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 2449 */      return arrayOfLong;
/*      */   }
/* 2451 */   public static final BitSet _tokenSet_8 = new BitSet(mk_tokenSet_8());
/*      */   private static final long[] mk_tokenSet_9() {
/* 2453 */     return new long[] { 576179277326712832L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2456 */   public static final BitSet _tokenSet_9 = new BitSet(mk_tokenSet_9());
/*      */   private static final long[] mk_tokenSet_10() {
/* 2458 */     return new long[] { 576188709074894848L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2461 */   public static final BitSet _tokenSet_10 = new BitSet(mk_tokenSet_10());
/*      */   private static final long[] mk_tokenSet_11() {
/* 2463 */     return new long[] { 576208504579171840L, 576460746532061182L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2466 */   public static final BitSet _tokenSet_11 = new BitSet(mk_tokenSet_11());
/*      */   private static final long[] mk_tokenSet_12() {
/* 2468 */     return new long[] { 288230376151711744L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2471 */   public static final BitSet _tokenSet_12 = new BitSet(mk_tokenSet_12());
/*      */   private static final long[] mk_tokenSet_13() {
/* 2473 */     return new long[] { 3747275269732312576L, 671088640L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2476 */   public static final BitSet _tokenSet_13 = new BitSet(mk_tokenSet_13());
/*      */   private static final long[] mk_tokenSet_14() {
/* 2478 */     long[] arrayOfLong = new long[8];
/* 2479 */     arrayOfLong[0] = -4611686018427387912L;
/* 2480 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 2481 */      return arrayOfLong;
/*      */   }
/* 2483 */   public static final BitSet _tokenSet_14 = new BitSet(mk_tokenSet_14());
/*      */   private static final long[] mk_tokenSet_15() {
/* 2485 */     return new long[] { 576183181451994624L, 576460746129407998L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2488 */   public static final BitSet _tokenSet_15 = new BitSet(mk_tokenSet_15());
/*      */   private static final long[] mk_tokenSet_16() {
/* 2490 */     return new long[] { 2306051920717948416L, 536870912L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2493 */   public static final BitSet _tokenSet_16 = new BitSet(mk_tokenSet_16());
/*      */   private static final long[] mk_tokenSet_17() {
/* 2495 */     return new long[] { 2305843013508670976L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2498 */   public static final BitSet _tokenSet_17 = new BitSet(mk_tokenSet_17());
/*      */   private static final long[] mk_tokenSet_18() {
/* 2500 */     return new long[] { 208911504254464L, 536870912L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2503 */   public static final BitSet _tokenSet_18 = new BitSet(mk_tokenSet_18());
/*      */   private static final long[] mk_tokenSet_19() {
/* 2505 */     return new long[] { 288231527202947072L, 576460746129407998L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2508 */   public static final BitSet _tokenSet_19 = new BitSet(mk_tokenSet_19());
/*      */   private static final long[] mk_tokenSet_20() {
/* 2510 */     return new long[] { 189120294954496L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2513 */   public static final BitSet _tokenSet_20 = new BitSet(mk_tokenSet_20());
/*      */   private static final long[] mk_tokenSet_21() {
/* 2515 */     return new long[] { 576370098428716544L, 576460746129407998L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2518 */   public static final BitSet _tokenSet_21 = new BitSet(mk_tokenSet_21());
/*      */   private static final long[] mk_tokenSet_22() {
/* 2520 */     return new long[] { 576315157207066112L, 576460746666278910L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2523 */   public static final BitSet _tokenSet_22 = new BitSet(mk_tokenSet_22());
/*      */   private static final long[] mk_tokenSet_23() {
/* 2525 */     return new long[] { 576190912393127424L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2528 */   public static final BitSet _tokenSet_23 = new BitSet(mk_tokenSet_23());
/*      */   private static final long[] mk_tokenSet_24() {
/* 2530 */     return new long[] { 576188713369871872L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2533 */   public static final BitSet _tokenSet_24 = new BitSet(mk_tokenSet_24());
/*      */   private static final long[] mk_tokenSet_25() {
/* 2535 */     return new long[] { 576459193230304768L, 576460746532061182L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2538 */   public static final BitSet _tokenSet_25 = new BitSet(mk_tokenSet_25());
/*      */   private static final long[] mk_tokenSet_26() {
/* 2540 */     return new long[] { 576388824486127104L, 576460746532061182L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2543 */   public static final BitSet _tokenSet_26 = new BitSet(mk_tokenSet_26());
/*      */ }


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\actions\cpp\ActionLexer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
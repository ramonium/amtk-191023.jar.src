/*     */ package antlr.actions.python;
/*     */ 
/*     */ import antlr.ByteBuffer;
/*     */ import antlr.CharBuffer;
/*     */ import antlr.CharScanner;
/*     */ import antlr.CharStreamException;
/*     */ import antlr.CharStreamIOException;
/*     */ import antlr.InputBuffer;
/*     */ import antlr.LexerSharedInputState;
/*     */ import antlr.NoViableAltForCharException;
/*     */ import antlr.RecognitionException;
/*     */ import antlr.Token;
/*     */ import antlr.TokenStream;
/*     */ import antlr.TokenStreamException;
/*     */ import antlr.TokenStreamIOException;
/*     */ import antlr.TokenStreamRecognitionException;
/*     */ import antlr.Tool;
/*     */ import antlr.collections.impl.BitSet;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CodeLexer
/*     */   extends CharScanner
/*     */   implements CodeLexerTokenTypes, TokenStream
/*     */ {
/*  36 */   protected int lineOffset = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   private Tool antlrTool;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CodeLexer(String paramString1, String paramString2, int paramInt, Tool paramTool) {
/*  46 */     this(new StringReader(paramString1));
/*  47 */     setLine(paramInt);
/*  48 */     setFilename(paramString2);
/*  49 */     this.antlrTool = paramTool;
/*     */   }
/*     */   
/*     */   public void setLineOffset(int paramInt) {
/*  53 */     setLine(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public void reportError(RecognitionException paramRecognitionException) {
/*  58 */     this.antlrTool.error("Syntax error in action: " + paramRecognitionException, getFilename(), getLine(), getColumn());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reportError(String paramString) {
/*  65 */     this.antlrTool.error(paramString, getFilename(), getLine(), getColumn());
/*     */   }
/*     */ 
/*     */   
/*     */   public void reportWarning(String paramString) {
/*  70 */     if (getFilename() == null) {
/*  71 */       this.antlrTool.warning(paramString);
/*     */     } else {
/*     */       
/*  74 */       this.antlrTool.warning(paramString, getFilename(), getLine(), getColumn());
/*     */     } 
/*     */   }
/*     */   public CodeLexer(InputStream paramInputStream) {
/*  78 */     this((InputBuffer)new ByteBuffer(paramInputStream));
/*     */   }
/*     */   public CodeLexer(Reader paramReader) {
/*  81 */     this((InputBuffer)new CharBuffer(paramReader));
/*     */   }
/*     */   public CodeLexer(InputBuffer paramInputBuffer) {
/*  84 */     this(new LexerSharedInputState(paramInputBuffer));
/*     */   }
/*     */   public CodeLexer(LexerSharedInputState paramLexerSharedInputState) {
/*  87 */     super(paramLexerSharedInputState);
/*  88 */     this.caseSensitiveLiterals = true;
/*  89 */     setCaseSensitive(true);
/*  90 */     this.literals = new Hashtable();
/*     */   }
/*     */   
/*     */   public Token nextToken() throws TokenStreamException {
/*  94 */     Token token = null;
/*     */     
/*     */     while (true) {
/*  97 */       Object object = null;
/*  98 */       int i = 0;
/*  99 */       resetText();
/*     */ 
/*     */       
/*     */       try {
/* 103 */         mACTION(true);
/* 104 */         token = this._returnToken;
/*     */ 
/*     */         
/* 107 */         if (this._returnToken == null)
/* 108 */           continue;  i = this._returnToken.getType();
/* 109 */         this._returnToken.setType(i);
/* 110 */         return this._returnToken;
/*     */       }
/* 112 */       catch (RecognitionException recognitionException) {
/* 113 */         throw new TokenStreamRecognitionException(recognitionException);
/*     */       
/*     */       }
/* 116 */       catch (CharStreamException charStreamException) {
/* 117 */         if (charStreamException instanceof CharStreamIOException) {
/* 118 */           throw new TokenStreamIOException(((CharStreamIOException)charStreamException).io);
/*     */         }
/*     */         
/* 121 */         throw new TokenStreamException(charStreamException.getMessage());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void mACTION(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 128 */     Token token = null; int i = this.text.length();
/* 129 */     byte b = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 135 */     while (LA(1) >= '\003' && LA(1) <= 'ÿ') {
/* 136 */       mSTUFF(false);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 144 */     if (paramBoolean && token == null && b != -1) {
/* 145 */       token = makeToken(b);
/* 146 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*     */     } 
/* 148 */     this._returnToken = token;
/*     */   }
/*     */   
/*     */   protected final void mSTUFF(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 152 */     Token token = null; int i = this.text.length();
/* 153 */     byte b = 5;
/*     */ 
/*     */     
/* 156 */     if (LA(1) == '/' && (LA(2) == '*' || LA(2) == '/')) {
/* 157 */       mCOMMENT(false);
/*     */     }
/* 159 */     else if (LA(1) == '\r' && LA(2) == '\n') {
/* 160 */       match("\r\n");
/* 161 */       newline();
/*     */     }
/* 163 */     else if (LA(1) == '/' && _tokenSet_0.member(LA(2))) {
/* 164 */       match('/');
/*     */       
/* 166 */       match(_tokenSet_0);
/*     */     
/*     */     }
/* 169 */     else if (LA(1) == '\r') {
/* 170 */       match('\r');
/* 171 */       newline();
/*     */     }
/* 173 */     else if (LA(1) == '\n') {
/* 174 */       match('\n');
/* 175 */       newline();
/*     */     }
/* 177 */     else if (_tokenSet_1.member(LA(1))) {
/*     */       
/* 179 */       match(_tokenSet_1);
/*     */     }
/*     */     else {
/*     */       
/* 183 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*     */     } 
/*     */     
/* 186 */     if (paramBoolean && token == null && b != -1) {
/* 187 */       token = makeToken(b);
/* 188 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*     */     } 
/* 190 */     this._returnToken = token;
/*     */   }
/*     */   
/*     */   protected final void mCOMMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 194 */     Token token = null; int i = this.text.length();
/* 195 */     byte b = 6;
/*     */ 
/*     */     
/* 198 */     if (LA(1) == '/' && LA(2) == '/') {
/* 199 */       mSL_COMMENT(false);
/*     */     }
/* 201 */     else if (LA(1) == '/' && LA(2) == '*') {
/* 202 */       mML_COMMENT(false);
/*     */     } else {
/*     */       
/* 205 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*     */     } 
/*     */     
/* 208 */     if (paramBoolean && token == null && b != -1) {
/* 209 */       token = makeToken(b);
/* 210 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*     */     } 
/* 212 */     this._returnToken = token;
/*     */   }
/*     */   
/*     */   protected final void mSL_COMMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 216 */     Token token = null; int i = this.text.length();
/* 217 */     byte b = 7;
/*     */ 
/*     */     
/* 220 */     int j = this.text.length();
/* 221 */     match("//");
/* 222 */     this.text.setLength(j);
/*     */ 
/*     */     
/* 225 */     this.text.append("#");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 231 */     while (LA(1) != '\n' && LA(1) != '\r' && 
/* 232 */       LA(1) >= '\003' && LA(1) <= 'ÿ' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 233 */       matchNot('￿');
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 242 */     if (LA(1) == '\r' && LA(2) == '\n') {
/* 243 */       match("\r\n");
/*     */     }
/* 245 */     else if (LA(1) == '\n') {
/* 246 */       match('\n');
/*     */     }
/* 248 */     else if (LA(1) == '\r') {
/* 249 */       match('\r');
/*     */     } else {
/*     */       
/* 252 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 257 */     newline();
/*     */     
/* 259 */     if (paramBoolean && token == null && b != -1) {
/* 260 */       token = makeToken(b);
/* 261 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*     */     } 
/* 263 */     this._returnToken = token;
/*     */   }
/*     */   
/*     */   protected final void mML_COMMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 267 */     Token token = null; int i = this.text.length();
/* 268 */     byte b = 9;
/*     */ 
/*     */     
/* 271 */     boolean bool = false;
/*     */ 
/*     */     
/* 274 */     int j = this.text.length();
/* 275 */     match("/*");
/* 276 */     this.text.setLength(j);
/*     */ 
/*     */     
/* 279 */     this.text.append("#");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 285 */     while (LA(1) != '*' || LA(2) != '/') {
/* 286 */       if (LA(1) == '\r' && LA(2) == '\n') {
/* 287 */         match('\r');
/* 288 */         match('\n');
/* 289 */         j = this.text.length();
/* 290 */         mIGNWS(false);
/* 291 */         this.text.setLength(j);
/*     */         
/* 293 */         newline();
/* 294 */         this.text.append("# ");
/*     */         continue;
/*     */       } 
/* 297 */       if (LA(1) == '\r' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 298 */         match('\r');
/* 299 */         j = this.text.length();
/* 300 */         mIGNWS(false);
/* 301 */         this.text.setLength(j);
/*     */         
/* 303 */         newline();
/* 304 */         this.text.append("# ");
/*     */         continue;
/*     */       } 
/* 307 */       if (LA(1) == '\n' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 308 */         match('\n');
/* 309 */         j = this.text.length();
/* 310 */         mIGNWS(false);
/* 311 */         this.text.setLength(j);
/*     */         
/* 313 */         newline();
/* 314 */         this.text.append("# ");
/*     */         continue;
/*     */       } 
/* 317 */       if (LA(1) >= '\003' && LA(1) <= 'ÿ' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 318 */         matchNot('￿');
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */ 
/*     */       
/*     */       break;
/*     */     } 
/*     */     
/* 328 */     this.text.append("\n");
/*     */     
/* 330 */     j = this.text.length();
/* 331 */     match("*/");
/* 332 */     this.text.setLength(j);
/* 333 */     if (paramBoolean && token == null && b != -1) {
/* 334 */       token = makeToken(b);
/* 335 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*     */     } 
/* 337 */     this._returnToken = token;
/*     */   }
/*     */   
/*     */   protected final void mIGNWS(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 341 */     Token token = null; int i = this.text.length();
/* 342 */     byte b = 8;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 348 */       if (LA(1) == ' ' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 349 */         match(' '); continue;
/*     */       } 
/* 351 */       if (LA(1) == '\t' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 352 */         match('\t');
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/*     */       break;
/*     */     } 
/*     */     
/* 360 */     if (paramBoolean && token == null && b != -1) {
/* 361 */       token = makeToken(b);
/* 362 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*     */     } 
/* 364 */     this._returnToken = token;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final long[] mk_tokenSet_0() {
/* 369 */     long[] arrayOfLong = new long[8];
/* 370 */     arrayOfLong[0] = -145135534866440L;
/* 371 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 372 */      return arrayOfLong;
/*     */   }
/* 374 */   public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
/*     */   private static final long[] mk_tokenSet_1() {
/* 376 */     long[] arrayOfLong = new long[8];
/* 377 */     arrayOfLong[0] = -140737488364552L;
/* 378 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 379 */      return arrayOfLong;
/*     */   }
/* 381 */   public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
/*     */ }


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\actions\python\CodeLexer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package antlr;
/*     */ 
/*     */ import antlr.collections.impl.BitSet;
/*     */ import antlr.collections.impl.Vector;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CodeGenerator
/*     */ {
/*     */   protected Tool antlrTool;
/*  54 */   protected int tabs = 0;
/*     */ 
/*     */   
/*     */   protected transient PrintWriter currentOutput;
/*     */ 
/*     */   
/*  60 */   protected Grammar grammar = null;
/*     */ 
/*     */ 
/*     */   
/*     */   protected Vector bitsetsUsed;
/*     */ 
/*     */ 
/*     */   
/*     */   protected DefineGrammarSymbols behavior;
/*     */ 
/*     */ 
/*     */   
/*     */   protected LLkGrammarAnalyzer analyzer;
/*     */ 
/*     */ 
/*     */   
/*     */   protected CharFormatter charFormatter;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean DEBUG_CODE_GENERATOR = false;
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int DEFAULT_MAKE_SWITCH_THRESHOLD = 2;
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int DEFAULT_BITSET_TEST_THRESHOLD = 4;
/*     */ 
/*     */   
/*     */   protected static final int BITSET_OPTIMIZE_INIT_THRESHOLD = 8;
/*     */ 
/*     */   
/*  94 */   protected int makeSwitchThreshold = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   protected int bitsetTestThreshold = 4;
/*     */   
/*     */   private static boolean OLD_ACTION_TRANSLATOR = true;
/*     */   
/* 106 */   public static String TokenTypesFileSuffix = "TokenTypes";
/* 107 */   public static String TokenTypesFileExt = ".txt";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _print(String paramString) {
/* 118 */     if (paramString != null) {
/* 119 */       this.currentOutput.print(paramString);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _printAction(String paramString) {
/* 129 */     if (paramString == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 134 */     byte b1 = 0;
/* 135 */     while (b1 < paramString.length() && Character.isSpaceChar(paramString.charAt(b1))) {
/* 136 */       b1++;
/*     */     }
/*     */ 
/*     */     
/* 140 */     int i = paramString.length() - 1;
/* 141 */     while (i > b1 && Character.isSpaceChar(paramString.charAt(i))) {
/* 142 */       i--;
/*     */     }
/*     */     
/* 145 */     char c = Character.MIN_VALUE;
/* 146 */     for (byte b2 = b1; b2 <= i; ) {
/* 147 */       c = paramString.charAt(b2);
/* 148 */       b2++;
/* 149 */       boolean bool = false;
/* 150 */       switch (c) {
/*     */         case '\n':
/* 152 */           bool = true;
/*     */           break;
/*     */         case '\r':
/* 155 */           if (b2 <= i && paramString.charAt(b2) == '\n') {
/* 156 */             b2++;
/*     */           }
/* 158 */           bool = true;
/*     */           break;
/*     */         default:
/* 161 */           this.currentOutput.print(c);
/*     */           break;
/*     */       } 
/* 164 */       if (bool) {
/* 165 */         this.currentOutput.println();
/* 166 */         printTabs();
/*     */         
/* 168 */         while (b2 <= i && Character.isSpaceChar(paramString.charAt(b2))) {
/* 169 */           b2++;
/*     */         }
/* 171 */         bool = false;
/*     */       } 
/*     */     } 
/* 174 */     this.currentOutput.println();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _println(String paramString) {
/* 182 */     if (paramString != null) {
/* 183 */       this.currentOutput.println(paramString);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean elementsAreRange(int[] paramArrayOfint) {
/* 192 */     if (paramArrayOfint.length == 0) {
/* 193 */       return false;
/*     */     }
/* 195 */     int i = paramArrayOfint[0];
/* 196 */     int j = paramArrayOfint[paramArrayOfint.length - 1];
/* 197 */     if (paramArrayOfint.length <= 2)
/*     */     {
/* 199 */       return false;
/*     */     }
/* 201 */     if (j - i + 1 > paramArrayOfint.length)
/*     */     {
/* 203 */       return false;
/*     */     }
/* 205 */     int k = i + 1;
/* 206 */     for (byte b = 1; b < paramArrayOfint.length - 1; b++) {
/* 207 */       if (k != paramArrayOfint[b])
/*     */       {
/* 209 */         return false;
/*     */       }
/* 211 */       k++;
/*     */     } 
/* 213 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String extractIdOfAction(Token paramToken) {
/* 224 */     return extractIdOfAction(paramToken.getText(), paramToken.getLine(), paramToken.getColumn());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String extractIdOfAction(String paramString, int paramInt1, int paramInt2) {
/* 237 */     paramString = removeAssignmentFromDeclaration(paramString);
/*     */ 
/*     */     
/* 240 */     for (int i = paramString.length() - 2; i >= 0; i--) {
/*     */       
/* 242 */       if (!Character.isLetterOrDigit(paramString.charAt(i)) && paramString.charAt(i) != '_')
/*     */       {
/* 244 */         return paramString.substring(i + 1);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 249 */     this.antlrTool.warning("Ill-formed action", this.grammar.getFilename(), paramInt1, paramInt2);
/* 250 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String extractTypeOfAction(Token paramToken) {
/* 261 */     return extractTypeOfAction(paramToken.getText(), paramToken.getLine(), paramToken.getColumn());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String extractTypeOfAction(String paramString, int paramInt1, int paramInt2) {
/* 273 */     paramString = removeAssignmentFromDeclaration(paramString);
/*     */ 
/*     */     
/* 276 */     for (int i = paramString.length() - 2; i >= 0; i--) {
/*     */       
/* 278 */       if (!Character.isLetterOrDigit(paramString.charAt(i)) && paramString.charAt(i) != '_')
/*     */       {
/* 280 */         return paramString.substring(0, i + 1);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 285 */     this.antlrTool.warning("Ill-formed action", this.grammar.getFilename(), paramInt1, paramInt2);
/* 286 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void gen();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void gen(ActionElement paramActionElement);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void gen(AlternativeBlock paramAlternativeBlock);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void gen(BlockEndElement paramBlockEndElement);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void gen(CharLiteralElement paramCharLiteralElement);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void gen(CharRangeElement paramCharRangeElement);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void gen(LexerGrammar paramLexerGrammar) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void gen(OneOrMoreBlock paramOneOrMoreBlock);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void gen(ParserGrammar paramParserGrammar) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void gen(RuleRefElement paramRuleRefElement);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void gen(StringLiteralElement paramStringLiteralElement);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void gen(TokenRangeElement paramTokenRangeElement);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void gen(TokenRefElement paramTokenRefElement);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void gen(TreeElement paramTreeElement);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void gen(TreeWalkerGrammar paramTreeWalkerGrammar) throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void gen(WildcardElement paramWildcardElement);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void gen(ZeroOrMoreBlock paramZeroOrMoreBlock);
/*     */ 
/*     */ 
/*     */   
/*     */   protected void genTokenInterchange(TokenManager paramTokenManager) throws IOException {
/* 372 */     String str = paramTokenManager.getName() + TokenTypesFileSuffix + TokenTypesFileExt;
/* 373 */     this.currentOutput = this.antlrTool.openOutputFile(str);
/*     */     
/* 375 */     println("// $ANTLR " + Tool.version + ": " + this.antlrTool.fileMinusPath(this.antlrTool.grammarFile) + " -> " + str + "$");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 381 */     this.tabs = 0;
/*     */ 
/*     */     
/* 384 */     println(paramTokenManager.getName() + "    // output token vocab name");
/*     */ 
/*     */     
/* 387 */     Vector vector = paramTokenManager.getVocabulary();
/* 388 */     for (byte b = 4; b < vector.size(); b++) {
/* 389 */       String str1 = (String)vector.elementAt(b);
/* 390 */       if (this.DEBUG_CODE_GENERATOR) {
/* 391 */         System.out.println("gen persistence file entry for: " + str1);
/*     */       }
/* 393 */       if (str1 != null && !str1.startsWith("<"))
/*     */       {
/* 395 */         if (str1.startsWith("\"")) {
/* 396 */           StringLiteralSymbol stringLiteralSymbol = (StringLiteralSymbol)paramTokenManager.getTokenSymbol(str1);
/* 397 */           if (stringLiteralSymbol != null && stringLiteralSymbol.label != null) {
/* 398 */             print(stringLiteralSymbol.label + "=");
/*     */           }
/* 400 */           println(str1 + "=" + b);
/*     */         } else {
/*     */           
/* 403 */           print(str1);
/*     */           
/* 405 */           TokenSymbol tokenSymbol = paramTokenManager.getTokenSymbol(str1);
/* 406 */           if (tokenSymbol == null) {
/* 407 */             this.antlrTool.warning("undefined token symbol: " + str1);
/*     */           
/*     */           }
/* 410 */           else if (tokenSymbol.getParaphrase() != null) {
/* 411 */             print("(" + tokenSymbol.getParaphrase() + ")");
/*     */           } 
/*     */           
/* 414 */           println("=" + b);
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 420 */     this.currentOutput.close();
/* 421 */     this.currentOutput = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String processStringForASTConstructor(String paramString) {
/* 430 */     return paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getASTCreateString(Vector paramVector);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getASTCreateString(GrammarAtom paramGrammarAtom, String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getBitsetName(int paramInt) {
/* 449 */     return "_tokenSet_" + paramInt;
/*     */   }
/*     */   
/*     */   public static String encodeLexerRuleName(String paramString) {
/* 453 */     return "m" + paramString;
/*     */   }
/*     */   
/*     */   public static String decodeLexerRuleName(String paramString) {
/* 457 */     if (paramString == null) {
/* 458 */       return null;
/*     */     }
/* 460 */     return paramString.substring(1, paramString.length());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String mapTreeId(String paramString, ActionTransInfo paramActionTransInfo);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int markBitsetForGen(BitSet paramBitSet) {
/* 484 */     for (byte b = 0; b < this.bitsetsUsed.size(); b++) {
/* 485 */       BitSet bitSet = (BitSet)this.bitsetsUsed.elementAt(b);
/* 486 */       if (paramBitSet.equals(bitSet))
/*     */       {
/* 488 */         return b;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 493 */     this.bitsetsUsed.appendElement(paramBitSet.clone());
/* 494 */     return this.bitsetsUsed.size() - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void print(String paramString) {
/* 502 */     if (paramString != null) {
/* 503 */       printTabs();
/* 504 */       this.currentOutput.print(paramString);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void printAction(String paramString) {
/* 514 */     if (paramString != null) {
/* 515 */       printTabs();
/* 516 */       _printAction(paramString);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void println(String paramString) {
/* 525 */     if (paramString != null) {
/* 526 */       printTabs();
/* 527 */       this.currentOutput.println(paramString);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void printTabs() {
/* 535 */     for (byte b = 1; b <= this.tabs; b++) {
/* 536 */       this.currentOutput.print("\t");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract String processActionForSpecialSymbols(String paramString, int paramInt, RuleBlock paramRuleBlock, ActionTransInfo paramActionTransInfo);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFOLLOWBitSet(String paramString, int paramInt) {
/* 550 */     GrammarSymbol grammarSymbol = this.grammar.getSymbol(paramString);
/* 551 */     if (!(grammarSymbol instanceof RuleSymbol)) {
/* 552 */       return null;
/*     */     }
/* 554 */     RuleBlock ruleBlock = ((RuleSymbol)grammarSymbol).getBlock();
/* 555 */     Lookahead lookahead = this.grammar.theLLkAnalyzer.FOLLOW(paramInt, ruleBlock.endNode);
/* 556 */     return getBitsetName(markBitsetForGen(lookahead.fset));
/*     */   }
/*     */ 
/*     */   
/*     */   public String getFIRSTBitSet(String paramString, int paramInt) {
/* 561 */     GrammarSymbol grammarSymbol = this.grammar.getSymbol(paramString);
/* 562 */     if (!(grammarSymbol instanceof RuleSymbol)) {
/* 563 */       return null;
/*     */     }
/* 565 */     RuleBlock ruleBlock = ((RuleSymbol)grammarSymbol).getBlock();
/* 566 */     Lookahead lookahead = this.grammar.theLLkAnalyzer.look(paramInt, ruleBlock);
/* 567 */     return getBitsetName(markBitsetForGen(lookahead.fset));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String removeAssignmentFromDeclaration(String paramString) {
/* 579 */     if (paramString.indexOf('=') >= 0) paramString = paramString.substring(0, paramString.indexOf('=')).trim(); 
/* 580 */     return paramString;
/*     */   }
/*     */ 
/*     */   
/*     */   private void reset() {
/* 585 */     this.tabs = 0;
/*     */     
/* 587 */     this.bitsetsUsed = new Vector();
/* 588 */     this.currentOutput = null;
/* 589 */     this.grammar = null;
/* 590 */     this.DEBUG_CODE_GENERATOR = false;
/* 591 */     this.makeSwitchThreshold = 2;
/* 592 */     this.bitsetTestThreshold = 4;
/*     */   }
/*     */   
/*     */   public static String reverseLexerRuleName(String paramString) {
/* 596 */     return paramString.substring(1, paramString.length());
/*     */   }
/*     */   
/*     */   public void setAnalyzer(LLkGrammarAnalyzer paramLLkGrammarAnalyzer) {
/* 600 */     this.analyzer = paramLLkGrammarAnalyzer;
/*     */   }
/*     */   
/*     */   public void setBehavior(DefineGrammarSymbols paramDefineGrammarSymbols) {
/* 604 */     this.behavior = paramDefineGrammarSymbols;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setGrammar(Grammar paramGrammar) {
/* 609 */     reset();
/* 610 */     this.grammar = paramGrammar;
/*     */     
/* 612 */     if (this.grammar.hasOption("codeGenMakeSwitchThreshold")) {
/*     */       try {
/* 614 */         this.makeSwitchThreshold = this.grammar.getIntegerOption("codeGenMakeSwitchThreshold");
/*     */       
/*     */       }
/* 617 */       catch (NumberFormatException numberFormatException) {
/* 618 */         Token token = this.grammar.getOption("codeGenMakeSwitchThreshold");
/* 619 */         this.antlrTool.error("option 'codeGenMakeSwitchThreshold' must be an integer", this.grammar.getClassName(), token.getLine(), token.getColumn());
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 628 */     if (this.grammar.hasOption("codeGenBitsetTestThreshold")) {
/*     */       try {
/* 630 */         this.bitsetTestThreshold = this.grammar.getIntegerOption("codeGenBitsetTestThreshold");
/*     */       
/*     */       }
/* 633 */       catch (NumberFormatException numberFormatException) {
/* 634 */         Token token = this.grammar.getOption("codeGenBitsetTestThreshold");
/* 635 */         this.antlrTool.error("option 'codeGenBitsetTestThreshold' must be an integer", this.grammar.getClassName(), token.getLine(), token.getColumn());
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 644 */     if (this.grammar.hasOption("codeGenDebug")) {
/* 645 */       Token token = this.grammar.getOption("codeGenDebug");
/* 646 */       if (token.getText().equals("true")) {
/*     */         
/* 648 */         this.DEBUG_CODE_GENERATOR = true;
/*     */       }
/* 650 */       else if (token.getText().equals("false")) {
/*     */         
/* 652 */         this.DEBUG_CODE_GENERATOR = false;
/*     */       } else {
/*     */         
/* 655 */         this.antlrTool.error("option 'codeGenDebug' must be true or false", this.grammar.getClassName(), token.getLine(), token.getColumn());
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setTool(Tool paramTool) {
/* 661 */     this.antlrTool = paramTool;
/*     */   }
/*     */ }


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\CodeGenerator.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
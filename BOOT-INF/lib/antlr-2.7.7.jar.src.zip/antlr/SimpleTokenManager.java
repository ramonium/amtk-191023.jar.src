/*     */ package antlr;
/*     */ 
/*     */ import antlr.collections.impl.Vector;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SimpleTokenManager
/*     */   implements TokenManager, Cloneable
/*     */ {
/*  17 */   protected int maxToken = 4;
/*     */   
/*     */   protected Vector vocabulary;
/*     */   
/*     */   private Hashtable table;
/*     */   
/*     */   protected Tool antlrTool;
/*     */   
/*     */   protected String name;
/*     */   
/*     */   protected boolean readOnly = false;
/*     */   
/*     */   SimpleTokenManager(String paramString, Tool paramTool) {
/*  30 */     this.antlrTool = paramTool;
/*  31 */     this.name = paramString;
/*     */     
/*  33 */     this.vocabulary = new Vector(1);
/*  34 */     this.table = new Hashtable();
/*     */ 
/*     */     
/*  37 */     TokenSymbol tokenSymbol = new TokenSymbol("EOF");
/*  38 */     tokenSymbol.setTokenType(1);
/*  39 */     define(tokenSymbol);
/*     */ 
/*     */     
/*  42 */     this.vocabulary.ensureCapacity(3);
/*  43 */     this.vocabulary.setElementAt("NULL_TREE_LOOKAHEAD", 3);
/*     */   }
/*     */   
/*     */   public Object clone() {
/*     */     SimpleTokenManager simpleTokenManager;
/*     */     try {
/*  49 */       simpleTokenManager = (SimpleTokenManager)super.clone();
/*  50 */       simpleTokenManager.vocabulary = (Vector)this.vocabulary.clone();
/*  51 */       simpleTokenManager.table = (Hashtable)this.table.clone();
/*  52 */       simpleTokenManager.maxToken = this.maxToken;
/*  53 */       simpleTokenManager.antlrTool = this.antlrTool;
/*  54 */       simpleTokenManager.name = this.name;
/*     */     }
/*  56 */     catch (CloneNotSupportedException cloneNotSupportedException) {
/*  57 */       this.antlrTool.panic("cannot clone token manager");
/*  58 */       return null;
/*     */     } 
/*  60 */     return simpleTokenManager;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void define(TokenSymbol paramTokenSymbol) {
/*  66 */     this.vocabulary.ensureCapacity(paramTokenSymbol.getTokenType());
/*  67 */     this.vocabulary.setElementAt(paramTokenSymbol.getId(), paramTokenSymbol.getTokenType());
/*     */     
/*  69 */     mapToTokenSymbol(paramTokenSymbol.getId(), paramTokenSymbol);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  74 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTokenStringAt(int paramInt) {
/*  79 */     return (String)this.vocabulary.elementAt(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public TokenSymbol getTokenSymbol(String paramString) {
/*  84 */     return (TokenSymbol)this.table.get(paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public TokenSymbol getTokenSymbolAt(int paramInt) {
/*  89 */     return getTokenSymbol(getTokenStringAt(paramInt));
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumeration getTokenSymbolElements() {
/*  94 */     return this.table.elements();
/*     */   }
/*     */   
/*     */   public Enumeration getTokenSymbolKeys() {
/*  98 */     return this.table.keys();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector getVocabulary() {
/* 105 */     return this.vocabulary;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadOnly() {
/* 110 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void mapToTokenSymbol(String paramString, TokenSymbol paramTokenSymbol) {
/* 116 */     this.table.put(paramString, paramTokenSymbol);
/*     */   }
/*     */ 
/*     */   
/*     */   public int maxTokenType() {
/* 121 */     return this.maxToken - 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int nextTokenType() {
/* 126 */     return this.maxToken++;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setName(String paramString) {
/* 131 */     this.name = paramString;
/*     */   }
/*     */   
/*     */   public void setReadOnly(boolean paramBoolean) {
/* 135 */     this.readOnly = paramBoolean;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean tokenDefined(String paramString) {
/* 140 */     return this.table.containsKey(paramString);
/*     */   }
/*     */ }


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\SimpleTokenManager.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
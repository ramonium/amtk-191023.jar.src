/*    */ package antlr;
/*    */ 
/*    */ import antlr.collections.AST;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DumpASTVisitor
/*    */   implements ASTVisitor
/*    */ {
/* 16 */   protected int level = 0;
/*    */ 
/*    */   
/*    */   private void tabs() {
/* 20 */     for (byte b = 0; b < this.level; b++) {
/* 21 */       System.out.print("   ");
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void visit(AST paramAST) {
/* 27 */     boolean bool = false;
/*    */     AST aST;
/* 29 */     for (aST = paramAST; aST != null; aST = aST.getNextSibling()) {
/* 30 */       if (aST.getFirstChild() != null) {
/* 31 */         bool = false;
/*    */         
/*    */         break;
/*    */       } 
/*    */     } 
/* 36 */     for (aST = paramAST; aST != null; aST = aST.getNextSibling()) {
/* 37 */       if (!bool || aST == paramAST) {
/* 38 */         tabs();
/*    */       }
/* 40 */       if (aST.getText() == null) {
/* 41 */         System.out.print("nil");
/*    */       } else {
/*    */         
/* 44 */         System.out.print(aST.getText());
/*    */       } 
/*    */       
/* 47 */       System.out.print(" [" + aST.getType() + "] ");
/*    */       
/* 49 */       if (bool) {
/* 50 */         System.out.print(" ");
/*    */       } else {
/*    */         
/* 53 */         System.out.println("");
/*    */       } 
/*    */       
/* 56 */       if (aST.getFirstChild() != null) {
/* 57 */         this.level++;
/* 58 */         visit(aST.getFirstChild());
/* 59 */         this.level--;
/*    */       } 
/*    */     } 
/*    */     
/* 63 */     if (bool)
/* 64 */       System.out.println(""); 
/*    */   }
/*    */ }


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\DumpASTVisitor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
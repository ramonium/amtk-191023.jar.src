/*     */ package antlr.collections.impl;
/*     */ 
/*     */ import antlr.collections.List;
/*     */ import antlr.collections.Stack;
/*     */ import java.util.Enumeration;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LList
/*     */   implements List, Stack
/*     */ {
/*  22 */   protected LLCell head = null; protected LLCell tail = null;
/*  23 */   protected int length = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(Object paramObject) {
/*  30 */     append(paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void append(Object paramObject) {
/*  37 */     LLCell lLCell = new LLCell(paramObject);
/*  38 */     if (this.length == 0) {
/*  39 */       this.head = this.tail = lLCell;
/*  40 */       this.length = 1;
/*     */     } else {
/*     */       
/*  43 */       this.tail.next = lLCell;
/*  44 */       this.tail = lLCell;
/*  45 */       this.length++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object deleteHead() throws NoSuchElementException {
/*  54 */     if (this.head == null) throw new NoSuchElementException(); 
/*  55 */     Object object = this.head.data;
/*  56 */     this.head = this.head.next;
/*  57 */     this.length--;
/*  58 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object elementAt(int paramInt) throws NoSuchElementException {
/*  67 */     byte b = 0;
/*  68 */     for (LLCell lLCell = this.head; lLCell != null; lLCell = lLCell.next) {
/*  69 */       if (paramInt == b) return lLCell.data; 
/*  70 */       b++;
/*     */     } 
/*  72 */     throw new NoSuchElementException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumeration elements() {
/*  77 */     return new LLEnumeration(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public int height() {
/*  82 */     return this.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean includes(Object paramObject) {
/*  90 */     for (LLCell lLCell = this.head; lLCell != null; lLCell = lLCell.next) {
/*  91 */       if (lLCell.data.equals(paramObject)) return true; 
/*     */     } 
/*  93 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void insertHead(Object paramObject) {
/* 101 */     LLCell lLCell = this.head;
/* 102 */     this.head = new LLCell(paramObject);
/* 103 */     this.head.next = lLCell;
/* 104 */     this.length++;
/* 105 */     if (this.tail == null) this.tail = this.head;
/*     */   
/*     */   }
/*     */   
/*     */   public int length() {
/* 110 */     return this.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object pop() throws NoSuchElementException {
/* 118 */     return deleteHead();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void push(Object paramObject) {
/* 127 */     insertHead(paramObject);
/*     */   }
/*     */   
/*     */   public Object top() throws NoSuchElementException {
/* 131 */     if (this.head == null) throw new NoSuchElementException(); 
/* 132 */     return this.head.data;
/*     */   }
/*     */ }


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\collections\impl\LList.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
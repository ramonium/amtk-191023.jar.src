/*     */ package antlr.collections.impl;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Vector
/*     */   implements Cloneable
/*     */ {
/*     */   protected Object[] data;
/*  17 */   protected int lastElement = -1;
/*     */   
/*     */   public Vector() {
/*  20 */     this(10);
/*     */   }
/*     */   
/*     */   public Vector(int paramInt) {
/*  24 */     this.data = new Object[paramInt];
/*     */   }
/*     */   
/*     */   public synchronized void appendElement(Object paramObject) {
/*  28 */     ensureCapacity(this.lastElement + 2);
/*  29 */     this.data[++this.lastElement] = paramObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int capacity() {
/*  36 */     return this.data.length;
/*     */   }
/*     */   
/*     */   public Object clone() {
/*  40 */     Vector vector = null;
/*     */     try {
/*  42 */       vector = (Vector)super.clone();
/*     */     }
/*  44 */     catch (CloneNotSupportedException cloneNotSupportedException) {
/*  45 */       System.err.println("cannot clone Vector.super");
/*  46 */       return null;
/*     */     } 
/*  48 */     vector.data = new Object[size()];
/*  49 */     System.arraycopy(this.data, 0, vector.data, 0, size());
/*  50 */     return vector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Object elementAt(int paramInt) {
/*  60 */     if (paramInt >= this.data.length) {
/*  61 */       throw new ArrayIndexOutOfBoundsException(paramInt + " >= " + this.data.length);
/*     */     }
/*  63 */     if (paramInt < 0) {
/*  64 */       throw new ArrayIndexOutOfBoundsException(paramInt + " < 0 ");
/*     */     }
/*  66 */     return this.data[paramInt];
/*     */   }
/*     */   
/*     */   public synchronized Enumeration elements() {
/*  70 */     return new VectorEnumerator(this);
/*     */   }
/*     */   
/*     */   public synchronized void ensureCapacity(int paramInt) {
/*  74 */     if (paramInt + 1 > this.data.length) {
/*  75 */       Object[] arrayOfObject = this.data;
/*  76 */       int i = this.data.length * 2;
/*  77 */       if (paramInt + 1 > i) {
/*  78 */         i = paramInt + 1;
/*     */       }
/*  80 */       this.data = new Object[i];
/*  81 */       System.arraycopy(arrayOfObject, 0, this.data, 0, arrayOfObject.length);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized boolean removeElement(Object paramObject) {
/*     */     byte b;
/*  88 */     for (b = 0; b <= this.lastElement && this.data[b] != paramObject; b++);
/*     */ 
/*     */     
/*  91 */     if (b <= this.lastElement) {
/*  92 */       this.data[b] = null;
/*  93 */       int i = this.lastElement - b;
/*  94 */       if (i > 0) {
/*  95 */         System.arraycopy(this.data, b + 1, this.data, b, i);
/*     */       }
/*  97 */       this.lastElement--;
/*  98 */       return true;
/*     */     } 
/*     */     
/* 101 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setElementAt(Object paramObject, int paramInt) {
/* 106 */     if (paramInt >= this.data.length) {
/* 107 */       throw new ArrayIndexOutOfBoundsException(paramInt + " >= " + this.data.length);
/*     */     }
/* 109 */     this.data[paramInt] = paramObject;
/*     */     
/* 111 */     if (paramInt > this.lastElement) {
/* 112 */       this.lastElement = paramInt;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 119 */     return this.lastElement + 1;
/*     */   }
/*     */ }


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\collections\impl\Vector.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
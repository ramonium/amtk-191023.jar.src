/*    */ package antlr.collections.impl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LLCell
/*    */ {
/*    */   Object data;
/*    */   LLCell next;
/*    */   
/*    */   public LLCell(Object paramObject) {
/* 23 */     this.data = paramObject;
/*    */   }
/*    */ }


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\collections\impl\LLCell.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package antlr.collections.impl;
/*    */ 
/*    */ import antlr.collections.AST;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ASTArray
/*    */ {
/* 18 */   public int size = 0;
/*    */   
/*    */   public AST[] array;
/*    */   
/*    */   public ASTArray(int paramInt) {
/* 23 */     this.array = new AST[paramInt];
/*    */   }
/*    */   
/*    */   public ASTArray add(AST paramAST) {
/* 27 */     this.array[this.size++] = paramAST;
/* 28 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\collections\impl\ASTArray.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
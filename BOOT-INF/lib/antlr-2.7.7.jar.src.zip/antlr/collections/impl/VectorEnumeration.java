/*    */ package antlr.collections.impl;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class VectorEnumeration
/*    */   implements Enumeration
/*    */ {
/*    */   Vector vector;
/*    */   int i;
/*    */   
/*    */   VectorEnumeration(Vector paramVector) {
/* 23 */     this.vector = paramVector;
/* 24 */     this.i = 0;
/*    */   }
/*    */   
/*    */   public boolean hasMoreElements() {
/* 28 */     synchronized (this.vector) {
/* 29 */       return (this.i <= this.vector.lastElement);
/*    */     } 
/*    */   }
/*    */   
/*    */   public Object nextElement() {
/* 34 */     synchronized (this.vector) {
/* 35 */       if (this.i <= this.vector.lastElement) {
/* 36 */         return this.vector.data[this.i++];
/*    */       }
/* 38 */       throw new NoSuchElementException("VectorEnumerator");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\collections\impl\VectorEnumeration.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package antlr;
/*     */ 
/*     */ import antlr.collections.impl.BitSet;
/*     */ import antlr.collections.impl.Vector;
/*     */ import antlr.preprocessor.Tool;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Reader;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Tool
/*     */ {
/*  26 */   public static String version = "";
/*     */ 
/*     */   
/*     */   ToolErrorHandler errorHandler;
/*     */ 
/*     */   
/*     */   protected boolean hasError = false;
/*     */ 
/*     */   
/*     */   boolean genDiagnostics = false;
/*     */ 
/*     */   
/*     */   boolean genDocBook = false;
/*     */ 
/*     */   
/*     */   boolean genHTML = false;
/*     */ 
/*     */   
/*  44 */   protected String outputDir = ".";
/*     */   
/*     */   protected String grammarFile;
/*     */   
/*  48 */   transient Reader f = new InputStreamReader(System.in);
/*     */ 
/*     */ 
/*     */   
/*  52 */   protected String literalsPrefix = "LITERAL_";
/*     */   
/*     */   protected boolean upperCaseMangledLiterals = false;
/*     */   
/*  56 */   protected NameSpace nameSpace = null;
/*  57 */   protected String namespaceAntlr = null;
/*  58 */   protected String namespaceStd = null;
/*     */   
/*     */   protected boolean genHashLines = true;
/*     */   protected boolean noConstructors = false;
/*  62 */   private BitSet cmdLineArgValid = new BitSet();
/*     */ 
/*     */   
/*     */   public Tool() {
/*  66 */     this.errorHandler = new DefaultToolErrorHandler(this);
/*     */   }
/*     */   
/*     */   public String getGrammarFile() {
/*  70 */     return this.grammarFile;
/*     */   }
/*     */   
/*     */   public boolean hasError() {
/*  74 */     return this.hasError;
/*     */   }
/*     */   
/*     */   public NameSpace getNameSpace() {
/*  78 */     return this.nameSpace;
/*     */   }
/*     */   
/*     */   public String getNamespaceStd() {
/*  82 */     return this.namespaceStd;
/*     */   }
/*     */   
/*     */   public String getNamespaceAntlr() {
/*  86 */     return this.namespaceAntlr;
/*     */   }
/*     */   
/*     */   public boolean getGenHashLines() {
/*  90 */     return this.genHashLines;
/*     */   }
/*     */   
/*     */   public String getLiteralsPrefix() {
/*  94 */     return this.literalsPrefix;
/*     */   }
/*     */   
/*     */   public boolean getUpperCaseMangledLiterals() {
/*  98 */     return this.upperCaseMangledLiterals;
/*     */   }
/*     */   
/*     */   public void setFileLineFormatter(FileLineFormatter paramFileLineFormatter) {
/* 102 */     FileLineFormatter.setFormatter(paramFileLineFormatter);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void checkForInvalidArguments(String[] paramArrayOfString, BitSet paramBitSet) {
/* 107 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/* 108 */       if (!paramBitSet.member(b)) {
/* 109 */         warning("invalid command-line argument: " + paramArrayOfString[b] + "; ignored");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void copyFile(String paramString1, String paramString2) throws IOException {
/* 121 */     File file1 = new File(paramString1);
/* 122 */     File file2 = new File(paramString2);
/* 123 */     BufferedReader bufferedReader = null;
/* 124 */     BufferedWriter bufferedWriter = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 131 */       if (!file1.exists() || !file1.isFile()) {
/* 132 */         throw new FileCopyException("FileCopy: no such source file: " + paramString1);
/*     */       }
/* 134 */       if (!file1.canRead()) {
/* 135 */         throw new FileCopyException("FileCopy: source file is unreadable: " + paramString1);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 141 */       if (file2.exists()) {
/* 142 */         if (file2.isFile()) {
/* 143 */           DataInputStream dataInputStream = new DataInputStream(System.in);
/*     */ 
/*     */           
/* 146 */           if (!file2.canWrite()) {
/* 147 */             throw new FileCopyException("FileCopy: destination file is unwriteable: " + paramString2);
/*     */ 
/*     */ 
/*     */           
/*     */           }
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */ 
/*     */           
/* 159 */           throw new FileCopyException("FileCopy: destination is not a file: " + paramString2);
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 164 */         File file = parent(file2);
/* 165 */         if (!file.exists()) {
/* 166 */           throw new FileCopyException("FileCopy: destination directory doesn't exist: " + paramString2);
/*     */         }
/* 168 */         if (!file.canWrite()) {
/* 169 */           throw new FileCopyException("FileCopy: destination directory is unwriteable: " + paramString2);
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 175 */       bufferedReader = new BufferedReader(new FileReader(file1));
/* 176 */       bufferedWriter = new BufferedWriter(new FileWriter(file2));
/*     */       
/* 178 */       char[] arrayOfChar = new char[1024];
/*     */       while (true) {
/* 180 */         int i = bufferedReader.read(arrayOfChar, 0, 1024);
/* 181 */         if (i == -1)
/* 182 */           break;  bufferedWriter.write(arrayOfChar, 0, i);
/*     */       }
/*     */     
/*     */     } finally {
/*     */       
/* 187 */       if (bufferedReader != null) {
/*     */         try {
/* 189 */           bufferedReader.close();
/*     */         }
/* 191 */         catch (IOException iOException) {}
/*     */       }
/*     */ 
/*     */       
/* 195 */       if (bufferedWriter != null) {
/*     */         try {
/* 197 */           bufferedWriter.close();
/*     */         }
/* 199 */         catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doEverythingWrapper(String[] paramArrayOfString) {
/* 211 */     int i = doEverything(paramArrayOfString);
/* 212 */     System.exit(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doEverything(String[] paramArrayOfString) {
/* 223 */     Tool tool = new Tool(this, paramArrayOfString);
/*     */     
/* 225 */     boolean bool = tool.preprocess();
/* 226 */     String[] arrayOfString = tool.preprocessedArgList();
/*     */ 
/*     */     
/* 229 */     processArguments(arrayOfString);
/* 230 */     if (!bool) {
/* 231 */       return 1;
/*     */     }
/*     */     
/* 234 */     this.f = getGrammarReader();
/*     */     
/* 236 */     ANTLRLexer aNTLRLexer = new ANTLRLexer(this.f);
/* 237 */     TokenBuffer tokenBuffer = new TokenBuffer(aNTLRLexer);
/* 238 */     LLkAnalyzer lLkAnalyzer = new LLkAnalyzer(this);
/* 239 */     MakeGrammar makeGrammar = new MakeGrammar(this, paramArrayOfString, lLkAnalyzer);
/*     */     
/*     */     try {
/* 242 */       ANTLRParser aNTLRParser = new ANTLRParser(tokenBuffer, makeGrammar, this);
/* 243 */       aNTLRParser.setFilename(this.grammarFile);
/* 244 */       aNTLRParser.grammar();
/* 245 */       if (hasError()) {
/* 246 */         fatalError("Exiting due to errors.");
/*     */       }
/* 248 */       checkForInvalidArguments(arrayOfString, this.cmdLineArgValid);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 255 */       String str = "antlr." + getLanguage(makeGrammar) + "CodeGenerator";
/*     */       try {
/* 257 */         CodeGenerator codeGenerator = (CodeGenerator)Utils.createInstanceOf(str);
/* 258 */         codeGenerator.setBehavior(makeGrammar);
/* 259 */         codeGenerator.setAnalyzer(lLkAnalyzer);
/* 260 */         codeGenerator.setTool(this);
/* 261 */         codeGenerator.gen();
/*     */       }
/* 263 */       catch (ClassNotFoundException classNotFoundException) {
/* 264 */         panic("Cannot instantiate code-generator: " + str);
/*     */       }
/* 266 */       catch (InstantiationException instantiationException) {
/* 267 */         panic("Cannot instantiate code-generator: " + str);
/*     */       }
/* 269 */       catch (IllegalArgumentException illegalArgumentException) {
/* 270 */         panic("Cannot instantiate code-generator: " + str);
/*     */       }
/* 272 */       catch (IllegalAccessException illegalAccessException) {
/* 273 */         panic("code-generator class '" + str + "' is not accessible");
/*     */       }
/*     */     
/* 276 */     } catch (RecognitionException recognitionException) {
/* 277 */       fatalError("Unhandled parser error: " + recognitionException.getMessage());
/*     */     }
/* 279 */     catch (TokenStreamException tokenStreamException) {
/* 280 */       fatalError("TokenStreamException: " + tokenStreamException.getMessage());
/*     */     } 
/* 282 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void error(String paramString) {
/* 289 */     this.hasError = true;
/* 290 */     System.err.println("error: " + paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void error(String paramString1, String paramString2, int paramInt1, int paramInt2) {
/* 300 */     this.hasError = true;
/* 301 */     System.err.println(FileLineFormatter.getFormatter().getFormatString(paramString2, paramInt1, paramInt2) + paramString1);
/*     */   }
/*     */ 
/*     */   
/*     */   public String fileMinusPath(String paramString) {
/* 306 */     String str = System.getProperty("file.separator");
/* 307 */     int i = paramString.lastIndexOf(str);
/* 308 */     if (i == -1) {
/* 309 */       return paramString;
/*     */     }
/* 311 */     return paramString.substring(i + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLanguage(MakeGrammar paramMakeGrammar) {
/* 318 */     if (this.genDiagnostics) {
/* 319 */       return "Diagnostic";
/*     */     }
/* 321 */     if (this.genHTML) {
/* 322 */       return "HTML";
/*     */     }
/* 324 */     if (this.genDocBook) {
/* 325 */       return "DocBook";
/*     */     }
/* 327 */     return paramMakeGrammar.language;
/*     */   }
/*     */   
/*     */   public String getOutputDirectory() {
/* 331 */     return this.outputDir;
/*     */   }
/*     */   
/*     */   private static void help() {
/* 335 */     System.err.println("usage: java antlr.Tool [args] file.g");
/* 336 */     System.err.println("  -o outputDir       specify output directory where all output generated.");
/* 337 */     System.err.println("  -glib superGrammar specify location of supergrammar file.");
/* 338 */     System.err.println("  -debug             launch the ParseView debugger upon parser invocation.");
/* 339 */     System.err.println("  -html              generate a html file from your grammar.");
/* 340 */     System.err.println("  -docbook           generate a docbook sgml file from your grammar.");
/* 341 */     System.err.println("  -diagnostic        generate a textfile with diagnostics.");
/* 342 */     System.err.println("  -trace             have all rules call traceIn/traceOut.");
/* 343 */     System.err.println("  -traceLexer        have lexer rules call traceIn/traceOut.");
/* 344 */     System.err.println("  -traceParser       have parser rules call traceIn/traceOut.");
/* 345 */     System.err.println("  -traceTreeParser   have tree parser rules call traceIn/traceOut.");
/* 346 */     System.err.println("  -h|-help|--help    this message");
/*     */   }
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {
/* 350 */     System.err.println("ANTLR Parser Generator   Version 2.7.7 (20060906)   1989-2005");
/*     */     
/* 352 */     version = "2.7.7 (20060906)";
/*     */     
/*     */     try {
/* 355 */       boolean bool = false;
/*     */       
/* 357 */       if (paramArrayOfString.length == 0) {
/* 358 */         bool = true;
/*     */       } else {
/*     */         
/* 361 */         for (byte b = 0; b < paramArrayOfString.length; b++) {
/* 362 */           if (paramArrayOfString[b].equals("-h") || paramArrayOfString[b].equals("-help") || paramArrayOfString[b].equals("--help")) {
/*     */ 
/*     */ 
/*     */             
/* 366 */             bool = true;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 372 */       if (bool) {
/* 373 */         help();
/*     */       } else {
/*     */         
/* 376 */         Tool tool = new Tool();
/* 377 */         tool.doEverything(paramArrayOfString);
/* 378 */         tool = null;
/*     */       }
/*     */     
/* 381 */     } catch (Exception exception) {
/* 382 */       System.err.println(System.getProperty("line.separator") + System.getProperty("line.separator"));
/*     */       
/* 384 */       System.err.println("#$%%*&@# internal error: " + exception.toString());
/* 385 */       System.err.println("[complain to nearest government official");
/* 386 */       System.err.println(" or send hate-mail to parrt@antlr.org;");
/* 387 */       System.err.println(" please send stack trace with report.]" + System.getProperty("line.separator"));
/*     */       
/* 389 */       exception.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrintWriter openOutputFile(String paramString) throws IOException {
/* 397 */     if (this.outputDir != ".") {
/* 398 */       File file = new File(this.outputDir);
/* 399 */       if (!file.exists())
/* 400 */         file.mkdirs(); 
/*     */     } 
/* 402 */     return new PrintWriter(new PreservingFileWriter(this.outputDir + System.getProperty("file.separator") + paramString));
/*     */   }
/*     */   
/*     */   public Reader getGrammarReader() {
/* 406 */     BufferedReader bufferedReader = null;
/*     */     try {
/* 408 */       if (this.grammarFile != null) {
/* 409 */         bufferedReader = new BufferedReader(new FileReader(this.grammarFile));
/*     */       }
/*     */     }
/* 412 */     catch (IOException iOException) {
/* 413 */       fatalError("cannot open grammar file " + this.grammarFile);
/*     */     } 
/* 415 */     return bufferedReader;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void reportException(Exception paramException, String paramString) {
/* 421 */     System.err.println((paramString == null) ? paramException.getMessage() : (paramString + ": " + paramException.getMessage()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reportProgress(String paramString) {
/* 428 */     System.out.println(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fatalError(String paramString) {
/* 444 */     System.err.println(paramString);
/* 445 */     Utils.error(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void panic() {
/* 455 */     fatalError("panic");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void panic(String paramString) {
/* 466 */     fatalError("panic: " + paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File parent(File paramFile) {
/* 473 */     String str = paramFile.getParent();
/* 474 */     if (str == null) {
/* 475 */       if (paramFile.isAbsolute()) {
/* 476 */         return new File(File.separator);
/*     */       }
/* 478 */       return new File(System.getProperty("user.dir"));
/*     */     } 
/* 480 */     return new File(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Vector parseSeparatedList(String paramString, char paramChar) {
/* 487 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, String.valueOf(paramChar));
/*     */     
/* 489 */     Vector vector = new Vector(10);
/* 490 */     while (stringTokenizer.hasMoreTokens()) {
/* 491 */       vector.appendElement(stringTokenizer.nextToken());
/*     */     }
/* 493 */     if (vector.size() == 0) return null; 
/* 494 */     return vector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String pathToFile(String paramString) {
/* 501 */     String str = System.getProperty("file.separator");
/* 502 */     int i = paramString.lastIndexOf(str);
/* 503 */     if (i == -1)
/*     */     {
/* 505 */       return "." + System.getProperty("file.separator");
/*     */     }
/* 507 */     return paramString.substring(0, i + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processArguments(String[] paramArrayOfString) {
/* 516 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/* 517 */       if (paramArrayOfString[b].equals("-diagnostic")) {
/* 518 */         this.genDiagnostics = true;
/* 519 */         this.genHTML = false;
/* 520 */         setArgOK(b);
/*     */       }
/* 522 */       else if (paramArrayOfString[b].equals("-o")) {
/* 523 */         setArgOK(b);
/* 524 */         if (b + 1 >= paramArrayOfString.length) {
/* 525 */           error("missing output directory with -o option; ignoring");
/*     */         } else {
/*     */           
/* 528 */           b++;
/* 529 */           setOutputDirectory(paramArrayOfString[b]);
/* 530 */           setArgOK(b);
/*     */         }
/*     */       
/* 533 */       } else if (paramArrayOfString[b].equals("-html")) {
/* 534 */         this.genHTML = true;
/* 535 */         this.genDiagnostics = false;
/* 536 */         setArgOK(b);
/*     */       }
/* 538 */       else if (paramArrayOfString[b].equals("-docbook")) {
/* 539 */         this.genDocBook = true;
/* 540 */         this.genDiagnostics = false;
/* 541 */         setArgOK(b);
/*     */       
/*     */       }
/* 544 */       else if (paramArrayOfString[b].charAt(0) != '-') {
/*     */         
/* 546 */         this.grammarFile = paramArrayOfString[b];
/* 547 */         setArgOK(b);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setArgOK(int paramInt) {
/* 554 */     this.cmdLineArgValid.add(paramInt);
/*     */   }
/*     */   
/*     */   public void setOutputDirectory(String paramString) {
/* 558 */     this.outputDir = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void toolError(String paramString) {
/* 565 */     System.err.println("error: " + paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void warning(String paramString) {
/* 572 */     System.err.println("warning: " + paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void warning(String paramString1, String paramString2, int paramInt1, int paramInt2) {
/* 582 */     System.err.println(FileLineFormatter.getFormatter().getFormatString(paramString2, paramInt1, paramInt2) + "warning:" + paramString1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void warning(String[] paramArrayOfString, String paramString, int paramInt1, int paramInt2) {
/* 592 */     if (paramArrayOfString == null || paramArrayOfString.length == 0) {
/* 593 */       panic("bad multi-line message to Tool.warning");
/*     */     }
/* 595 */     System.err.println(FileLineFormatter.getFormatter().getFormatString(paramString, paramInt1, paramInt2) + "warning:" + paramArrayOfString[0]);
/*     */     
/* 597 */     for (byte b = 1; b < paramArrayOfString.length; b++) {
/* 598 */       System.err.println(FileLineFormatter.getFormatter().getFormatString(paramString, paramInt1, paramInt2) + "    " + paramArrayOfString[b]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNameSpace(String paramString) {
/* 610 */     if (null == this.nameSpace)
/* 611 */       this.nameSpace = new NameSpace(StringUtils.stripFrontBack(paramString, "\"", "\"")); 
/*     */   }
/*     */ }


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\Tool.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package antlr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ANTLRHashString
/*     */ {
/*     */   private String s;
/*     */   private char[] buf;
/*     */   private int len;
/*     */   private CharScanner lexer;
/*     */   private static final int prime = 151;
/*     */   
/*     */   public ANTLRHashString(char[] paramArrayOfchar, int paramInt, CharScanner paramCharScanner) {
/*  24 */     this.lexer = paramCharScanner;
/*  25 */     setBuffer(paramArrayOfchar, paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public ANTLRHashString(CharScanner paramCharScanner) {
/*  30 */     this.lexer = paramCharScanner;
/*     */   }
/*     */   
/*     */   public ANTLRHashString(String paramString, CharScanner paramCharScanner) {
/*  34 */     this.lexer = paramCharScanner;
/*  35 */     setString(paramString);
/*     */   }
/*     */   
/*     */   private final char charAt(int paramInt) {
/*  39 */     return (this.s != null) ? this.s.charAt(paramInt) : this.buf[paramInt];
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*     */     ANTLRHashString aNTLRHashString;
/*  44 */     if (!(paramObject instanceof ANTLRHashString) && !(paramObject instanceof String)) {
/*  45 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  49 */     if (paramObject instanceof String) {
/*  50 */       aNTLRHashString = new ANTLRHashString((String)paramObject, this.lexer);
/*     */     } else {
/*     */       
/*  53 */       aNTLRHashString = (ANTLRHashString)paramObject;
/*     */     } 
/*  55 */     int i = length();
/*  56 */     if (aNTLRHashString.length() != i) {
/*  57 */       return false;
/*     */     }
/*  59 */     if (this.lexer.getCaseSensitiveLiterals()) {
/*  60 */       for (byte b = 0; b < i; b++) {
/*  61 */         if (charAt(b) != aNTLRHashString.charAt(b)) {
/*  62 */           return false;
/*     */         }
/*     */       } 
/*     */     } else {
/*     */       
/*  67 */       for (byte b = 0; b < i; b++) {
/*  68 */         if (this.lexer.toLower(charAt(b)) != this.lexer.toLower(aNTLRHashString.charAt(b))) {
/*  69 */           return false;
/*     */         }
/*     */       } 
/*     */     } 
/*  73 */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  77 */     int i = 0;
/*  78 */     int j = length();
/*     */     
/*  80 */     if (this.lexer.getCaseSensitiveLiterals()) {
/*  81 */       for (byte b = 0; b < j; b++) {
/*  82 */         i = i * 151 + charAt(b);
/*     */       }
/*     */     } else {
/*     */       
/*  86 */       for (byte b = 0; b < j; b++) {
/*  87 */         i = i * 151 + this.lexer.toLower(charAt(b));
/*     */       }
/*     */     } 
/*  90 */     return i;
/*     */   }
/*     */   
/*     */   private final int length() {
/*  94 */     return (this.s != null) ? this.s.length() : this.len;
/*     */   }
/*     */   
/*     */   public void setBuffer(char[] paramArrayOfchar, int paramInt) {
/*  98 */     this.buf = paramArrayOfchar;
/*  99 */     this.len = paramInt;
/* 100 */     this.s = null;
/*     */   }
/*     */   
/*     */   public void setString(String paramString) {
/* 104 */     this.s = paramString;
/* 105 */     this.buf = null;
/*     */   }
/*     */ }


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\ANTLRHashString.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
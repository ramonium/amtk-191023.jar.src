/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringUtils
/*    */ {
/*    */   public static String stripBack(String paramString, char paramChar) {
/* 11 */     while (paramString.length() > 0 && paramString.charAt(paramString.length() - 1) == paramChar) {
/* 12 */       paramString = paramString.substring(0, paramString.length() - 1);
/*    */     }
/* 14 */     return paramString;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String stripBack(String paramString1, String paramString2) {
/*    */     while (true) {
/* 26 */       boolean bool = false;
/* 27 */       for (byte b = 0; b < paramString2.length(); b++) {
/* 28 */         char c = paramString2.charAt(b);
/* 29 */         while (paramString1.length() > 0 && paramString1.charAt(paramString1.length() - 1) == c) {
/* 30 */           bool = true;
/* 31 */           paramString1 = paramString1.substring(0, paramString1.length() - 1);
/*    */         } 
/*    */       } 
/* 34 */       if (!bool) {
/* 35 */         return paramString1;
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String stripFront(String paramString, char paramChar) {
/* 45 */     while (paramString.length() > 0 && paramString.charAt(0) == paramChar) {
/* 46 */       paramString = paramString.substring(1);
/*    */     }
/* 48 */     return paramString;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String stripFront(String paramString1, String paramString2) {
/*    */     while (true) {
/* 60 */       boolean bool = false;
/* 61 */       for (byte b = 0; b < paramString2.length(); b++) {
/* 62 */         char c = paramString2.charAt(b);
/* 63 */         while (paramString1.length() > 0 && paramString1.charAt(0) == c) {
/* 64 */           bool = true;
/* 65 */           paramString1 = paramString1.substring(1);
/*    */         } 
/*    */       } 
/* 68 */       if (!bool) {
/* 69 */         return paramString1;
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String stripFrontBack(String paramString1, String paramString2, String paramString3) {
/* 80 */     int i = paramString1.indexOf(paramString2);
/* 81 */     int j = paramString1.lastIndexOf(paramString3);
/* 82 */     if (i == -1 || j == -1) return paramString1; 
/* 83 */     return paramString1.substring(i + 1, j);
/*    */   }
/*    */ }


/* Location:              C:\Users\mouad\Documents\AMTK\amtk-191023.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\StringUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
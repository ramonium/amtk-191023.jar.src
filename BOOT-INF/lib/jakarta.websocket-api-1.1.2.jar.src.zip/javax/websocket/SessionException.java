/*
 * Copyright (c) 2018 Oracle and/or its affiliates and others.
 * All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0, which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * This Source Code may also be made available under the following Secondary
 * Licenses when the conditions for such availability set forth in the
 * Eclipse Public License v. 2.0 are satisfied: GNU General Public License,
 * version 2 with the GNU Classpath Exception, which is available at
 * https://www.gnu.org/software/classpath/license.html.
 *
 * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
 */

package javax.websocket;

/**
 * A SessionException represents a general exception type reporting problems occurring on a websocket session.
 *
 * @author dannycoward
 */
public class SessionException extends Exception {
    private final Session session;
    private static final long serialVersionUID = 014;

    /**
     * Creates a new instance of this exception with the given message, the wrapped cause of the exception and the
     * session with which the problem is associated.
     *
     * @param message a description of the problem
     * @param cause   the error that caused the problem
     * @param session the session on which the problem occurred.
     */
    public SessionException(String message, Throwable cause, Session session) {
        super(message, cause);
        this.session = session;
    }

    /**
     * Return the Session on which the problem occurred.
     *
     * @return the session
     */
    public Session getSession() {
        return this.session;
    }
}

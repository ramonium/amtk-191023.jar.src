/**
 * Utility classes for using SASL mechanisms atop NIO or XNIO APIs.
 */
package org.xnio.sasl;

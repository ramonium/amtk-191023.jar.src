/**
 * Utility classes for creating streams which use XNIO channels.
 */
package org.xnio.streams;

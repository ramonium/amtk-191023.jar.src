package liquibase.statement;

public interface CallableSqlStatement extends SqlStatement {
   
}

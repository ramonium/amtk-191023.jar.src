package liquibase.statement.core;

import liquibase.statement.AbstractSqlStatement;

public class GetNextChangeSetSequenceValueStatement extends AbstractSqlStatement {
    
}

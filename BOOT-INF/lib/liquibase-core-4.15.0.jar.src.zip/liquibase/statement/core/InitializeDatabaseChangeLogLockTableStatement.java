package liquibase.statement.core;

import liquibase.statement.AbstractSqlStatement;

public class InitializeDatabaseChangeLogLockTableStatement extends AbstractSqlStatement {
}

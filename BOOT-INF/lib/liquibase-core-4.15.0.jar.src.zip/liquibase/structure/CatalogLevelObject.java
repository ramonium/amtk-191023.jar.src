package liquibase.structure;

import liquibase.structure.core.Catalog;

public interface CatalogLevelObject {
    Catalog getCatalog();
}

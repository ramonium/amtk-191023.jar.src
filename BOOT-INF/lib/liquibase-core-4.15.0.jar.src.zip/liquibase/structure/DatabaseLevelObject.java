package liquibase.structure;

public interface DatabaseLevelObject {
}

package liquibase.hub.model;

import java.util.UUID;

public interface HubModel {

    UUID getId();
}

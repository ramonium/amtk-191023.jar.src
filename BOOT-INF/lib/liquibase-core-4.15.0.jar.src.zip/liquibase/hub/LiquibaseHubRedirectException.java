package liquibase.hub;

import liquibase.exception.LiquibaseException;

public class LiquibaseHubRedirectException extends LiquibaseHubException {
    public LiquibaseHubRedirectException() {
    }
}

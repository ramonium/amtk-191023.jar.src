package liquibase.configuration;

/**
 * @deprecated
 */
public interface ConfigurationValueHandler {
    Object convert(Object value);
}

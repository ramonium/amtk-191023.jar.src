package io.swagger.v3.oas.models;

public enum SpecVersion {
    V30,
    V31
}

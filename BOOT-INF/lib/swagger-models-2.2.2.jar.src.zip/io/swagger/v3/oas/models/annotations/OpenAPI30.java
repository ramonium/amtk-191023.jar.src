package io.swagger.v3.oas.models.annotations;

import java.lang.annotation.Inherited;

@Inherited
public @interface OpenAPI30 {
}
